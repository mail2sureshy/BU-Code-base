﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Threading.Tasks;
using AMCASDESDAL.DataMapping;
using AMCASDESModels;
using System.Data;
using System.Data.Entity;
using System.IO;

namespace AMCASDESDAL
{
    public class AMCASRepository : ErrorLog, IAMCASRepository
    {
        #region AMCASDES Related

        #region ApplicantPersonRelated

        /// <summary>
        /// Insert Applicant information into database.
        /// </summary>
        /// <param name="data"></param>
        /// <param name="sesson"></param>
        /// <param name="batchId"></param>
        /// <returns>bool</returns>
        public async Task<bool> InsertApplicantsData(Export data, int sesson, int batchId, int year)
        {
            try
            {               
                foreach (var application in data.Applications.Application)
                {
                    string res = string.Empty;
                    if (year == 0)
                    {
                        res = await InsertApplicatInformation(application, sesson);
                    }
                    else if (application.IdentifyingInformation.ID.ApplicationYear == year)
                    {
                        res = await InsertApplicatInformation(application, sesson);
                    }
                    // Insert Batch details into datbase.
                    if (!string.IsNullOrEmpty(res))
                        await InsertBatchDetails(sesson, batchId, application.IdentifyingInformation.ID.AAMCID, application.IdentifyingInformation.ID.ApplicationYear, res);
                }
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        private async Task<string> InsertApplicatInformation(ExportApplicationsApplication applicantInfo, int sessonId)
        {
            try
            {
                #region Context

                using (var context = new AMCASEntities())
                {
                    // To increase command timeout.
                    //context.Database.CommandTimeout = 180;

                    #region TransactionPart

                    using (var dbcxtransaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            bool applicationExist = false;

                            var appExist = context.APPLICANT_PERSON.SingleOrDefault(d =>
                                         d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                                         d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);

                            // If applicant person already exist, update DESAUDITs table UPDATE_DATE to current
                            var applicantExists = context.DESAUDITs.SingleOrDefault(d =>
                                                        d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                                                        d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);
                            if (applicantExists != null)
                            {
                                applicantExists.UpdatedDESSessionID = sessonId;
                                applicantExists.UPDATE_DATE = DateTime.Now;
                            }
                            else
                            {
                                // Add data to Audit table.
                                DateTime dtNow = DateTime.Now;
                                DESAUDIT audit = new DESAUDIT
                                {
                                    DESSessionID = sessonId,
                                    APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    CREATE_DATE = dtNow,
                                    UPDATE_DATE = dtNow
                                };
                                context.DESAUDITs.Add(audit);

                            }

                            if (appExist != null)
                            {
                                #region Archive

                                applicationExist = true;

                                // Archive Applicant if alredy exist in database --Start

                                // GPA's Archive object
                                var appGpasArchive = Gpas.GetGpasArchiveList(applicantInfo, sessonId);

                                // Add Gpas Archive data
                                if (appGpasArchive.Count > 0)
                                    context.GPA_ARCHIVE.AddRange(appGpasArchive);

                                // Mcat 1991 Archive object
                                var appMcat1991Archive = Mcat1991.GetMcat1991ArchivesList(applicantInfo, sessonId);

                                // Add MCAT 1991 archive data.
                                if (appMcat1991Archive.Count > 0)
                                    context.MCAT_SCORES_ARCHIVE.AddRange(appMcat1991Archive);

                                // Mcat 2015 Archive object
                                var appMcat2015Archive = Mcat2015.GetMcat2015ArchivesList(applicantInfo, sessonId);

                                // Add MCAT 2015 Archive data
                                if (appMcat2015Archive.Count > 0)
                                    context.MCAT_SCORE_2015_ARCHIVE.AddRange(appMcat2015Archive);


                                // Archive Applicant if alredy exist in database -- End

                                #endregion

                                #region UpdateDesignatedData

                                // Update DESIGNATED_SCHOOL and DESIGNATED_PROGRAM Tables.
                                await DesignatedSchools.UpdateDesignatedSchoolsList(applicantInfo, context);

                                #endregion

                                #region DeleteExistingData

                                // Delete Applicant if alredy exist in database --Start

                                await DeleteApplicant.DeleteExistingApplicant(context, applicantInfo);

                                // Delete Applicant if alredy exist in database -- End

                                #endregion
                            }

                            #region Insert

                            await InsertApplicantData(context, applicantInfo, applicationExist);

                            #endregion

                            dbcxtransaction.Commit();

                        }
                        catch (DbEntityValidationException ex)
                        {
                            // Retrieve the error messages as a list of strings.
                            var errorMessages = ex.EntityValidationErrors
                                    .SelectMany(x => x.ValidationErrors)
                                    .Select(x => x.ErrorMessage);

                            // Join the list to a single string.
                            var fullErrorMessage = string.Join("; ", errorMessages);

                            // Combine the original exception message with the new one.
                            var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                            dbcxtransaction.Rollback();

                            // Throw a new DbEntityValidationException with the improved exception message.
                            throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                        }
                        catch (Exception)
                        {
                            dbcxtransaction.Rollback();
                            throw;
                        }
                    }
                    #endregion
                }

                #endregion
            }
            catch (Exception ex)
            {
                string exceptiondetails = ex.Message;
                var ex1 = ex.InnerException;
                while (ex1 != null)
                {
                    exceptiondetails += "Inner exception: " + ex1.Message;
                    ex1 = ex1.InnerException;
                }
                await InsertEvenLogInformation(exceptiondetails, applicantInfo.IdentifyingInformation.ID.AAMCID.ToString());
                return exceptiondetails;
            }
            return "Success";
        }


        private static async Task<bool> InsertApplicantData(AMCASEntities context, ExportApplicationsApplication applicantInfo, bool applicationExist)
        {
            try
            {
                #region Insert Objects

                // Applicant Person related object
                var appPerson = ApplicantPerson.MapObject(applicantInfo);

                // Address related objects
                //Unable to determine the principal end of the 'AMCAS_Entities.FK__ADDRESS__0E240DFC' relationship. Multiple added entities may have the same primary key.
                //var appAddress = Address.Addresses(applicantInfo); // Using this getting above exception, split into multiple entries.

                // Alternate Names objects
                var appAlternateNames = AlternateNames.GetAlternateNamesList(applicantInfo);

                // Address related objects
                var appPerAddress = Address.PermanentAddress(applicantInfo);

                // Address related objects
                var appPreAddress = Address.PreferredAddress(applicantInfo);

                // Address related objects
                var appAltAddress = Address.AlternateAddress(applicantInfo);

                // Parent Guardians objects
                var appParentGuardians = ParentGuardian.GetParentGuardianList(applicantInfo);

                // Alternate ID's objects
                var appAlternateIds = AlternateId.AlternateIds(applicantInfo);

                // Siblings objects
                var appSiblings = Siblings.SiblingsDataList(applicantInfo);

                // Disadvantaged Status objects
                var appDisadvantagedStatus = DisadvantagedStatus.GetDisadvantagedStatus(applicantInfo);

                // Schools Attended object
                var appSchoolsAttended = SchoolsAttended.SchoolsAttendedList(applicantInfo);

                // Degrees object
                var appDegrees = Degrees.DegreesList(applicantInfo);

                // Essays object
                var appEssays = Essays.EssaysList(applicantInfo);

                // Ethnicity object
                var appEthnicity = Ethnicitys.EthnicitysList(applicantInfo);

                // Races object
                var appRaces = Races.GetRacesList(applicantInfo);

                // Experiences object
                var appExperiences = Experiences.ExperiencesList(applicantInfo);

                // Languages object
                var appLanguages = Languages.LanguagesList(applicantInfo);

                // Letters object
                var appLetters = Letters.LettersList(applicantInfo);

                // Letter Receipts object
                var appLetterReceipts = LetterReceipts.LetterReceiptsList(applicantInfo);

                // Letter Document Receipt object
                var appLetterDocReceipts = Letters.DocumentReceiptsList(applicantInfo);

                // GPA's object
                var appGpas = Gpas.GetGpaList(applicantInfo);

                // Major Minor object
                var appMajorMinor = MajorMinor.MajorMinorsList(applicantInfo);

                // Investigative, Evaluative and MCAT Image Document Receipts object
                var appInvEvalAndMcatDocReceipts = Letters.InvestigativeEvaluativeAndMcatDocumentReceiptsList(applicantInfo);

                // Misc Test object
                var appMiscTest = MiscTest.GetMiscTest(applicantInfo);

                // Previous Application object
                var appPreviousApplicationInfo = PreviousApplicationInfo.GetPreviousApplicationInfoList(applicantInfo);

                // MCAT 1991 objects
                var mcat1991 = Mcat1991.Mcat1991List(applicantInfo);

                // MCAT 2015 objects
                var mcat2015 = Mcat2015.Mcat2015List(applicantInfo);

                // Course Work object
                var courseWork = CourseWork.GetCourseWorksList(applicantInfo);

                // Course Type object
                var courseType = CourseType.GetCourseTypeList(applicantInfo);

                #endregion

                #region InsertData

                // Add Applicant person
                if (appPerson != null)
                    context.APPLICANT_PERSON.Add(appPerson);
                //await context.SaveChangesAsync();

                // Add Alternate Names
                if (appAlternateNames != null && appAlternateNames.Count > 0)
                    context.NAMEs.AddRange(appAlternateNames);

                // Add Applicant Permanent Address
                if (appPerAddress != null)
                    context.ADDRESSes.Add(appPerAddress);

                // Add Applicant Preferred Address
                if (appPreAddress != null)
                    context.ADDRESSes.Add(appPreAddress);

                // Add Applicant Alternate Address
                if (appAltAddress != null)
                    context.ADDRESSes.Add(appAltAddress);
                //await context.SaveChangesAsync();

                // Add Parent Guardians data.
                if (appParentGuardians != null && appParentGuardians.Count > 0)
                    context.PARENT_GUARDIAN.AddRange(appParentGuardians);
                //await context.SaveChangesAsync();

                // Add Applicant AlternateId's
                if (appAlternateIds != null && appAlternateIds.Count > 0)
                    context.ALTERNATE_ID.AddRange(appAlternateIds);
                //await context.SaveChangesAsync();

                // Add Siblings data
                if (appSiblings != null && appSiblings.Count > 0)
                    context.SIBLINGs.AddRange(appSiblings);
                //await context.SaveChangesAsync();

                // Add Disadvantaged Status data
                if (appDisadvantagedStatus != null)
                    context.DISADVANTAGED_STATUS.Add(appDisadvantagedStatus);
                //await context.SaveChangesAsync();

                // Add Schools Attended data
                if (appSchoolsAttended != null && appSchoolsAttended.Count > 0)
                    context.SCHOOL_ATTENDED.AddRange(appSchoolsAttended);
                //await context.SaveChangesAsync();

                // Add Degrees data
                if (appDegrees != null && appDegrees.Count > 0)
                    context.DEGREEs.AddRange(appDegrees);
                //await context.SaveChangesAsync();

                // Add Essays data
                if (appEssays != null && appEssays.Count > 0)
                    context.ESSAYs.AddRange(appEssays);
                //await context.SaveChangesAsync();

                // Add Ethnicity data
                if (appEthnicity != null && appEthnicity.Count > 0)
                    context.ETHNICITies.AddRange(appEthnicity);
                //await context.SaveChangesAsync();

                // Add RACEs data
                if (appRaces != null && appRaces.Count > 0)
                    context.RACEs.AddRange(appRaces);
                //await context.SaveChangesAsync();

                // Add Experiences data
                if (appExperiences != null && appExperiences.Count > 0)
                    context.EXPERIENCEs.AddRange(appExperiences);
                //await context.SaveChangesAsync();

                // Add Languages data
                if (appLanguages != null && appLanguages.Count > 0)
                    context.LANGUAGEs.AddRange(appLanguages);
                //await context.SaveChangesAsync();

                // Add Letters data
                if (appLetters != null && appLetters.Count > 0)
                    context.LETTERs.AddRange(appLetters);
                //await context.SaveChangesAsync();

                // Add Letter Receipts data
                if (appLetterReceipts != null && appLetterReceipts.Count > 0)
                    context.LETTER_RECEIPT.AddRange(appLetterReceipts);
                //await context.SaveChangesAsync();

                // Add Letter Document Receipt data
                if (appLetterDocReceipts != null && appLetterDocReceipts.Count > 0)
                    context.DOCUMENT_RECEIPT.AddRange(appLetterDocReceipts);
                //await context.SaveChangesAsync();

                // Investigative And Evaluative Document Receipts data
                if (appInvEvalAndMcatDocReceipts != null && appInvEvalAndMcatDocReceipts.Count > 0)
                    context.DOCUMENT_RECEIPT.AddRange(appInvEvalAndMcatDocReceipts);
                //await context.SaveChangesAsync();

                // Add Gpa's data
                if (appGpas != null && appGpas.Count > 0)
                    context.GPAs.AddRange(appGpas);
                //await context.SaveChangesAsync();

                // MCAT 1991 data
                if (appAlternateNames != null && mcat1991.Count > 0)
                    context.MCAT_SCORES.AddRange(mcat1991);
                //await context.SaveChangesAsync();

                // MCAT 2015 data
                if (mcat2015 != null && mcat2015.Count > 0)
                    context.MCAT_SCORE_2015.AddRange(mcat2015);
                //await context.SaveChangesAsync();

                //Add Misc Test data
                if (appMiscTest != null && appMiscTest.Count > 0)
                    context.MISC_TEST.AddRange(appMiscTest);
                //await context.SaveChangesAsync();

                // Add Course Work data
                if (courseWork != null && courseWork.Count > 0)
                    context.COURSE_WORK.AddRange(courseWork);
                //await context.SaveChangesAsync();

                // Add Course Type data
                if (courseType != null && courseType.Count > 0)
                    context.COURSE_TYPE.AddRange(courseType);
                //await context.SaveChangesAsync();

                // Add Major Minor data
                if (appMajorMinor != null && appMajorMinor.Count > 0)
                    context.MAJOR_MINOR.AddRange(appMajorMinor);
                //await context.SaveChangesAsync();

                // Previous Application Data
                if (appPreviousApplicationInfo != null && appPreviousApplicationInfo.Count > 0)
                    context.PREVIOUS_APPLICATION_INFO.AddRange(appPreviousApplicationInfo);

                await context.SaveChangesAsync();

                if (!applicationExist)
                {
                    // Set the designated schools and related chaild tables, Save the changes when context.savechanges called.
                    await DesignatedSchools.SetDesignatedSchoolsList(applicantInfo, context);
                }                

                return true;

                #endregion
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region DocumentContent

        public IEnumerable<DocumentContent> GetDocumnetContents(int appYear)
        {
            try
            {
                return DocContents.GetDocumnetContents(appYear);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> SaveDocumnetContents(DocumentContentData data)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    using (var dbcxtransaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            var cont = DocContents.SaveDocumnetContent(data);
                            if (cont != null)
                            {
                                context.DOCUMENT_CONTENT.Add(cont);
                                await context.SaveChangesAsync();
                                int docContId = cont.DocumentContentID;
                                if (docContId != 0)
                                {
                                    var docReceipt =
                                        context.DOCUMENT_RECEIPT.SingleOrDefault(a => a.APPL_PERSON_ID == data.ApplicantPersonId &&
                                        a.APPL_YEAR == data.ApplicantYear && a.DocumentReceiptID == data.DocumentReceiptId);
                                    if (docReceipt != null)
                                    {
                                        docReceipt.DocumentContentID = docContId;
                                        await context.SaveChangesAsync();
                                        dbcxtransaction.Commit();
                                    }
                                }
                            }
                        }
                        catch (Exception)
                        {
                            dbcxtransaction.Rollback();
                            throw;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await InsertEvenLogInformation(ex.Message);
                return false;
            }
            return true;
        }

        #endregion

        #region ActionRelatedCalls

        /// <summary>
        /// Gets Actions as string
        /// </summary>
        /// <param name="appYear"></param>
        /// <param name="medicalInstId"></param>
        /// <returns>string</returns>
        public async Task<string> GetAmcasActions(int appYear, int medicalInstId)
        {
            try
            {
                return await AmcasAction.GetAmcasActions(appYear, medicalInstId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Update actions result back to database.
        /// </summary>
        /// <param name="response"></param>
        /// <returns>bool</returns>
        public async Task<bool> UpdateAmcasActionsResults(AdmissionActionsResponse response)
        {
            try
            {
                foreach (var result in response.ActionResult)
                {
                    await AmcasAction.UpdateAmcasActionResults(result);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        #endregion

        #region GeneralCalls
        
        public async Task<int> InsertSessionId(string methodCall)
        {
            int seesionId = 0;
            try
            {
                using (var context = new AMCASEntities())
                {
                    DateTime dtNow = DateTime.Now;
                    DESSession sesson = new DESSession
                    {
                        CallFrom = methodCall,
                        StartDate = dtNow,
                        EndDate = dtNow
                    };
                    context.DESSessions.Add(sesson);
                    await context.SaveChangesAsync();
                    seesionId = sesson.DESSessionID;
                }
            }
            catch (Exception ex)
            {
                await InsertEvenLogInformation(ex.Message);
                return 0;
            }
            return seesionId;
        }

        public async Task<bool> UpdateSessionId(int sessionId)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    var res = context.DESSessions.SingleOrDefault(a => a.DESSessionID == sessionId);
                    if (res != null)
                    {
                        res.EndDate = DateTime.Now;
                        await context.SaveChangesAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        public async Task<int> InsertBatchId(int seesionId, string xmlResponse)
        {
            int batchId = 0;
            try
            {
                using (var context = new AMCASEntities())
                {
                    DESBatch batch = new DESBatch
                    {
                        DESSessionID = seesionId,
                        XMLResponse = xmlResponse
                    };
                    context.DESBatches.Add(batch);
                    await context.SaveChangesAsync();
                    batchId = batch.DESBatchID;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return batchId;
        }

        public async Task<bool> InsertBatchDetails(int seesionId, int batchId, long aamcId, int cycle, string comments)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    DESBatchDetail batchDetails = new DESBatchDetail
                    {
                        DESSessionID = seesionId,
                        DESBatchID = batchId,
                        AAMCID = (int)aamcId,
                        Cycle = cycle,
                        IsSuccess = comments == "Success",
                        ExecutionComments = comments,
                        CreateDate = DateTime.Now,
                    };
                    context.DESBatchDetails.Add(batchDetails);
                    await context.SaveChangesAsync();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        #endregion

        #endregion

        #region AMCASREF Related

        /// <summary>
        /// Get the File names and table names from database, read data from files and insert into database.
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="applicationYear"></param>
        /// <returns></returns>
        public async Task<string> InsertReferenceTablesData(string filePath, int applicationYear)
        {
            int errorRowCount = 0;
            try
            {
                using (var context = new AMCASEntities())
                {
                    var appExist = await context.DES_REFTABLELOADORDER.Where(a => a.APPL_YEAR == applicationYear && a.FileName != null).ToListAsync();
                    if (appExist.Count > 0)
                    {
                        foreach (var tbls in appExist)
                        {
                            string fileFullPath = string.Concat(filePath, tbls.FileName);
                            string tblName = tbls.TableName;
                            if (File.Exists(fileFullPath))
                            {
                                var reader = ReadAsLines(fileFullPath);

                                var data = new DataTable();
                                //this assume the first record is filled with the column names
                                var headers = reader.First().Split('|');
                                int columnCount = headers.Length;
                                foreach (var header in headers)
                                {
                                    data.Columns.Add(header);
                                }
                                var records = reader.Skip(1);
                                foreach (var record in records)
                                {
                                    string[] rowData = record.Split('|');
                                    int rowDataCount = rowData.Length;
                                    // Check if column count and data element count match or not
                                    if (columnCount == rowDataCount)
                                    {
                                        data.Rows.Add(rowData);
                                    }
                                    else
                                    {
                                        errorRowCount += 1;
                                        await InsertRefErrorLogInfor(applicationYear, tblName, record);
                                    }
                                }

                                //Check if data in datatable then insert into database.
                                if (data.Rows.Count > 0)
                                    await InsertRefTableData(tblName, context, data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string exceptiondetails = ex.Message;
                var ex1 = ex.InnerException;
                while (ex1 != null)
                {
                    exceptiondetails += "Inner exception: " + ex1.Message;
                    ex1 = ex1.InnerException;
                }
                await InsertEvenLogInformation(exceptiondetails);
                return exceptiondetails;
            }
            if (errorRowCount > 0)
                return errorRowCount.ToString() + " Rows of error data, Please verify DES_RefEventLog table.";
            return "Success";
        }

        /// <summary>
        /// Insert specific table data into database.
        /// </summary>
        /// <param name="tblName"></param>
        /// <param name="context"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        private async Task<bool> InsertRefTableData(string tblName, AMCASEntities context, DataTable data)
        {
            try
            {
                switch (tblName)
                {
                    case "adiuser.REF_SCHOOL_ADMISSION_ACTION":
                        var lstSchoolAdmActions = RefTablesDataList.GetRefSchoolAdmissionList(data);
                        if (lstSchoolAdmActions.Count > 0)
                            context.REF_SCHOOL_ADMISSION_ACTION.AddRange(lstSchoolAdmActions);
                        break;
                    case "adiuser.REF_COUNTRY":
                        var lstCountrys = RefTablesDataList.GetRefCountrysList(data);
                        if (lstCountrys.Count > 0)
                            context.REF_COUNTRY.AddRange(lstCountrys);
                        break;
                    case "adiuser.REF_STATE":
                        var lstStates = RefTablesDataList.GetRefStatesList(data);
                        if (lstStates.Count > 0)
                            context.REF_STATE.AddRange(lstStates);
                        break;
                    case "adiuser.REF_COUNTY":
                        var lstCountys = RefTablesDataList.GetRefCountyList(data);
                        if (lstCountys.Count > 0)
                            context.REF_COUNTY.AddRange(lstCountys);
                        break;
                    case "adiuser.REF_SALUTATION":
                        var lstSalutation = RefTablesDataList.GetRefSalutationList(data);
                        if (lstSalutation.Count > 0)
                            context.REF_SALUTATION.AddRange(lstSalutation);
                        break;
                    case "adiuser.REF_SUFFIX":
                        var lstSuffix = RefTablesDataList.GetRefSuffixList(data);
                        if (lstSuffix.Count > 0)
                            context.REF_SUFFIX.AddRange(lstSuffix);
                        break;
                    case "adiuser.REF_COLLEGE_INSTITUTION": // Issues with data
                        var lstCollegeInst = RefTablesDataList.GetRefCollegeInisInstitutionsList(data);
                        if (lstCollegeInst.Count > 0)
                            context.REF_COLLEGE_INSTITUTION.AddRange(lstCollegeInst);
                        break;
                    case "adiuser.REF_COLLEGE_INST_CONTACT":
                        var lstCollegeInstContact = RefTablesDataList.GetRefCollegeInisInstContactsList(data);
                        if (lstCollegeInstContact.Count > 0)
                            context.REF_COLLEGE_INST_CONTACT.AddRange(lstCollegeInstContact);
                        break;
                    case "adiuser.REF_COURSE_TYPE":
                        var lstRefCourseType = RefTablesDataList.GetRefCourseType(data);
                        if (lstRefCourseType.Count > 0)
                            context.REF_COURSE_TYPE.AddRange(lstRefCourseType);
                        break;
                    case "adiuser.REF_DEGREE_CAT":
                        var lstDegreeCat = RefTablesDataList.GetRefDegreeCatList(data);
                        if (lstDegreeCat.Count > 0)
                            context.REF_DEGREE_CAT.AddRange(lstDegreeCat);
                        break;
                    case "adiuser.REF_FIELD_TYPE":
                        var lstFieldType = RefTablesDataList.GetRefFieldTypeList(data);
                        if (lstFieldType.Count > 0)
                            context.REF_FIELD_TYPE.AddRange(lstFieldType);
                        break;
                    case "adiuser.REF_MAJOR_CAT":
                        var lstMajorCat = RefTablesDataList.GetMajorCatList(data);
                        if (lstMajorCat.Count > 0)
                            context.REF_MAJOR_CAT.AddRange(lstMajorCat);
                        break;
                    case "adiuser.REF_MED_INST": // Issues with data
                        var lstMedInst = RefTablesDataList.GetMedInstList(data);
                        if (lstMedInst.Count > 0)
                            context.REF_MED_INST.AddRange(lstMedInst);
                        break;
                    case "adiuser.REF_GRADUATE_PROGRAM":
                        var lstGraduateProgram = RefTablesDataList.GetGraduateProgramList(data);
                        if (lstGraduateProgram.Count > 0)
                            context.REF_GRADUATE_PROGRAM.AddRange(lstGraduateProgram);
                        break;
                    case "adiuser.REF_APPLICATION_STATUS":
                        var lstApplicationStatus = RefTablesDataList.GetApplicationStatusList(data);
                        if (lstApplicationStatus.Count > 0)
                            context.REF_APPLICATION_STATUS.AddRange(lstApplicationStatus);
                        break;
                    case "adiuser.REF_APPLICATION_TYPE":
                        var lstApplicationTypes = RefTablesDataList.GetApplicationTypesList(data);
                        if (lstApplicationTypes.Count > 0)
                            context.REF_APPLICATION_TYPE.AddRange(lstApplicationTypes);
                        break;
                    case "adiuser.REF_MED_PROG_INFO":
                        var lstMedicalProgInfo = RefTablesDataList.GetMedicalProgInfoList(data);
                        if (lstMedicalProgInfo.Count > 0)
                            context.REF_MED_PROG_INFO.AddRange(lstMedicalProgInfo);
                        break;
                    case "adiuser.REF_RACE_CATEGORY":
                        var lstRaceCategorys = RefTablesDataList.GetRaceCategorysList(data);
                        if (lstRaceCategorys.Count > 0)
                            context.REF_RACE_CATEGORY.AddRange(lstRaceCategorys);
                        break;
                    case "adiuser.REF_CALENDAR":
                        var lstCalendars = RefTablesDataList.GetCalendarList(data);
                        if (lstCalendars.Count > 0)
                            context.REF_CALENDAR.AddRange(lstCalendars);
                        break;
                    case "adiuser.REF_ACA_STATUS":
                        var lstAcaStatus = RefTablesDataList.GetAcaStatusList(data);
                        if (lstAcaStatus.Count > 0)
                            context.REF_ACA_STATUS.AddRange(lstAcaStatus);
                        break;
                    case "adiuser.REF_ADDRESS_TYPE":
                        var lstAddressTypes = RefTablesDataList.GetAddressTypesList(data);
                        if (lstAddressTypes.Count > 0)
                            context.REF_ADDRESS_TYPE.AddRange(lstAddressTypes);
                        break;
                    case "adiuser.REF_ADI_STATUS":
                        var lstAdiStatus = RefTablesDataList.GetAdiStatusList(data);
                        if (lstAdiStatus.Count > 0)
                            context.REF_ADI_STATUS.AddRange(lstAdiStatus);
                        break;
                    //// As per Marco, no need to populate REF_ADMISSION_ACTION_VALID table.
                    //case "adiuser.REF_ADMISSION_ACTION_VALID": 
                    //    var lstAdmissionActionValid = RefTablesDataList.GetRefAdmissionActionValidList(data);
                    //    if (lstAdmissionActionValid.Count > 0)
                    //        context.REF_ADMISSION_ACTION_VALID.AddRange(lstAdmissionActionValid);
                    //    break;
                    case "adiuser.REF_ALT_ID_TYPE":
                        var lstAltIdType = RefTablesDataList.GetAltIdTypeList(data);
                        if (lstAltIdType.Count > 0)
                            context.REF_ALT_ID_TYPE.AddRange(lstAltIdType);
                        break;
                    case "adiuser.REF_AMCAS_GRADE":
                        var lstMCASGrades = RefTablesDataList.GetAMCASGradesList(data);
                        if (lstMCASGrades.Count > 0)
                            context.REF_AMCAS_GRADE.AddRange(lstMCASGrades);
                        break;
                    case "adiuser.REF_AP_SECTION_TAB":
                        var lstAPSectionTabs = RefTablesDataList.GetAPSectionTabsList(data);
                        if (lstAPSectionTabs.Count > 0)
                            context.REF_AP_SECTION_TAB.AddRange(lstAPSectionTabs);
                        break;

                    case "adiuser.REF_CARNEGIE":
                        var lstCarnegies = RefTablesDataList.GetCarnegiesList(data);
                        if (lstCarnegies.Count > 0)
                            context.REF_CARNEGIE.AddRange(lstCarnegies);
                        break;
                    case "adiuser.REF_CLASS":
                        var lstClasses = RefTablesDataList.GetClass(data);
                        if (lstClasses.Count > 0)
                            context.REF_CLASS.AddRange(lstClasses);
                        break;
                    case "adiuser.REF_COLLEGE_PROGRAM":
                        var lstCollegeProgram = RefTablesDataList.GetCollegeProgram(data);
                        if (lstCollegeProgram.Count > 0)
                            context.REF_COLLEGE_PROGRAM.AddRange(lstCollegeProgram);
                        break;
                    case "adiuser.REF_DEGREE":
                        var lstDegrees = RefTablesDataList.GetDegrees(data);
                        if (lstDegrees.Count > 0)
                            context.REF_DEGREE.AddRange(lstDegrees);
                        break;
                    case "adiuser.REF_EDU_LEVEL":
                        var lstEduLevel = RefTablesDataList.GetEduLevel(data);
                        if (lstEduLevel.Count > 0)
                            context.REF_EDU_LEVEL.AddRange(lstEduLevel);
                        break;
                    case "adiuser.REF_ESSAY_TYPE":
                        var lstEssayTypes = RefTablesDataList.GetEssayTypes(data);
                        if (lstEssayTypes.Count > 0)
                            context.REF_ESSAY_TYPE.AddRange(lstEssayTypes);
                        break;
                    case "adiuser.REF_ETHNICITY":
                        var lstEthnicitys = RefTablesDataList.GetEthnicitys(data);
                        if (lstEthnicitys.Count > 0)
                            context.REF_ETHNICITY.AddRange(lstEthnicitys);
                        break;
                    case "adiuser.REF_EXP_TYPE":
                        var lstExpTypes = RefTablesDataList.GetExpTypes(data);
                        if (lstExpTypes.Count > 0)
                            context.REF_EXP_TYPE.AddRange(lstExpTypes);
                        break;
                    case "adiuser.REF_FIELD":
                        var lstFields = RefTablesDataList.GetFields(data);
                        if (lstFields.Count > 0)
                            context.REF_FIELD.AddRange(lstFields);
                        break;
                    case "adiuser.REF_GEO_CAT":
                        var lstGeoCats = RefTablesDataList.GetGeoCat(data);
                        if (lstGeoCats.Count > 0)
                            context.REF_GEO_CAT.AddRange(lstGeoCats);
                        break;
                    case "adiuser.REF_HIDE_TYPE":
                        var lstHideTypes = RefTablesDataList.GetHideTypes(data);
                        if (lstHideTypes.Count > 0)
                            context.REF_HIDE_TYPE.AddRange(lstHideTypes);
                        break;
                    case "adiuser.REF_HIGH_SCHOOL_INSTITUTION":
                        var lstHighSchoolInistitutions = RefTablesDataList.GetHighSchoolInistitutions(data);
                        if (lstHighSchoolInistitutions.Count > 0)
                            context.REF_HIGH_SCHOOL_INSTITUTION.AddRange(lstHighSchoolInistitutions);
                        break;
                    case "adiuser.REF_INCOME":
                        var lstIncomes = RefTablesDataList.GetIncomes(data);
                        if (lstIncomes.Count > 0)
                            context.REF_INCOME.AddRange(lstIncomes);
                        break;
                    case "adiuser.REF_INVESTIGATION_TYPE":
                        var lstInvestigationTypes = RefTablesDataList.GetInvestigationTypes(data);
                        if (lstInvestigationTypes.Count > 0)
                            context.REF_INVESTIGATION_TYPE.AddRange(lstInvestigationTypes);
                        break;
                    case "adiuser.REF_LANG":
                        var lstLanges = RefTablesDataList.GetLanges(data);
                        if (lstLanges.Count > 0)
                            context.REF_LANG.AddRange(lstLanges);
                        break;
                    case "adiuser.REF_LANGUAGE_PROFICIENCY":
                        var lstLanguageProficiencys = RefTablesDataList.GetLanguageProficiency(data);
                        if (lstLanguageProficiencys.Count > 0)
                            context.REF_LANGUAGE_PROFICIENCY.AddRange(lstLanguageProficiencys);
                        break;
                    case "adiuser.REF_LANGUAGE_USAGE":
                        var lstLanguageUsage = RefTablesDataList.GetLanguageUsage(data);
                        if (lstLanguageUsage.Count > 0)
                            context.REF_LANGUAGE_USAGE.AddRange(lstLanguageUsage);
                        break;
                    case "adiuser.REF_LETTER_SOURCE":
                        var lstLetterSource = RefTablesDataList.GetLetterSource(data);
                        if (lstLetterSource.Count > 0)
                            context.REF_LETTER_SOURCE.AddRange(lstLetterSource);
                        break;
                    //case "adiuser.REF_LETTER_TYPE": // Column names are not matching with source .txt file
                    //    var lstLetterType = RefTablesDataList.GetLetterType(data);
                    //    if (lstLetterType.Count > 0)
                    //        context.REF_LETTER_TYPE.AddRange(lstLetterType);
                    //    break;
                    case "adiuser.REF_LOCAL_APPL_STATUS":
                        var lstLocalApplStatus = RefTablesDataList.GetLocalApplStatus(data);
                        if (lstLocalApplStatus.Count > 0)
                            context.REF_LOCAL_APPL_STATUS.AddRange(lstLocalApplStatus);
                        break;
                    case "adiuser.REF_MAJOR":
                        var lstMajor = RefTablesDataList.GetMajor(data);
                        if (lstMajor.Count > 0)
                            context.REF_MAJOR.AddRange(lstMajor);
                        break;
                    case "adiuser.REF_MED_GRAD_PROG": // Error: Missing data in REF_MED_PROG_INFO table 
                        var lstMedGraduatePrograms = RefTablesDataList.GetMedGraduatePrograms(data);
                        //var coumty = lstMedGraduatePrograms.Select(x => x.MED_PROGRAM_INFO_ID).Distinct();
                        //using (StreamWriter writetext = new StreamWriter(@"C:\BUMCProjects\AMCASDESClient\AMCASDESClient.Tests\bin\Debug\ErrorFile.txt"))
                        //{
                        //    foreach (var programInfoId in coumty)
                        //    {
                        //        writetext.WriteLine(programInfoId);
                        //    }
                        //}
                        if (lstMedGraduatePrograms.Count > 0)
                            context.REF_MED_GRAD_PROG.AddRange(lstMedGraduatePrograms);
                        break;
                    case "adiuser.REF_MED_INST_CAMPUS":
                        var lstMedInstCampus = RefTablesDataList.GetMedInstCampus(data);
                        if (lstMedInstCampus.Count > 0)
                            context.REF_MED_INST_CAMPUS.AddRange(lstMedInstCampus);
                        break;
                    case "adiuser.REF_MILITARY_STATUS":
                        var lstMilitaryStatus = RefTablesDataList.GetMilitaryStatus(data);
                        if (lstMilitaryStatus.Count > 0)
                            context.REF_MILITARY_STATUS.AddRange(lstMilitaryStatus);
                        break;
                    case "adiuser.REF_OCCUPATION":
                        var lstOccupations = RefTablesDataList.GetOccupations(data);
                        if (lstOccupations.Count > 0)
                            context.REF_OCCUPATION.AddRange(lstOccupations);
                        break;
                    case "adiuser.REF_PROGRAM_TYPE":
                        var lstProgramTypes = RefTablesDataList.GetProgramTypes(data);
                        if (lstProgramTypes.Count > 0)
                            context.REF_PROGRAM_TYPE.AddRange(lstProgramTypes);
                        break;
                    case "adiuser.REF_RACE":
                        var lstRaces = RefTablesDataList.GetRaces(data);
                        if (lstRaces.Count > 0)
                            context.REF_RACE.AddRange(lstRaces);
                        break;
                    case "adiuser.REF_SCORE_RANGE":
                        var lstScoreRanges = RefTablesDataList.GetScoreRanges(data);
                        if (lstScoreRanges.Count > 0)
                            context.REF_SCORE_RANGE.AddRange(lstScoreRanges);
                        break;
                    case "adiuser.REF_SUBJECT_TYPE":
                        var lstSubjectTypes = RefTablesDataList.GetSubjectTypes(data);
                        if (lstSubjectTypes.Count > 0)
                            context.REF_SUBJECT_TYPE.AddRange(lstSubjectTypes);
                        break;
                    case "adiuser.REF_TERM":
                        var lstTerms = RefTablesDataList.GetTerms(data);
                        if (lstTerms.Count > 0)
                            context.REF_TERM.AddRange(lstTerms);
                        break;
                    case "adiuser.REF_VERIFICATION_SYMBOL":
                        var lstVerificationSymbols = RefTablesDataList.GetVerificationSymbols(data);
                        if (lstVerificationSymbols.Count > 0)
                            context.REF_VERIFICATION_SYMBOL.AddRange(lstVerificationSymbols);
                        break;
                    case "adiuser.REF_VISA":
                        var lstVisa = RefTablesDataList.GetVisa(data);
                        if (lstVisa.Count > 0)
                            context.REF_VISA.AddRange(lstVisa);
                        break;
                }
                await context.SaveChangesAsync();
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                // Throw a new DbEntityValidationException with the improved exception message.
                //throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
                await InsertEvenLogInformation(exceptionMessage);
                return false;
            }
            catch (Exception ex)
            {
                string exceptiondetails = ex.Message;
                var ex1 = ex.InnerException;
                while (ex1 != null)
                {
                    exceptiondetails += "Inner exception: " + ex1.Message;
                    ex1 = ex1.InnerException;
                }
                await InsertEvenLogInformation(exceptiondetails);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Read data from file and reurn IEnumerable string.
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        private static IEnumerable<string> ReadAsLines(string filename)
        {
            using (var reader = new StreamReader(filename))
            {
                while (!reader.EndOfStream)
                {
                    yield return reader.ReadLine();
                }
            }
        }

        #endregion
    }   
}
