﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class ApplicantPerson
    {
        private static string GetSalvationCode(string salvation)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    return context.REF_SALUTATION.FirstOrDefault(a => a.SALUTATION_DESC == salvation).SALUTATION_CD;
                }
            }
            catch (Exception ex)
            {
               throw ex;
            }
        }

        private static string GetSuffixCode(string suffix)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    return context.REF_SUFFIX.FirstOrDefault(a => a.DISPLAY_TXT == suffix).SUFFIX_CD;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static APPLICANT_PERSON MapObject(ExportApplicationsApplication applicantInfo)
        {
            try
            {
                var appPerson = new APPLICANT_PERSON()
                {
                    APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                    VISA_CD = applicantInfo.DemographicInformation.CitizenshipResidency.VisaType.ToString(),
                    LEGAL_RES_STATE_CD = applicantInfo.DemographicInformation.CitizenshipResidency.ResidencyState?.StateCode.ToString(),
                    LEGAL_SALUTATION_CD = applicantInfo.IdentifyingInformation.NameDetails.Legal.Salutation != null
                        ? GetSalvationCode(applicantInfo.IdentifyingInformation.NameDetails.Legal.Salutation) : null,   
                     LEGAL_SUFFIX_CD = applicantInfo.IdentifyingInformation.NameDetails.Legal.Suffix != null
                        ? GetSuffixCode(applicantInfo.IdentifyingInformation.NameDetails.Legal.Suffix) : null,
                    //LEGAL_SUFFIX_CD = applicantInfo.IdentifyingInformation.NameDetails.Legal?.Suffix,
                    FAP_IND = applicantInfo.DemographicInformation.GeneralDemographics.FAPIndicator,
                    LEGAL_RES_COUNTY_CD = applicantInfo.DemographicInformation.CitizenshipResidency?.ResidencyCounty?.CountyCode,
                    PREF_SALUTATION_CD = applicantInfo.IdentifyingInformation.NameDetails.Preferred.Salutation != null
                        ? GetSalvationCode(applicantInfo.IdentifyingInformation.NameDetails.Preferred.Salutation) : null,
                    LEGAL_FNAME = applicantInfo.IdentifyingInformation.NameDetails.Legal.FirstName,
                    LEGAL_MNAME = applicantInfo.IdentifyingInformation.NameDetails.Legal.MiddleName,
                    LEGAL_LNAME = applicantInfo.IdentifyingInformation.NameDetails.Legal.LastName,
                    PREF_SUFFIX_CD = applicantInfo.IdentifyingInformation.NameDetails.Preferred.Suffix != null
                        ? GetSuffixCode(applicantInfo.IdentifyingInformation.NameDetails.Preferred.Suffix) : null,
                    //PREF_SUFFIX_CD = applicantInfo.IdentifyingInformation.NameDetails.Preferred.Suffix,
                    PREF_FNAME = applicantInfo.IdentifyingInformation.NameDetails.Preferred.FirstName,
                    PREF_MNAME = applicantInfo.IdentifyingInformation.NameDetails.Preferred.MiddleName,
                    PREF_LNAME = applicantInfo.IdentifyingInformation.NameDetails.Preferred.LastName,
                    BIRTH_COUNTY_CD = applicantInfo.DemographicInformation.BirthInformation.BirthCounty?.CountyCode,
                    GENDER = applicantInfo.DemographicInformation.BirthInformation.Sex == "Male" ? "M" : "F",
                    BIRTH_DATE = applicantInfo.DemographicInformation.BirthInformation.BirthDate,
                    BIRTH_COUNTRY_CD = applicantInfo.DemographicInformation.BirthInformation.BirthCountry.CountryCode.ToString(),
                    BIRTH_STATE_CD = applicantInfo.DemographicInformation.BirthInformation.BirthState?.StateCode.ToString(),
                    BIRTH_CITY = applicantInfo.DemographicInformation.BirthInformation.BirthCity,
                    INST_ACTION_DESC = applicantInfo.AcademicInformation.InstitutionalActionDescription,
                    PREV_MATRIC_SCHOOL = applicantInfo.AcademicInformation.PreviousMatriculationSchoolID,
                    PREV_MATRIC_YEAR = applicantInfo.AcademicInformation.PreviousMatriculationYear,
                    CIT_COUNTRY_CD = applicantInfo.DemographicInformation.CitizenshipResidency.CitizenshipCountry?.CountryCode.ToString(),
                    PREV_MATRIC_DESC = applicantInfo.AcademicInformation.PreviousMatriculationDescription,
                    PREV_MATRIC_SCHOOL_LONG_DESC = applicantInfo.AcademicInformation?.PreviousMatriculationSchoolLongDescription,
                    FELONY_DESC = applicantInfo.CriminalHistoryAndAAMCInvestigations?.FelonyDescription,
                    NUM_DEPENDENTS = applicantInfo.DemographicInformation.GeneralDemographics.NumberOfDependents,
                    FELONY_IND = applicantInfo.CriminalHistoryAndAAMCInvestigations != null && applicantInfo.CriminalHistoryAndAAMCInvestigations.FelonyIndicator ? 1 : 0,
                    PREV_MATRIC_IND = applicantInfo.AcademicInformation.PreviousMatriculationIndicator ? 1 : 0,
                    INST_ACTION_IND = applicantInfo.AcademicInformation.InstitutionalActionIndicator ? 1 : 0,
                    MCAT_CORRECT_IND = applicantInfo.AcademicInformation.MCATScores.AdditionalMCATIntentIndicator ? 1 : 0,
                    INVESTIGATION_IND = applicantInfo.CriminalHistoryAndAAMCInvestigations != null && applicantInfo.CriminalHistoryAndAAMCInvestigations.InvestigationIndicator ? 1 : 0,
                    AAMC_ID = applicantInfo.IdentifyingInformation.ID.AAMCID,
                    CERTIFY_DATE = DateTime.Now,
                    //PREV_MATRIC_CONFLICT_IND = applicantInfo.AcademicInformation.PreviousMatriculationIndicator ? 1 : 0, // Need to verify
                    SUBMIT_DATE = applicantInfo.IdentifyingInformation.ID.ApplicationDateTime,
                    CERT_IND = 1,
                    CREATED_BY = 1,
                    LAST_UPDATE = DateTime.Now,
                    CREATED_DATE = DateTime.Now,
                    USA_LEGAL_RESIDENT_IND = applicantInfo.DemographicInformation.CitizenshipResidency.USALegalResidentIndicator ? 1 : 0,
                    ADDL_MCAT_INTENT_IND = applicantInfo.AcademicInformation.MCATScores.AdditionalMCATIntentIndicator ? 1 : 0,
                    VISA_OTHER_DESC = applicantInfo.DemographicInformation.CitizenshipResidency.VisaStatusDescription,
                    SES_IND = applicantInfo.DemographicInformation.SocioEconomicInformation.SESIndicator == "Yes" ? 1 : 0,
                    SES_VALUE = applicantInfo.DemographicInformation.SocioEconomicInformation?.EOLevel.ToString(),
                    MILITARY_SERVICE_IND = applicantInfo.MilitaryService.MilitaryServiceIndicator?.MilitaryServiceIndicator,
                    MILITARY_SERVICE_STATUS_IND = applicantInfo.MilitaryService.MilitaryServiceStatus?.MilitaryServiceStatusID,
            };

                // Need to verify below column values.
                //appPerson.SSN =
                //appPerson.SIN =
                //appPerson.APP_PHOTO_LOCATION =
                //appPerson.AUGUST_MCAT_IND =
                //appPerson.WITHDRAW_ID =
                //appPerson.AMCAS_USER_ID =
                //appPerson.APP_LAST_UPDATE =DateTime.Now;// 
                //appPerson.PREV_APPLIED_IND =
                //appPerson.APPL_STATUS_CD =
                //appPerson.APPL_STATUS_DATE = DateTime.Now;// 
                //appPerson.CBC_MILITARY_HON_DISCHARGE_IND = 
                if (applicantInfo.AcademicInformation.MCATScores.AdditionalMCATIntentDateSpecified)
                {
                    appPerson.ADDL_MCAT_INTENT_DATE = applicantInfo.AcademicInformation.MCATScores.AdditionalMCATIntentDate;
                }
                
                if (applicantInfo.CriminalHistoryAndAAMCInvestigations != null)
                {
                    appPerson.CBC_FELONY_IND = applicantInfo.CriminalHistoryAndAAMCInvestigations.FelonyIndicator ? 1 : 0;
                    appPerson.CBC_FELONY_DESC = applicantInfo.CriminalHistoryAndAAMCInvestigations.FelonyDescription;
                    appPerson.CBC_MISDEMEANOR_IND = applicantInfo.CriminalHistoryAndAAMCInvestigations.MisdemeanorIndicator ? 1 : 0;
                    appPerson.CBC_MISDEMEANOR_DESC = applicantInfo.CriminalHistoryAndAAMCInvestigations?.MisdemeanorDescription;
                    appPerson.CBC_MILITARY_DISCHARGE_IND = applicantInfo.CriminalHistoryAndAAMCInvestigations.MilitaryDischargeOtherThanHonorableIndicator ? 1 : 0;
                    appPerson.CBC_MILITARY_DISCHARGE_DESC = applicantInfo.CriminalHistoryAndAAMCInvestigations?.MilitaryDischargeOtherThanHonorableDescription;
                }
              
                appPerson.MILITARY_STATUS_OTHER_DESC = applicantInfo.MilitaryService.MilitaryServiceStatus?.MilitaryServiceStatusOtherDescription;

                return appPerson;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
