﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMCASDESDAL.DataMapping
{
    public static class DesignatedSchools
    {
        public static async Task<bool> SetDesignatedSchoolsList(ExportApplicationsApplication applicantInfo, AMCASEntities context)
        {
            try
            {
                if (applicantInfo.MedicalSchoolDesignation != null)
                {
                    foreach (var designatedSchools in applicantInfo.MedicalSchoolDesignation)
                    {
                        var tblDesignatedSchool = new DESIGNATED_SCHOOL()
                        {
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            FAP_IND = applicantInfo.DemographicInformation.GeneralDemographics.FAPIndicator,
                            PREV_APP_IND = designatedSchools.PreviousAppliedYear != null ? 1 : 0,
                            MED_INST_ID = designatedSchools.MedicalInstitutionID,
                            //AMOUNT_PAID =,//Need to verify
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            //FEE_ID =,//Need to verify
                            //DESIGNATED_STATUS_CD =,//Need to verify
                            //DOCUMENT_ID =,//Need to verify
                            //FILE_COMPLETE_IND =,//Need to verify
                            AMCAS_LETTERS_REC_IND = applicantInfo.LettersOfEvaluation != null && applicantInfo.LettersOfEvaluation?.AllAMCASLettersReceivedIndicator == true ? 1 : 0,
                            //ALL_LETTERS_REC_IND =, //Need to verify
                        };

                        context.DESIGNATED_SCHOOL.Add(tblDesignatedSchool);
                        await context.SaveChangesAsync();
                        if (designatedSchools.ApplicationProgramType != null)
                        {
                            int desSchoolId = tblDesignatedSchool.DESIGNATED_SCHOOL_ID;
                            await InsertDesignatedProgram(applicantInfo.IdentifyingInformation.ID.ApplicationYear, desSchoolId,  designatedSchools.ApplicationProgramType.ApplicationProgramTypeID, context, designatedSchools);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        private static async Task<bool> InsertDesignatedProgram(int applYear, int desSchoolId, decimal appTypeId, AMCASEntities context, ExportApplicationsApplicationMedicalSchoolDesignation medSghools)
        {
            try
            {
                var tblDesignatedProgram = new DESIGNATED_PROGRAM()
                {
                    APPL_YEAR = applYear,
                    DESIGNATED_SCHOOL_ID = desSchoolId,
                    APPL_TYPE_ID = appTypeId,
                    CREATED_BY = 1,
                    LAST_UPDATE = DateTime.Now,
                    //RESTRICTION_DATE = , //Need to verify
                    //RESTRICTION_RELEASE_CD = , //Need to verify
                };
                context.DESIGNATED_PROGRAM.Add(tblDesignatedProgram);
                await context.SaveChangesAsync();
                if (medSghools.GraduatePrograms != null)
                {
                    int designatedProgramId = tblDesignatedProgram.DESIGNATED_PROGRAM_ID;
                    await InsertDesignatedGradArea(applYear, designatedProgramId, context, medSghools);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private static async Task<bool> InsertDesignatedGradArea(int applYear, int desProgramlId, AMCASEntities context, ExportApplicationsApplicationMedicalSchoolDesignation medSghools)
        {
            try
            {
                var lstDesignatedGradArea = new List<DESIGNATED_GRAD_AREA>();
                foreach (var gradPrograms in medSghools.GraduatePrograms)
                {
                    var tblDesignatedGradArea = new DESIGNATED_GRAD_AREA()
                    {
                        APPL_YEAR = applYear,
                        DESIGNATED_PROGRAM_ID = desProgramlId,
                        GRAD_PROGRAM_ID = gradPrograms.GraduateProgramID,
                        CREATED_BY = 1,
                        LAST_UPDATE = DateTime.Now,
                    };
                    lstDesignatedGradArea.Add(tblDesignatedGradArea);
                }
                context.DESIGNATED_GRAD_AREA.AddRange(lstDesignatedGradArea);
                await context.SaveChangesAsync();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        public static async Task<bool> UpdateDesignatedSchoolsList(ExportApplicationsApplication applicantInfo, AMCASEntities context)
        {
            try
            {
                if (applicantInfo.MedicalSchoolDesignation != null)
                {
                    var desigantedSchools = context.DESIGNATED_SCHOOL.SingleOrDefault(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);

                    if (desigantedSchools != null)
                    {
                        foreach (var designatedSchools in applicantInfo.MedicalSchoolDesignation)
                        {
                            desigantedSchools.FAP_IND = applicantInfo.DemographicInformation.GeneralDemographics.FAPIndicator;
                            desigantedSchools.PREV_APP_IND = designatedSchools.PreviousAppliedYear != null ? 1 : 0;
                            desigantedSchools.MED_INST_ID = designatedSchools.MedicalInstitutionID;
                            //desigantedSchools.AMOUNT_PAID =;//Need to verify
                            //desigantedSchools.CERT_IND = 1;
                            //desigantedSchools.CREATED_BY = 1;
                            desigantedSchools.LAST_UPDATE = DateTime.Now;
                            //desigantedSchools.FEE_ID =;//Need to verify
                            //desigantedSchools.DESIGNATED_STATUS_CD =;//Need to verify
                            //desigantedSchools.DOCUMENT_ID =;//Need to verify
                            //desigantedSchools.FILE_COMPLETE_IND =;//Need to verify
                            desigantedSchools.AMCAS_LETTERS_REC_IND = applicantInfo.LettersOfEvaluation != null && applicantInfo.LettersOfEvaluation?.AllAMCASLettersReceivedIndicator == true ? 1 : 0;
                            //desigantedSchools.ALL_LETTERS_REC_IND =; //Need to verify                                                     
                            await context.SaveChangesAsync();
                            if (designatedSchools.ApplicationProgramType != null)
                            {
                                int desSchoolId = desigantedSchools.DESIGNATED_SCHOOL_ID;
                                await UpdateDesignatedProgram(applicantInfo.IdentifyingInformation.ID.ApplicationYear, desSchoolId, designatedSchools.ApplicationProgramType.ApplicationProgramTypeID, context, designatedSchools);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        private static async Task<bool> UpdateDesignatedProgram(int applYear, int desSchoolId, decimal appTypeId, AMCASEntities context, ExportApplicationsApplicationMedicalSchoolDesignation medSghools)
        {
            try
            {
                var desiganteddProgram = context.DESIGNATED_PROGRAM.SingleOrDefault(d => d.DESIGNATED_SCHOOL_ID == desSchoolId && d.APPL_YEAR == applYear);
                if (desiganteddProgram != null)
                {
                    desiganteddProgram.APPL_TYPE_ID = appTypeId;
                    desiganteddProgram.LAST_UPDATE = DateTime.Now;
                    await context.SaveChangesAsync();
                }               
                if (medSghools.GraduatePrograms != null)
                {
                    int designatedProgramId = desiganteddProgram.DESIGNATED_PROGRAM_ID;
                    
                    context.DESIGNATED_GRAD_AREA.RemoveRange(context.DESIGNATED_GRAD_AREA.Where(d => d.DESIGNATED_PROGRAM_ID == designatedProgramId && d.APPL_YEAR == applYear));
                    await context.SaveChangesAsync();

                    await InsertDesignatedGradArea(applYear, designatedProgramId, context, medSghools);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
