﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMCASDESDAL.DataMapping
{
    public static class CourseWork
    {
        public static List<COURSE_WORK> GetCourseWorksList(ExportApplicationsApplication applicantInfo)
        {
            // Add COURSE_WORK information
            var lstCourseWork = new List<COURSE_WORK>();
            try
            {
                if (applicantInfo.AcademicInformation.SchoolsAttended != null && applicantInfo.AcademicInformation.SchoolsAttended.Length > 0)
                {
                    foreach (var schoolsAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        if (schoolsAttended.Coursework != null && schoolsAttended.Coursework.Length > 0)
                        {
                            foreach (var courseWork in schoolsAttended.Coursework)
                            {
                                var tblCourseWork = new COURSE_WORK()
                                {
                                    PREREQ_IND = 0, // Need to verify
                                    CRSE_WORK_ID = courseWork.CourseWorkID,
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    LAB_IND = Convert.ToDecimal(courseWork.LabIndicator),
                                    CREDIT_HOURS = courseWork.CreditHours,
                                    ACADEMIC_YEAR = courseWork.AcademicYear,
                                    COURSE_NAME = courseWork.CourseName,
                                    COURSE_NUM = courseWork.CourseNumber,
                                    TRNSCPT_GRADE = courseWork.TranscriptGrade,
                                    SUPP_HOURS = courseWork.SupplementalHours,
                                    SCHOOL_ATTENDED_ID = schoolsAttended.SchoolAttendedID,
                                    //COURSE_QP =// Need to verify
                                    //GRADE_SYSTEM_ID =// Need to verify
                                    ACA_TERM_CD = GetAcademicTermCode(courseWork.AcademicTerm.AcademicTermDescription, applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                                    SEMESTER_HOURS = courseWork.SemesterHours,
                                    VERIFICATION_SYMBOL_ID = courseWork.VerificationMark.VerificationMarkID,
                                    ACA_STATUS_CD = courseWork.AcademicStatus.AcademicStatusCode.ToString(),
                                    CLASS_CD = GetClassCode(courseWork.CourseClassification, applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                                    AMCAS_GRADE_CD = courseWork.AMCASGrade,
                                    CERT_IND =1,
                                    CREATED_BY =1,
                                    LAST_UPDATE = DateTime.Now
                                };
                                lstCourseWork.Add(tblCourseWork);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCourseWork;
        }


        private static string GetAcademicTermCode(string academicTermDesc, int year)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    var firstOrDefault = context.REF_TERM.FirstOrDefault(a => a.ACA_TERM_DESC == academicTermDesc && a.APPL_YEAR == year);
                    if (
                        firstOrDefault != null)
                        return firstOrDefault.ACA_TERM_CD;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        private static string GetClassCode(string courseClassification, int year)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    var firstOrDefault = context.REF_CLASS.FirstOrDefault(a => a.CLASS_DESC == courseClassification && a.APPL_YEAR == year);
                    if (
                        firstOrDefault != null)
                        return firstOrDefault.CLASS_CD;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }
    }
}
