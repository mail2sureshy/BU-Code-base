﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class Address
    {
        /// <summary>
        /// Get Address type.
        /// </summary>
        /// <param name="addTypeDesc"></param>
        /// <param name="year"></param>
        /// <returns>int</returns>
        private static int GetAddressTypeId(string addTypeDesc, int year)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    var refAddressType = context.REF_ADDRESS_TYPE.FirstOrDefault(a => a.ADDR_TYPE_DESC == addTypeDesc && a.APPL_YEAR == year);
                    if (refAddressType != null)
                        return (int)refAddressType.ADDR_TYPE_ID;
                }
            }
            catch (Exception)
            {
                //InsertErrorInfo(ex.Message);
            }
            return 0;
        }
        public static List<ADDRESS> Addresses(ExportApplicationsApplication applicantInfo)
        {
            var appAddress = new List<ADDRESS>();
            try
            {
                //Add Preferred Address 
                if (applicantInfo.ContactInformation.PreferredAddress != null)
                {
                    var preferredAddress = new ADDRESS()
                    {
                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                        ADDRESS1 = applicantInfo.ContactInformation.PreferredAddress.StreetAddress.Address1,
                        ADDRESS2 = applicantInfo.ContactInformation.PreferredAddress.StreetAddress.Address2,
                        CITY = applicantInfo.ContactInformation.PreferredAddress.City,
                        POSTAL_CD = applicantInfo.ContactInformation.PreferredAddress.PostalCode,
                        DPHONE = applicantInfo.ContactInformation.PreferredAddress.DayPhone,
                        EPHONE = applicantInfo.ContactInformation.PreferredAddress.EveningPhone,
                        FAX = applicantInfo.ContactInformation.PreferredAddress.Fax,
                        EMAIL = applicantInfo.ContactInformation.PreferredAddress.Email,
                        RELATION_TYPE = null,
                        COUNTY_CD = applicantInfo.ContactInformation.PreferredAddress.County?.CountyCode,
                        RELATION_NAME = null,
                        COUNTRY_CD = applicantInfo.ContactInformation.PreferredAddress.Country?.CountryCode.ToString(),
                        ADDR_TYPE_ID = GetAddressTypeId("Preferred", applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                        CERT_IND = 1,
                        CREATED_BY =1,
                        LAST_UPDATE = DateTime.Now,
                        STATE_CD = applicantInfo.ContactInformation.PreferredAddress.State?.StateCode.ToString(),
                        DPHONE_EXT = applicantInfo.ContactInformation.PreferredAddress.DayPhoneExt,
                        EPHONE_EXT = applicantInfo.ContactInformation.PreferredAddress.EveningPhoneExt
                    };
                    appAddress.Add(preferredAddress);
                }

                //Add Permanent Address 
                if (applicantInfo.ContactInformation.PermanentAddress != null)
                {
                    var permanentAddress = new ADDRESS()
                    {
                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                        ADDRESS1 = applicantInfo.ContactInformation.PermanentAddress.StreetAddress?.Address1,
                        ADDRESS2 = applicantInfo.ContactInformation.PermanentAddress.StreetAddress?.Address2,
                        CITY = applicantInfo.ContactInformation.PermanentAddress.City,
                        POSTAL_CD = applicantInfo.ContactInformation.PermanentAddress.PostalCode,
                        DPHONE = applicantInfo.ContactInformation.PermanentAddress.DayPhone,
                        EPHONE = applicantInfo.ContactInformation.PermanentAddress.EveningPhone,
                        FAX = applicantInfo.ContactInformation.PermanentAddress.Fax,
                        EMAIL = applicantInfo.ContactInformation.PermanentAddress.Email,
                        RELATION_TYPE = null,
                        COUNTY_CD = applicantInfo.ContactInformation.PermanentAddress.County?.CountyCode,
                        RELATION_NAME = null,
                        COUNTRY_CD = applicantInfo.ContactInformation.PermanentAddress.Country?.CountryCode.ToString(),
                        ADDR_TYPE_ID = GetAddressTypeId("Permanent", applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                        CERT_IND = 1,
                        CREATED_BY =1,
                        LAST_UPDATE = DateTime.Now,
                        STATE_CD = applicantInfo.ContactInformation.PermanentAddress.State?.StateCode.ToString(),
                        DPHONE_EXT = applicantInfo.ContactInformation.PermanentAddress.DayPhoneExt,
                        EPHONE_EXT = applicantInfo.ContactInformation.PermanentAddress.EveningPhoneExt
                    };
                    appAddress.Add(permanentAddress);
                }

                // Add Alternate Address
                if (applicantInfo.ContactInformation.AlternateAddress != null)
                {
                    var alternateAddress = new ADDRESS()
                    {
                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                        ADDRESS1 = applicantInfo.ContactInformation.AlternateAddress.StreetAddress?.Address1,
                        ADDRESS2 = applicantInfo.ContactInformation.AlternateAddress.StreetAddress?.Address2,
                        CITY = applicantInfo.ContactInformation.AlternateAddress.City,
                        POSTAL_CD = applicantInfo.ContactInformation.AlternateAddress.PostalCode,
                        DPHONE = applicantInfo.ContactInformation.AlternateAddress.DayPhone,
                        EPHONE = applicantInfo.ContactInformation.AlternateAddress.EveningPhone,
                        FAX = applicantInfo.ContactInformation.AlternateAddress.Fax,
                        EMAIL = applicantInfo.ContactInformation.AlternateAddress.Email,
                        RELATION_TYPE = applicantInfo.ContactInformation.AlternateAddress.Relationship,
                        COUNTY_CD = applicantInfo.ContactInformation.AlternateAddress.County?.CountyCode,
                        RELATION_NAME = applicantInfo.ContactInformation.AlternateAddress.ContactName,
                        COUNTRY_CD = applicantInfo.ContactInformation.AlternateAddress.Country?.CountryCode.ToString(),
                        ADDR_TYPE_ID = GetAddressTypeId("Alternate", applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                        CERT_IND = 1,
                        CREATED_BY =1,
                        LAST_UPDATE = DateTime.Now,
                        STATE_CD = applicantInfo.ContactInformation.AlternateAddress.State?.StateCode.ToString(),
                        DPHONE_EXT = applicantInfo.ContactInformation.AlternateAddress.DayPhoneExt,
                        EPHONE_EXT = applicantInfo.ContactInformation.AlternateAddress.EveningPhoneExt
                    };
                    appAddress.Add(alternateAddress);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return appAddress;
        }

        public static ADDRESS PreferredAddress(ExportApplicationsApplication applicantInfo)
        {
            try
            {
                //Add Preferred Address 
                if (applicantInfo.ContactInformation.PreferredAddress != null)
                {
                    var preferredAddress = new ADDRESS()
                    {
                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                        ADDRESS1 = applicantInfo.ContactInformation.PreferredAddress.StreetAddress.Address1,
                        ADDRESS2 = applicantInfo.ContactInformation.PreferredAddress.StreetAddress.Address2,
                        CITY = applicantInfo.ContactInformation.PreferredAddress.City,
                        POSTAL_CD = applicantInfo.ContactInformation.PreferredAddress.PostalCode,
                        DPHONE = applicantInfo.ContactInformation.PreferredAddress.DayPhone,
                        EPHONE = applicantInfo.ContactInformation.PreferredAddress.EveningPhone,
                        FAX = applicantInfo.ContactInformation.PreferredAddress.Fax,
                        EMAIL = applicantInfo.ContactInformation.PreferredAddress.Email,
                        RELATION_TYPE = null,
                        COUNTY_CD = applicantInfo.ContactInformation.PreferredAddress.County?.CountyCode,
                        RELATION_NAME = null,
                        COUNTRY_CD = applicantInfo.ContactInformation.PreferredAddress.Country?.CountryCode.ToString(),
                        ADDR_TYPE_ID =
                            GetAddressTypeId("Preferred", applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                        CERT_IND = 1,
                        CREATED_BY =1,
                        LAST_UPDATE = DateTime.Now,
                        STATE_CD = applicantInfo.ContactInformation.PreferredAddress.State?.StateCode.ToString(),
                        DPHONE_EXT = applicantInfo.ContactInformation.PreferredAddress.DayPhoneExt,
                        EPHONE_EXT = applicantInfo.ContactInformation.PreferredAddress.EveningPhoneExt
                    };
                    return preferredAddress;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        public static ADDRESS PermanentAddress(ExportApplicationsApplication applicantInfo)
        {
            try
            {
                //Add Permanent Address 
                if (applicantInfo.ContactInformation.PermanentAddress != null)
                {
                    var permanentAddress = new ADDRESS()
                    {
                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                        ADDRESS1 = applicantInfo.ContactInformation.PermanentAddress.StreetAddress?.Address1,
                        ADDRESS2 = applicantInfo.ContactInformation.PermanentAddress.StreetAddress?.Address2,
                        CITY = applicantInfo.ContactInformation.PermanentAddress.City,
                        POSTAL_CD = applicantInfo.ContactInformation.PermanentAddress.PostalCode,
                        DPHONE = applicantInfo.ContactInformation.PermanentAddress.DayPhone,
                        EPHONE = applicantInfo.ContactInformation.PermanentAddress.EveningPhone,
                        FAX = applicantInfo.ContactInformation.PermanentAddress.Fax,
                        EMAIL = applicantInfo.ContactInformation.PermanentAddress.Email,
                        RELATION_TYPE = null,
                        COUNTY_CD = applicantInfo.ContactInformation.PermanentAddress.County?.CountyCode,
                        RELATION_NAME = null,
                        COUNTRY_CD = applicantInfo.ContactInformation.PermanentAddress.Country?.CountryCode.ToString(),
                        ADDR_TYPE_ID =
                            GetAddressTypeId("Permanent", applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                        CERT_IND = 1,
                        CREATED_BY =1,
                        LAST_UPDATE = DateTime.Now,
                        STATE_CD = applicantInfo.ContactInformation.PermanentAddress.State?.StateCode.ToString(),
                        DPHONE_EXT = applicantInfo.ContactInformation.PermanentAddress.DayPhoneExt,
                        EPHONE_EXT = applicantInfo.ContactInformation.PermanentAddress.EveningPhoneExt
                    };
                    return permanentAddress;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }

        public static ADDRESS AlternateAddress(ExportApplicationsApplication applicantInfo)
        {
            try
            {
                // Add Alternate Address
                if (applicantInfo.ContactInformation.AlternateAddress != null)
                {
                    var alternateAddress = new ADDRESS()
                    {
                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                        ADDRESS1 = applicantInfo.ContactInformation.AlternateAddress.StreetAddress?.Address1,
                        ADDRESS2 = applicantInfo.ContactInformation.AlternateAddress.StreetAddress?.Address2,
                        CITY = applicantInfo.ContactInformation.AlternateAddress.City,
                        POSTAL_CD = applicantInfo.ContactInformation.AlternateAddress.PostalCode,
                        DPHONE = applicantInfo.ContactInformation.AlternateAddress.DayPhone,
                        EPHONE = applicantInfo.ContactInformation.AlternateAddress.EveningPhone,
                        FAX = applicantInfo.ContactInformation.AlternateAddress.Fax,
                        EMAIL = applicantInfo.ContactInformation.AlternateAddress.Email,
                        RELATION_TYPE = applicantInfo.ContactInformation.AlternateAddress.Relationship,
                        COUNTY_CD = applicantInfo.ContactInformation.AlternateAddress.County?.CountyCode,
                        RELATION_NAME = applicantInfo.ContactInformation.AlternateAddress.ContactName,
                        COUNTRY_CD = applicantInfo.ContactInformation.AlternateAddress.Country?.CountryCode.ToString(),
                        ADDR_TYPE_ID = GetAddressTypeId("Alternate", applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                        CERT_IND = 1,
                        CREATED_BY =1,
                        LAST_UPDATE = DateTime.Now,
                        STATE_CD = applicantInfo.ContactInformation.AlternateAddress.State?.StateCode.ToString(),
                        DPHONE_EXT = applicantInfo.ContactInformation.AlternateAddress.DayPhoneExt,
                        EPHONE_EXT = applicantInfo.ContactInformation.AlternateAddress.EveningPhoneExt
                    };
                    return alternateAddress;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }
    }
}
