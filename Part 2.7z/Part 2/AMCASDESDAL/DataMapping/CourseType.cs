﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class CourseType
    {
        public static List<COURSE_TYPE> GetCourseTypeList(ExportApplicationsApplication applicantInfo)
        {
            // Add COURSE_TYPE information
            var lstCourseType = new List<COURSE_TYPE>();
            try
            {
                if (applicantInfo.AcademicInformation.SchoolsAttended != null && applicantInfo.AcademicInformation.SchoolsAttended.Length > 0)
                {
                    foreach (var schoolsAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        if (schoolsAttended.Coursework != null && schoolsAttended.Coursework.Length > 0)
                        {
                            foreach (var courseTypes in schoolsAttended.Coursework)
                            {
                                if (courseTypes.CourseType != null && courseTypes.CourseType.Length > 0)
                                {
                                    foreach (var courseType in courseTypes.CourseType)
                                    {
                                        var tblCourseType = new COURSE_TYPE()
                                        {
                                            CRSE_WORK_ID = courseTypes.CourseWorkID,
                                            CREATED_BY = 1,
                                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                            COURSE_TYPE_CD = courseType.CourseTypeCode.ToString(),
                                            LAST_UPDATE = DateTime.Now
                                        };
                                        lstCourseType.Add(tblCourseType);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCourseType;
        }
    }
}
