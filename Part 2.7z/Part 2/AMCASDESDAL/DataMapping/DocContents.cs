﻿using System;
using System.Collections.Generic;
using System.Linq;
using AMCASDESModels;

namespace AMCASDESDAL.DataMapping
{
    public static class DocContents
    {
        public static IEnumerable<DocumentContent> GetDocumnetContents(int year)
        {
            try
            {
                var context = new AMCASEntities();
                var result =
                    (from a in context.DOCUMENT_RECEIPT
                     join b in context.REF_DOCUMENT_TYPE on a.DocumentTypeID equals b.DocumentTypeID
                     where b.Active_Ind == 1 && a.DocumentContentID == null && a.APPL_YEAR == year
                     select new DocumentContent()
                     {
                         DocumentReceiptId = a.DocumentReceiptID,
                         DocumentType = b.DocumentType,
                         ApplicantPersonId = a.APPL_PERSON_ID,
                         ApplicantYear = a.APPL_YEAR,
                         DocumentContentId = a.DocumentContentID,
                         DocumentContentType = b.DocumentContentType
                     });
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //DocumentContentData

        public static DOCUMENT_CONTENT SaveDocumnetContent(DocumentContentData data)
        {
            try
            {
                var tblDocContent = new DOCUMENT_CONTENT()
                {
                    DocumentContentType = data.DocumentContentType,
                    DocumentContent = data.DocumentContent,
                    DocumentSize = data.DocumentSize,
                    CreateDate = DateTime.Now
                };
                return tblDocContent;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
