﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace AMCASDESDAL.DataMapping
{
    public static class AmcasAction
    {
        /// <summary>
        /// Get AMCAS actions as a string
        /// </summary>
        /// <param name="appYear"></param>
        /// <param name="medicalInstId"></param>
        /// <returns>string</returns>
        public static async Task<string> GetAmcasActions(int appYear, int medicalInstId)
        {
            try
            {
                var action = new AdmissionActionsRequest();
                using (var context = new AMCASEntities())
                {
                    var result = (context.LOCAL_AAUU.AsNoTracking().AsEnumerable()
                        .Where(p => p.APPL_YEAR == appYear && p.PROCESSED_IND == 0)
                        .Select(p => new AdmissionActionsRequestAction
                        {
                            AAMCID = (int)p.AAMC_ID,
                            ApplicationYear = (short)p.APPL_YEAR,
                            //MedicalInstitutionId = medicalInstId,
                            MedicalInstitutionId = Convert.ToInt32(p.CAMPUS_CD),
                            ActionCode = (ActionCodeType)Enum.Parse(typeof(ActionCodeType), p.ADMISSION_ACTION_CD),
                            ProgramType = p.APPL_TYPE_ID.ToString(),
                            CampusCode = p.CAMPUS_CD.ToString(),
                            ProjectedGraduationDateSpecified = p.GRADUATED_DATETIME != null,
                            ProjectedGraduationDate = p.GRADUATED_DATETIME,
                            ActionEffectiveDateSpecified = p.TIMESTAMP != null,
                            ActionEffectiveDate = p.TIMESTAMP,
                            DeleteIndicatorSpecified = p.DELROW == "1",
                            DeleteIndicator = p.DELROW == "1"
                        })).ToList();

                    action.Action = result.ToArray();
                }

                string xmlString;
                var xsSubmit = new XmlSerializer(typeof(AdmissionActionsRequest));
                using (StringWriter writer = new Utf8StringWriter())
                {
                    xsSubmit.Serialize(writer, action);
                    xmlString = writer.ToString();
                }
                return xmlString;
            }
            catch (Exception ex)
            {
                await InsertEvenLogInformation(ex.Message);
                return "";
            }
        }


        /// <summary>
        /// Insert or Update Amcas actions after post
        /// </summary>
        /// <param name="actionResponse"></param>
        /// <returns>int</returns>
        public static async Task<int> UpdateAmcasActionResults(AdmissionActionsResponseActionResult actionResponse)
        {
            try
            {
                if (actionResponse != null && (actionResponse.ResultStatus == ResultStatusType.ERROR ||
                                                actionResponse.ResultStatus == ResultStatusType.UNAUTHORIZED ||
                                                actionResponse.ResultStatus == ResultStatusType.SYSTEM_ERROR))
                {
                    using (var context = new AMCASEntities())
                    {
                        var tbLocalAauu = context.LOCAL_AAUU.SingleOrDefault(
                                          l => l.AAMC_ID == actionResponse.AAMCID &&
                                          l.ADMISSION_ACTION_CD == actionResponse.ActionCode.ToString());
                        if (tbLocalAauu != null)
                        {
                            tbLocalAauu.PROCESSED_IND = 1;
                            tbLocalAauu.SUCCESS_IND = 0;
                            tbLocalAauu.ERROR_DESC = actionResponse.ResultStatusMessage;
                        }
                        return await context.SaveChangesAsync();
                    }
                }
                else if (actionResponse != null && actionResponse.ResultStatus == ResultStatusType.SUCCESS)
                {
                    using (var context = new AMCASEntities())
                    {
                        // If delete action is Success delete that record from LOCAL_AAUU table.
                        var tbLocalAauu = context.LOCAL_AAUU.SingleOrDefault(
                                 l => l.AAMC_ID == actionResponse.AAMCID &&
                                 l.ADMISSION_ACTION_CD == actionResponse.ActionCode.ToString());

                        context.LOCAL_AAUU.Remove(tbLocalAauu);
                        
                        // Delete action is Success and LOCAL_AAUU table DELROW == "1", delete this record from ADMISSIONS_ACTION table also
                        if (tbLocalAauu != null && tbLocalAauu.DELROW == "1")
                        {
                            decimal schoolId = GetDesSchoolId(actionResponse.AAMCID, actionResponse.ApplicationYear);

                            var tblAdmissionAction =
                                context.ADMISSIONS_ACTION.SingleOrDefault(
                                    a => a.APPL_YEAR == actionResponse.ApplicationYear &&
                                         a.ADMISSION_ACTION_CD == actionResponse.ActionCode.ToString() && 
                                         a.DESIGNATED_SCHOOL_ID == schoolId);

                                context.ADMISSIONS_ACTION.Remove(tblAdmissionAction);
                        }
                        else
                        {
                            // If DELROW == "0" from LOCAL_AAUU, Add this record into ADMISSIONS_ACTION atble.
                            var tblAdmissionAction = new ADMISSIONS_ACTION();

                            decimal desSchoolId = GetDesSchoolId(actionResponse.AAMCID, actionResponse.ApplicationYear);

                            tblAdmissionAction.ACTION_DATE = DateTime.Now;
                            tblAdmissionAction.MATRICULATED_DATE = DateTime.Now;
                            tblAdmissionAction.GRADUATED_DATE = DateTime.Now;
                            tblAdmissionAction.CREATED_BY = 1;
                            tblAdmissionAction.LAST_UPDATE = DateTime.Now;
                            //tblAdmissionAction.MED_INST_CAMPUS_ID = actionResponse.MedicalInstitutionId;
                            if (desSchoolId != 0)
                            {
                                tblAdmissionAction.DESIGNATED_SCHOOL_ID = (int)desSchoolId;

                                decimal designatedProgramId = GetDesProgramId(desSchoolId, actionResponse.ApplicationYear);

                                if(designatedProgramId != 0)
                                    tblAdmissionAction.DESIGNATED_PROGRAM_ID = (int)designatedProgramId;
                            }

                            
                            tblAdmissionAction.APPL_YEAR = actionResponse.ApplicationYear;
                            tblAdmissionAction.ADMISSION_ACTION_CD = actionResponse.ActionCode.ToString();
                            tblAdmissionAction.USERNAME = "1";

                            context.ADMISSIONS_ACTION.Add(tblAdmissionAction);
                        }
                        return await context.SaveChangesAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                await InsertEvenLogInformation(ex.Message);
                return 0;
            }
            return 1;
        }

        private static decimal GetDesSchoolId(long applicatId, int year)
        {
            using (var context = new AMCASEntities())
            {
                var result = (from a in context.DESIGNATED_SCHOOL.AsNoTracking()
                    join b in context.APPLICANT_PERSON.AsNoTracking() on a.APPL_PERSON_ID equals b.APPL_PERSON_ID
                    where a.APPL_YEAR == b.APPL_YEAR && b.AAMC_ID == applicatId && a.APPL_YEAR == year
                    select (a.DESIGNATED_SCHOOL_ID)).SingleOrDefault();
                return result;
            }
        }

        private static decimal GetDesProgramId(decimal designatedSchoolId, int year)
        {
            using (var context = new AMCASEntities())
            {
                var result = (from a in context.DESIGNATED_PROGRAM.AsNoTracking()
                              where a.DESIGNATED_SCHOOL_ID == designatedSchoolId && a.APPL_YEAR == year
                              select (a.DESIGNATED_PROGRAM_ID)).SingleOrDefault();
                return result;
            }
        }

        /// <summary>
        /// Insert Error log information
        /// </summary>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public static async Task<bool> InsertEvenLogInformation(string message)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    DESEventLog evenLog = new DESEventLog
                    {
                        Message = message,
                        Date = DateTime.Now
                    };
                    context.DESEventLogs.Add(evenLog);
                    await context.SaveChangesAsync();
                }
            }
            catch
            {
                return false;
            }
            return true;
        }
    }


    /// <summary>
    ///  Override default UTF 16 encoding.
    /// </summary>
    public class Utf8StringWriter : StringWriter
    {
        public override Encoding Encoding => Encoding.UTF8;
    }
}
