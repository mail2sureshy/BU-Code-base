﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class AlternateId
    {
        private static decimal GetRefAltId(string altIdType, int year)
        {
            using (var context = new AMCASEntities())
            {
               return context.REF_ALT_ID_TYPE.FirstOrDefault(a => a.ALT_ID_TYPE_DESC == altIdType && a.APPL_YEAR == year).REF_ALT_ID_TYPE_ID;
            }
        }

        public static List<ALTERNATE_ID> AlternateIds(ExportApplicationsApplication applicantInfo)
        {
            var alternateIds = new List<ALTERNATE_ID>();
            try
            {
                if (applicantInfo.IdentifyingInformation.ID.AlternateID != null)
                {
                    foreach (var alternateId in applicantInfo.IdentifyingInformation.ID.AlternateID)
                    {
                        var tblAlternateId = new ALTERNATE_ID()
                        {
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            REF_ALT_ID_TYPE_ID = GetRefAltId(alternateId.AlternateIDType, applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                            ALT_ID_DESC = alternateId.AlternateIDValue,
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now
                        };
                        alternateIds.Add(tblAlternateId);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return alternateIds;
        }
    }
}
