﻿using System;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class DisadvantagedStatus
    {
        public static DISADVANTAGED_STATUS GetDisadvantagedStatus(ExportApplicationsApplication applicantInfo)
        {
            try
            {
                var disadvantagedStatus = new DISADVANTAGED_STATUS()
                {
                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                    APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                    DISADVANTAGED_IND = applicantInfo.DemographicInformation.SelfReportedDisadvantagedStatus.DisadvantagedIndicator ? 1 : 0,
                    CITY = applicantInfo.DemographicInformation.Childhood?.City,
                    COUNTY_CD = applicantInfo.DemographicInformation.Childhood?.County?.CountyCode,
                    COUNTRY_CD = applicantInfo.DemographicInformation.Childhood?.Country?.CountryCode.ToString(),
                    MED_UNDRSVRD_IND = applicantInfo.DemographicInformation.Childhood?.MedicallyUnderServedSelfReported == "No" ? 0 : 1,
                    ASST_PRGMS_IND = applicantInfo.DemographicInformation.Childhood?.FederalOrStateAssistanceProgramIndicator == "No" ? 0 : 1,
                    PD_EMPLMT_IND = applicantInfo.DemographicInformation.Childhood?.PaidEmploymentIndicator == "No" ? 0 : 1,
                    CONTR_INCOME_IND = applicantInfo.DemographicInformation.Childhood?.ContributeIncomeIndicator == "No" ? 0 : 1,
                    HOUSEHLD_TOTAL = applicantInfo.DemographicInformation.Childhood?.HouseholdSize,
                    ACADEMIC_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.AcademicPercent,
                    NEED_BASED_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.NeedBasedScholarshipPercent,
                    STUDENT_LOAN_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.StudentLoanPercent,
                    OTHER_LOAN_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.OtherLoanPercent,
                    FAMILY_CONTR_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.FamilyContributionPercent,
                    APP_CONTR_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.ApplicantContributionPercent,
                    OTHER_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.OtherPercent,
                    HRDSHPS_IND = !string.IsNullOrEmpty(applicantInfo.DemographicInformation.SelfReportedDisadvantagedStatus?.DisadvantagedComments) ? 1 : 0,
                    TOTAL_PERCENT = applicantInfo.DemographicInformation.Childhood?.EducationFunding?.TotalPercent,
                    REF_INCOME_ID = GetRefIncomeId(applicantInfo.DemographicInformation.Childhood?.FamilyIncomeLevel, applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                    HRDSHP_COMMENTS = applicantInfo.DemographicInformation.SelfReportedDisadvantagedStatus?.DisadvantagedComments,
                    REF_GEO_CAT_ID = applicantInfo.DemographicInformation.Childhood?.GeographicCategory?.GeographicCategoryID,
                    STATE_CD = applicantInfo.DemographicInformation.Childhood?.State?.StateCode.ToString(),
                    CERT_IND = 1,
                    CREATED_BY = 1,
                    LAST_UPDATE = DateTime.Now,
                    PELL_GRANT_IND = applicantInfo.DemographicInformation.SocioEconomicInformation?.PellGrantIndicator == "No" ? 0 : 1
                };
                return disadvantagedStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static decimal GetRefIncomeId(string familyIncomeLevel, int appYear)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    var firstOrDefault = context.REF_INCOME.FirstOrDefault(a => a.INCOME_DESC == familyIncomeLevel && a.APPL_YEAR == appYear);
                    if (firstOrDefault != null)
                        return firstOrDefault.REF_INCOME_ID;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return 1;
        }
    }
}
