﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class MajorMinor
    {
        public static List<MAJOR_MINOR> MajorMinorsList(ExportApplicationsApplication applicantInfo)
        {
            // Add MAJOR_MINOR information
            var lstMajorMinors = new List<MAJOR_MINOR>();
            try
            {
                if (applicantInfo.AcademicInformation.SchoolsAttended != null)
                {
                    foreach (var schoolsAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        // Major information
                        if (schoolsAttended?.Major != null)
                        {
                            foreach (var major in schoolsAttended.Major)
                            {
                                if (major != null)
                                {
                                    var tblmajor = new MAJOR_MINOR()
                                    {
                                        MAJOR_MINOR_ID = (int)major.MajorID,
                                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                        MODIFIED_MAJOR = major.MajorDescription,
                                        MAJOR_CD = major.MajorCode.ToString(),
                                        MINOR_INDICATOR = 0,
                                        CERT_IND = 1,
                                        CREATED_BY = 1,
                                        SCHOOL_ATTENDED_ID = schoolsAttended.SchoolAttendedID,
                                        LAST_UPDATE = DateTime.Now,
                                    };
                                    lstMajorMinors.Add(tblmajor);
                                }
                            }
                        }
                        // Minor information.
                        if (schoolsAttended?.Minor != null)
                        {
                            foreach (var minor in schoolsAttended.Minor)
                            {
                                if (minor != null)
                                {
                                    var tblminor = new MAJOR_MINOR()
                                    {
                                        MAJOR_MINOR_ID = (int)minor.MinorID,
                                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                        MODIFIED_MAJOR = minor.MinorDescription,
                                        MAJOR_CD = minor.MinorCode.ToString(),
                                        MINOR_INDICATOR = 1,
                                        CERT_IND = 1,
                                        CREATED_BY = 1,
                                        SCHOOL_ATTENDED_ID = schoolsAttended.SchoolAttendedID,
                                        LAST_UPDATE = DateTime.Now,
                                    };
                                    lstMajorMinors.Add(tblminor);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMajorMinors;
        }
    }
}
