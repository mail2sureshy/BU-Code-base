﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class Mcat2015
    {
        public static List<MCAT_SCORE_2015> Mcat2015List(ExportApplicationsApplication applicantInfo)
        {
            var listMcat2015 = new List<MCAT_SCORE_2015>();
            try
            {
                if (applicantInfo.AcademicInformation.MCATScores?.MCATScore2015 != null
                   && applicantInfo.AcademicInformation.MCATScores.MCATScore2015.Length > 0)
                {
                    foreach (var mcat2015 in applicantInfo.AcademicInformation.MCATScores.MCATScore2015)
                    {
                        var tblMcat2015Score = new MCAT_SCORE_2015();
                            tblMcat2015Score.appl_year = applicantInfo.IdentifyingInformation.ID.ApplicationYear;
                            tblMcat2015Score.appl_person_id = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID;
                            tblMcat2015Score.aamc_id = applicantInfo.IdentifyingInformation.ID.AAMCID;
                            tblMcat2015Score.cert_ind = 1;
                            tblMcat2015Score.mcat_id = mcat2015.MCATImageID;
                            tblMcat2015Score.mcat_series = mcat2015.SeriesNumber;
                            if (!string.IsNullOrEmpty(Convert.ToString(mcat2015.TestDate)))
                            {
                                tblMcat2015Score.test_DATE = mcat2015.TestDate;
                            }
                            tblMcat2015Score.cpbs_score = mcat2015.CPBSScore;
                            tblMcat2015Score.cb_cpbs_low = mcat2015.CPBSSectionDetails?.ConfidenceBandLow;
                            tblMcat2015Score.cb_cpbs_high = mcat2015.CPBSSectionDetails?.ConfidenceBandHigh;
                            tblMcat2015Score.cpbs_percentile = mcat2015.CPBSSectionDetails?.PercentileRank;
                            tblMcat2015Score.cars_score = mcat2015.CARSScore;
                            tblMcat2015Score.cb_cars_low = mcat2015.CARSSectionDetails?.ConfidenceBandLow;
                            tblMcat2015Score.cb_cars_high = mcat2015.CARSSectionDetails?.ConfidenceBandHigh;
                            tblMcat2015Score.cars_percentile = mcat2015.CARSSectionDetails?.PercentileRank;
                            tblMcat2015Score.bbfl_score = mcat2015.BBFLScore;
                            tblMcat2015Score.cb_bbfl_low = mcat2015.BBFLSectionDetails?.ConfidenceBandLow;
                            tblMcat2015Score.cb_bbfl_high = mcat2015.BBFLSectionDetails?.ConfidenceBandHigh;
                            tblMcat2015Score.bbfl_percentile = mcat2015.BBFLSectionDetails?.PercentileRank;
                            tblMcat2015Score.psbb_score = mcat2015.PSBBScore;
                            tblMcat2015Score.cb_psbb_low = mcat2015.PSBBSectionDetails?.ConfidenceBandLow;
                            tblMcat2015Score.cb_psbb_high = mcat2015.PSBBSectionDetails?.ConfidenceBandLow;
                            tblMcat2015Score.psbb_percentile = mcat2015.PSBBSectionDetails?.PercentileRank;
                            tblMcat2015Score.total_score = mcat2015.TotalScore;
                            tblMcat2015Score.cb_total_low = mcat2015.TotalSectionDetails?.ConfidenceBandLow;
                            tblMcat2015Score.cb_total_high = mcat2015.TotalSectionDetails?.ConfidenceBandLow;
                            tblMcat2015Score.total_percentile = mcat2015.TotalSectionDetails?.PercentileRank;
                            tblMcat2015Score.created_by = 1;
                            tblMcat2015Score.last_update = DateTime.Now;
                            //tblMcat2015Score.advisor_release =// Need to verify
                            //tblMcat2015Score.med_mar_release =// Need to verify
                            //tblMcat2015Score.recruitment_release =// Need to verify
                            if (!string.IsNullOrEmpty(Convert.ToString(mcat2015.PercentileEffectiveDate)) && mcat2015.PercentileEffectiveDate.ToString() != "1/1/0001 12:00:00 AM")
                            {
                                tblMcat2015Score.PERCENTILE_EFFECTIVE_DATE = mcat2015.PercentileEffectiveDate;
                            }
                        
                        listMcat2015.Add(tblMcat2015Score);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listMcat2015;
        }

        public static List<MCAT_SCORE_2015_ARCHIVE> GetMcat2015ArchivesList(ExportApplicationsApplication applicantInfo, int sessonId)
        {
            // Add 2015 Archive information
            var lstMcat2015Arc = new List<MCAT_SCORE_2015_ARCHIVE>();
            try
            {// Archive GPA's data into GPA_ARCHIVE table
                if (applicantInfo.AcademicInformation.GPAs != null)
                {
                    AMCASEntities context = new AMCASEntities();
                    var mcat2015Scores = context.MCAT_SCORE_2015.Where(d => d.appl_person_id == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                                                                d.appl_year == applicantInfo.IdentifyingInformation.ID.ApplicationYear);
                    if (mcat2015Scores.Any())
                    {
                        foreach (var mcat2015Score in mcat2015Scores)
                        {
                            var tblMcas2015Archive = new MCAT_SCORE_2015_ARCHIVE()
                            {
                                DESSessionID = sessonId,
                                appl_year = mcat2015Score.appl_year,
                                appl_person_id = mcat2015Score.appl_person_id,
                                aamc_id = mcat2015Score.aamc_id,
                                cert_ind = mcat2015Score.cert_ind,
                                mcat_id = mcat2015Score.mcat_id,
                                mcat_series = mcat2015Score.mcat_series,
                                test_DATE = mcat2015Score.test_DATE,
                                cpbs_score = mcat2015Score.cpbs_score,
                                cb_cpbs_low = mcat2015Score.cb_cpbs_low,
                                cb_cpbs_high = mcat2015Score.cb_cpbs_high,
                                cpbs_percentile = mcat2015Score.cpbs_percentile,
                                cars_score = mcat2015Score.cars_score,
                                cb_cars_low = mcat2015Score.cb_cars_low,
                                cb_cars_high = mcat2015Score.cb_cars_high,
                                cars_percentile = mcat2015Score.cars_percentile,
                                bbfl_score = mcat2015Score.bbfl_score,
                                cb_bbfl_low = mcat2015Score.cb_bbfl_low,
                                cb_bbfl_high = mcat2015Score.cb_bbfl_high,
                                bbfl_percentile = mcat2015Score.bbfl_percentile,
                                psbb_score = mcat2015Score.psbb_score,
                                cb_psbb_low = mcat2015Score.cb_psbb_low,
                                cb_psbb_high = mcat2015Score.cb_psbb_high,
                                psbb_percentile = mcat2015Score.psbb_percentile,
                                total_score = mcat2015Score.total_score,
                                cb_total_low = mcat2015Score.cb_total_low,
                                cb_total_high = mcat2015Score.cb_total_high,
                                total_percentile = mcat2015Score.total_percentile,
                                created_by = mcat2015Score.created_by,
                                create_date = DateTime.Now,
                                last_update = mcat2015Score.last_update,
                                advisor_release = mcat2015Score.advisor_release,
                                med_mar_release = mcat2015Score.med_mar_release,
                                recruitment_release = mcat2015Score.recruitment_release,
                                PERCENTILE_EFFECTIVE_DATE = mcat2015Score.PERCENTILE_EFFECTIVE_DATE
                            };
                            lstMcat2015Arc.Add(tblMcas2015Archive);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMcat2015Arc;
        }
    }
}
