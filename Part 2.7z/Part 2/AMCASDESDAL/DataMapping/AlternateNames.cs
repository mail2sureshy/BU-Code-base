﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class AlternateNames
    {
        public static List<NAME> GetAlternateNamesList(ExportApplicationsApplication applicantInfo)
        {
            // Add NAME information 
            var lstAlternateNames = new List<NAME>();
            try
            {
                if (applicantInfo.IdentifyingInformation.NameDetails.Alternate != null && applicantInfo.IdentifyingInformation.NameDetails.Alternate.Length > 0)
                {
                    foreach (var alternateNames in applicantInfo.IdentifyingInformation.NameDetails.Alternate)
                    {
                        var alternateName = new NAME()
                        {
                            NAME_ID = (int)alternateNames.NameID,
                            ALT_FNAME = alternateNames.FirstName,
                            ALT_MNAME = alternateNames.MiddleName,
                            ALT_LNAME = alternateNames.LastName,
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID
                        };
                        lstAlternateNames.Add(alternateName);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAlternateNames;
        }
    }
}
