﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class Ethnicitys
    {
        public static List<ETHNICITY> EthnicitysList(ExportApplicationsApplication applicantInfo)
        {
            // Add ETHNICITY information
            var lstEthnicitys = new List<ETHNICITY>();
            try
            {
                if (applicantInfo.DemographicInformation.SelfIdentification.HispanicEthnicityIndicator && 
                    applicantInfo.DemographicInformation.SelfIdentification?.HispanicLatinoOrOfSpanishOrigin != null)
                {
                    foreach (var ethnicity in applicantInfo.DemographicInformation.SelfIdentification.HispanicLatinoOrOfSpanishOrigin)
                    {
                        var tblEthnicity = new ETHNICITY()
                        {
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            MOD_DESC = ethnicity.EthnicityDescription,
                            ETHNICITY_CD = ethnicity.EthnicityCode.ToString(),
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID
                        };
                        lstEthnicitys.Add(tblEthnicity);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstEthnicitys;
        }
    }
}
