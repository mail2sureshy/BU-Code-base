﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class Experiences
    {
        public static List<EXPERIENCE> ExperiencesList(ExportApplicationsApplication applicantInfo)
        {
            // Add SCHOOL_ATTENDED information
            var lstExperiences = new List<EXPERIENCE>();
            try
            {
                if (applicantInfo.Experiences != null)
                {
                    foreach (var experience in applicantInfo.Experiences)
                    {
                        var tblexperience = new EXPERIENCE()
                        {
                            EXPERIENCE_ID = experience.ExperienceID,
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID
                        };

                        if (experience.DateRange.Length > 0 && experience.DateRange[0].StartDate != null)
                        {
                            tblexperience.START_DT = experience.DateRange[0].StartDate;
                            tblexperience.FIRST_TOTAL_HRS = experience.DateRange[0].TotalHours;
                        }
                        if (experience.DateRange.Length > 0 && experience.DateRange[0].EndDateSpecified)
                        {
                            tblexperience.END_DT = experience.DateRange[0].EndDate;
                        }
                        //tblexperience.AVG_HRS_PER_WEEK = ; //Need to verify
                        tblexperience.ORG_NAME = experience.Organization.Name;
                        tblexperience.CITY = experience.Organization.City;
                        tblexperience.CONTACT_FNAME = experience.ContactName.FirstName;
                        tblexperience.CONTACT_LNAME = experience.ContactName.LastName;
                        tblexperience.CONTACT_TITLE = experience.ContactTitle;
                        tblexperience.CONTACT_PHONE = experience.ContactPhone;
                        tblexperience.CONTACT_EMAIL = experience.ContactEmail;
                        tblexperience.EXP_TITLE = null; //
                        tblexperience.EXP_DESC = experience.ExperienceDescription;
                        tblexperience.EXP_NAME = experience.ExperienceName;
                        tblexperience.REF_EXP_TYPE_ID = experience.ExperienceType.ExperienceTypeID;
                        tblexperience.CERT_IND = 1;
                        tblexperience.CREATED_BY = 1;
                        tblexperience.LAST_UPDATE = DateTime.Now;
                        if (experience.Organization.Country != null)
                        {
                            tblexperience.COUNTRY_CD = experience.Organization.Country.CountryCode.ToString();
                        }

                        if (experience.Organization.State != null)
                        {
                            tblexperience.STATE_CD = experience.Organization.State.StateCode.ToString();
                        }
                        tblexperience.MEANINGFULL_EXP_IND = experience.MeaningfulExperienceIndicator ? 1 : 0;
                        tblexperience.MEANINGFULL_EXP_DESC = experience.MeaningfulExperienceDescription;
                        tblexperience.REPEATED_EXP_IND = 0;
                        if (experience.DateRange.Length > 1 && experience.DateRange[1].StartDate != null && Convert.ToString(experience.DateRange[1].StartDate) != "1/1/0001 12:00:00 AM")
                        //if (experience.DateRange.Length > 1 && experience.DateRange[1].StartDate != null)
                        {
                            tblexperience.SECOND_START_DT = experience.DateRange[1].StartDate;
                            tblexperience.SECOND_TOTAL_HRS = experience.DateRange[1].TotalHours;
                        }

                        if (experience.DateRange.Length > 1 && experience.DateRange[1].EndDateSpecified && experience.DateRange[1].EndDateSpecified)
                        {
                            tblexperience.SECOND_END_DT = experience.DateRange[1].EndDate;
                        }

                        if (experience.DateRange.Length > 2 && experience.DateRange[2].StartDate != null && Convert.ToString(experience.DateRange[2].StartDate) != "1/1/0001 12:00:00 AM")
                        //if (experience.DateRange.Length > 2 && experience.DateRange[2].StartDate != null)
                        {
                            tblexperience.THIRD_START_DT = experience.DateRange[2].StartDate;
                            tblexperience.THIRD_TOTAL_HRS = experience.DateRange[2].TotalHours;
                        }
                        if (experience.DateRange.Length > 2 && experience.DateRange[2].EndDateSpecified && experience.DateRange[2].EndDateSpecified)
                        {
                            tblexperience.THIRD_END_DT = experience.DateRange[2].EndDate;
                        }
                        if (experience.DateRange.Length > 3 && experience.DateRange[3].StartDate != null && Convert.ToString(experience.DateRange[3].StartDate) != "1/1/0001 12:00:00 AM")
                        //if (experience.DateRange.Length > 3 && experience.DateRange[3].StartDate != null)
                        {
                            tblexperience.FOURTH_START_DT = experience.DateRange[3].StartDate;
                            tblexperience.FOURTH_TOTAL_HRS = experience.DateRange[3].TotalHours;
                        }
                        if (experience.DateRange.Length > 3 && experience.DateRange[3].EndDateSpecified && experience.DateRange[3].EndDateSpecified)
                        {
                            tblexperience.FOURTH_END_DT = experience.DateRange[3].EndDate;
                        }
                        lstExperiences.Add(tblexperience);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstExperiences;
        }
    }
}
