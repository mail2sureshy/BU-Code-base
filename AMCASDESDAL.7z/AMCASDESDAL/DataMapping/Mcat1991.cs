﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class Mcat1991
    {
        public static List<MCAT_SCORES> Mcat1991List(ExportApplicationsApplication applicantInfo)
        {
            var listMcat1991 = new List<MCAT_SCORES>();
            try
            {
                if (applicantInfo.AcademicInformation.MCATScores?.MCATScore1991 != null 
                    && applicantInfo.AcademicInformation.MCATScores.MCATScore1991.Length > 0)
                {
                    foreach (var mcat1991 in applicantInfo.AcademicInformation.MCATScores.MCATScore1991)
                    {
                        var tblMcatScore = new MCAT_SCORES()
                        {
                            VR_SCORE = mcat1991.VerbalReasoning,
                            PS_SCORE = mcat1991.PhysicalScience,
                            BS_SCORE = mcat1991.BiologicalScience,
                            WS_SCORE = mcat1991.WritingSample,
                            SERIES_NO = mcat1991.SeriesNumber,
                            TEST_DATE = mcat1991.TestDate,
                            //AMCAS_RELEASE = "Y", // Need to verify
                            COMBINED_SCORE = mcat1991.Total,
                            //SPECIAL_ACCOMMODATIONS = "N", // Need to verify
                            CERT_IND = 1,
                            //TEST_FORMAT = "C",// Need to verify
                            CREATED_BY = 1,
                            //SSN =
                            LAST_UPDATE = DateTime.Now,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            AAMC_ID = applicantInfo.IdentifyingInformation.ID.AAMCID,
                            //ADVISOR_RELEASE =// Need to verify
                            //MED_MAR_RELEASE =// Need to verify
                            //RECRUITMENT_RELEASE =// Need to verify
                            VR_LOW_P = mcat1991.VerbalReasoningPercentile?.LowPercentile,
                            VR_HIGH_P = mcat1991.VerbalReasoningPercentile?.HighPercentile,
                            PS_LOW_P = mcat1991.PhysicalSciencePercentile?.LowPercentile,
                            PS_HIGH_P = mcat1991.PhysicalSciencePercentile?.HighPercentile,
                            WS_LOW_P = mcat1991.WritingSamplePercentile?.LowPercentile,
                            WS_HIGH_P = mcat1991.WritingSamplePercentile?.HighPercentile,
                            BS_LOW_P = mcat1991.BiologicalSciencePercentile?.LowPercentile,
                            BS_HIGH_P = mcat1991.BiologicalSciencePercentile?.HighPercentile,
                            TOTAL_LOW_P = mcat1991.TotalPercentile?.LowPercentile,
                            TOTAL_HIGH_P = mcat1991.TotalPercentile?.HighPercentile,
                            CB_VR_LOW = mcat1991.VerbalReasoningSectionDetails?.ConfidenceBandLow,
                            CB_VR_HIGH = mcat1991.VerbalReasoningSectionDetails?.ConfidenceBandHigh,
                            VR_PERCENTILE = mcat1991.VerbalReasoningSectionDetails?.PercentileRank,
                            CB_PS_LOW = mcat1991.PhysicalScienceSectionDetails?.ConfidenceBandLow,
                            CB_PS_HIGH = mcat1991.PhysicalScienceSectionDetails?.ConfidenceBandLow,
                            PS_PERCENTILE = mcat1991.PhysicalScienceSectionDetails?.PercentileRank,
                            CB_BS_LOW = mcat1991.BiologicalScienceSectionDetails?.ConfidenceBandLow,
                            CB_BS_HIGH = mcat1991.BiologicalScienceSectionDetails?.ConfidenceBandHigh,
                            BS_PERCENTILE = mcat1991.BiologicalScienceSectionDetails?.PercentileRank,
                            WS_PERCENTILE = mcat1991.WritingSamplePercentileRank,
                            CB_TOTAL_LOW = mcat1991.TotalSectionDetails?.ConfidenceBandLow,
                            CB_TOTAL_HIGH = mcat1991.TotalSectionDetails?.ConfidenceBandHigh,
                            TOTAL_PERCENTILE = mcat1991.TotalSectionDetails?.PercentileRank
                        };
                        listMcat1991.Add(tblMcatScore);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listMcat1991;
        }

        public static List<MCAT_SCORES_ARCHIVE> GetMcat1991ArchivesList(ExportApplicationsApplication applicantInfo, int sessonId)
        {
            // Add 1991 Archive information
            var lstMcat1991Arc = new List<MCAT_SCORES_ARCHIVE>();
            try
            {// Archive GPA's data into GPA_ARCHIVE table
                if (applicantInfo.AcademicInformation.GPAs != null)
                {
                    AMCASEntities context = new AMCASEntities();
                    var mcat1991Scores = context.MCAT_SCORES.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                                                                d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);
                    if (mcat1991Scores.Any())
                    {
                        foreach (var mcat1991Score in mcat1991Scores)
                        {
                            var tblMcas1991Archive = new MCAT_SCORES_ARCHIVE()
                            {
                                DESSessionID = sessonId,
                                VR_SCORE = mcat1991Score.VR_SCORE,
                                PS_SCORE = mcat1991Score.PS_SCORE,
                                BS_SCORE = mcat1991Score.BS_SCORE,
                                WS_SCORE = mcat1991Score.WS_SCORE,
                                SERIES_NO = mcat1991Score.SERIES_NO,
                                TEST_DATE = mcat1991Score.TEST_DATE,
                                AMCAS_RELEASE = mcat1991Score.AMCAS_RELEASE,
                                COMBINED_SCORE = mcat1991Score.COMBINED_SCORE,
                                SPECIAL_ACCOMMODATIONS = mcat1991Score.SPECIAL_ACCOMMODATIONS,
                                CERT_IND = mcat1991Score.CERT_IND,
                                TEST_FORMAT = mcat1991Score.TEST_FORMAT,
                                CREATED_BY = mcat1991Score.CREATED_BY,
                                SSN = mcat1991Score.SSN,
                                LAST_UPDATE = DateTime.Now,
                                APPL_PERSON_ID = mcat1991Score.APPL_PERSON_ID,
                                APPL_YEAR = mcat1991Score.APPL_YEAR,
                                AAMC_ID = mcat1991Score.AAMC_ID,
                                ADVISOR_RELEASE = mcat1991Score.ADVISOR_RELEASE,
                                MED_MAR_RELEASE = mcat1991Score.MED_MAR_RELEASE,
                                RECRUITMENT_RELEASE = mcat1991Score.RECRUITMENT_RELEASE,
                                VR_LOW_P = mcat1991Score.VR_LOW_P,
                                VR_HIGH_P = mcat1991Score.VR_HIGH_P,
                                PS_LOW_P = mcat1991Score.PS_LOW_P,
                                PS_HIGH_P = mcat1991Score.PS_HIGH_P,
                                WS_LOW_P = mcat1991Score.WS_LOW_P,
                                WS_HIGH_P = mcat1991Score.WS_HIGH_P,
                                BS_LOW_P = mcat1991Score.BS_LOW_P,
                                BS_HIGH_P = mcat1991Score.BS_HIGH_P,
                                TOTAL_LOW_P = mcat1991Score.TOTAL_LOW_P,
                                TOTAL_HIGH_P = mcat1991Score.TOTAL_HIGH_P,
                                CB_VR_LOW = mcat1991Score.CB_VR_LOW,
                                CB_VR_HIGH = mcat1991Score.CB_VR_HIGH,
                                VR_PERCENTILE = mcat1991Score.VR_PERCENTILE,
                                CB_PS_LOW = mcat1991Score.CB_PS_LOW,
                                CB_PS_HIGH = mcat1991Score.CB_PS_HIGH,
                                PS_PERCENTILE = mcat1991Score.PS_PERCENTILE,
                                CB_BS_LOW = mcat1991Score.CB_BS_LOW,
                                CB_BS_HIGH = mcat1991Score.CB_BS_HIGH,
                                BS_PERCENTILE = mcat1991Score.BS_PERCENTILE,
                                WS_PERCENTILE = mcat1991Score.WS_PERCENTILE,
                                CB_TOTAL_LOW = mcat1991Score.CB_TOTAL_LOW,
                                CB_TOTAL_HIGH = mcat1991Score.CB_TOTAL_HIGH,
                                TOTAL_PERCENTILE = mcat1991Score.TOTAL_PERCENTILE,
                                create_date = DateTime.Now
                            };
                            lstMcat1991Arc.Add(tblMcas1991Archive);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMcat1991Arc;
        }
    }
}
