﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace AMCASDESDAL.DataMapping
{
    public abstract class ErrorLog
    {
        /// <summary>
        /// Insert Error information into Database.
        /// </summary>
        /// <param name="message"></param>
        /// <param name="url"></param>
        /// <returns>bool</returns>
        public async Task<bool> InsertEvenLogInformation(string message, string url = null, int sessionId = 0)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    DES_EventLog evenLog = new DES_EventLog
                    {
                        Message = message,
                        URL = url,
                        Date = DateTime.Now,
                        SessionID = sessionId
                    };
                    context.DES_EventLog.Add(evenLog);
                    await context.SaveChangesAsync();
                }
            }
            catch
            {
                string source = "AMCASDESClient";
                string log = "Application";
                if (!EventLog.SourceExists(source))
                {
                    EventLog.CreateEventSource(source, log);
                }
                EventLog.WriteEntry(source, message, EventLogEntryType.Error);

                return false;
            }
            return true;
        }

        public async Task<bool> InsertRefErrorLogInfor(int applYear, string tblName, string rowData)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    DES_RefEventLog desRefErrorData = new DES_RefEventLog
                    {
                        APPL_YEAR = applYear,
                        TableName = tblName,
                        ErrorRow = rowData,
                        Date = DateTime.Now
                    };
                    context.DES_RefEventLog.Add(desRefErrorData);
                    await context.SaveChangesAsync();
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Insert Error log information
        /// </summary>
        /// <param name="message"></param>
        /// <returns>bool</returns>
        public static bool InsertEvenLogInfor(string message)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    DES_EventLog evenLog = new DES_EventLog
                    {
                        Message = message,
                        Date = DateTime.Now
                    };
                    context.DES_EventLog.Add(evenLog);
                    context.SaveChanges();
                }
            }
            catch
            {
                return false;
            }
            return true;
        }

    }
}
