﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class Letters
    {
        public static List<LETTER> LettersList(ExportApplicationsApplication applicantInfo)
        {
            // Add Letter information 
            var lstLetters = new List<LETTER>();
            try
            {
                if (applicantInfo.LettersOfEvaluation?.Letter != null && applicantInfo.LettersOfEvaluation.Letter.Length > 0)
                {
                    foreach (var letter in applicantInfo.LettersOfEvaluation.Letter)
                    {
                        var tblLetter = new LETTER()
                        {
                            LETTER_ID = letter.LetterID,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear
                        };

                        //tblLetter.INST_COUNTRY_CD =//Need to verify
                        //tblLetter.INST_STATE_CD =//Need to verify
                        tblLetter.MOD_SCHOOL_DESC = letter.PrimaryAuthorInstitutionName;
                        tblLetter.AUTHOR_SALUTATION_CD = letter.PrimaryAuthorName.AuthorSalutation;
                        tblLetter.AUTHOR_FNAME = letter.PrimaryAuthorName.AuthorFirstName;
                        tblLetter.AUTHOR_MNAME = letter.PrimaryAuthorName.AuthorMiddleName;
                        tblLetter.AUTHOR_LNAME = letter.PrimaryAuthorName.AuthorLastName;
                        tblLetter.AUTHOR_SUFFIX_CD = letter.PrimaryAuthorName.AuthorSuffix;
                        tblLetter.AUTHOR_TITLE = letter.PrimaryAuthorTitle;
                        tblLetter.AUTHOR_EMAIL = letter.PrimaryAuthorEmail;
                        tblLetter.AUTHOR_PHONE = letter.PrimaryAuthorPhone;
                        tblLetter.AUTHOR_ADDRESS1 = letter.PrimaryAuthorAddress.StreetAddress?.Address1;
                        tblLetter.AUTHOR_ADDRESS2 = letter.PrimaryAuthorAddress.StreetAddress?.Address2;
                        tblLetter.AUTHOR_STATE_CD = letter.PrimaryAuthorAddress.State?.StateCode.ToString();
                        tblLetter.AUTHOR_POSTAL_CODE = letter.PrimaryAuthorAddress?.PostalCode;
                        tblLetter.AUTHOR_INSTITUTION_NAME = letter.PrimaryAuthorOrganizationName;
                        if (letter.AdditionalAuthors.Length > 0)
                        {
                            tblLetter.ADDL_AUTHOR_1 = (letter.AdditionalAuthors.Length > 0 && !string.IsNullOrEmpty(letter.AdditionalAuthors[0])) ? letter.AdditionalAuthors[0] : null;
                            tblLetter.ADDL_AUTHOR_2 = (letter.AdditionalAuthors.Length > 1 && !string.IsNullOrEmpty(letter.AdditionalAuthors[1])) ? letter.AdditionalAuthors[1] : null;
                            tblLetter.ADDL_AUTHOR_3 = (letter.AdditionalAuthors.Length > 2 && !string.IsNullOrEmpty(letter.AdditionalAuthors[2])) ? letter.AdditionalAuthors[2] : null;
                            tblLetter.ADDL_AUTHOR_4 = (letter.AdditionalAuthors.Length > 3 && !string.IsNullOrEmpty(letter.AdditionalAuthors[3])) ? letter.AdditionalAuthors[3] : null;
                            tblLetter.ADDL_AUTHOR_5 = (letter.AdditionalAuthors.Length > 4 && !string.IsNullOrEmpty(letter.AdditionalAuthors[4])) ? letter.AdditionalAuthors[4] : null;
                            tblLetter.ADDL_AUTHOR_6 = (letter.AdditionalAuthors.Length > 5 && !string.IsNullOrEmpty(letter.AdditionalAuthors[5])) ? letter.AdditionalAuthors[5] : null;
                            tblLetter.ADDL_AUTHOR_7 = (letter.AdditionalAuthors.Length > 6 && !string.IsNullOrEmpty(letter.AdditionalAuthors[6])) ? letter.AdditionalAuthors[6] : null;
                            tblLetter.ADDL_AUTHOR_8 = (letter.AdditionalAuthors.Length > 7 && !string.IsNullOrEmpty(letter.AdditionalAuthors[7])) ? letter.AdditionalAuthors[7] : null;
                            tblLetter.ADDL_AUTHOR_9 = (letter.AdditionalAuthors.Length > 8 && !string.IsNullOrEmpty(letter.AdditionalAuthors[8])) ? letter.AdditionalAuthors[8] : null;
                            tblLetter.ADDL_AUTHOR_10 = (letter.AdditionalAuthors.Length > 9 && !string.IsNullOrEmpty(letter.AdditionalAuthors[9])) ? letter.AdditionalAuthors[9] : null;
                        }

                        tblLetter.AUTHOR_CITY = letter.PrimaryAuthorAddress.City;
                        tblLetter.AUTHOR_COUNTRY_CD = letter.PrimaryAuthorAddress.Country?.CountryCode.ToString();
                        tblLetter.CERT_IND = 1;
                        //tblLetter.COLLEGE_INST_ID =//Need to verify
                        //tblLetter.BARCODE_ID =//Need to verify
                        //tblLetter.ACTIVE_IND =//Need to verify
                        tblLetter.CREATED_BY = 1;
                        //tblLetter.AUTHOR_AAMC_ID =//Need to verify
                        //tblLetter.COMMITTEE_IND =//Need to verify
                        //tblLetter.LETTER_STATUS_CD =//Need to verify
                        tblLetter.LAST_UPDATE = DateTime.Now;
                        //tblLetter.APPL_TYPE_ID =//Need to verify
                        tblLetter.LETTER_TITLE = letter.LetterType.LetterTypeDescription;
                        tblLetter.NO_SEND_IND = letter.NoSendIndicator ? 1 : 0;
                        tblLetter.CERT_IND = 1;
                        tblLetter.CREATED_BY = 1;
                        tblLetter.LAST_UPDATE = DateTime.Now;

                        lstLetters.Add(tblLetter);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLetters;
        }
        

        public static List<DOCUMENT_RECEIPT> DocumentReceiptsList(ExportApplicationsApplication applicantInfo)
        {
            // Add Letter information 
            var lstDocumentReceipts = new List<DOCUMENT_RECEIPT>();
            try
            {
                if (applicantInfo.LettersOfEvaluation?.Letter != null && applicantInfo.LettersOfEvaluation.Letter.Length > 0)
                {
                    foreach (var letter in applicantInfo.LettersOfEvaluation.Letter)
                    {
                        if (letter.Receipt != null && letter.Receipt.Length > 0)
                        {
                            foreach (var receipt in letter.Receipt)
                            {
                                //var recordExists =
                                //    context.DOCUMENT_RECEIPT.AsNoTracking().SingleOrDefault(
                                //        a => a.DocumentReceiptID == receipt.ReceiptDocumentID && a.DocumentContentID == null &&
                                //        a.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && 
                                //        a.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);

                                //if (recordExists == null)
                                //{
                                    var letterDocReceipts = new DOCUMENT_RECEIPT()
                                    {
                                        DocumentReceiptID = (int)receipt.ReceiptDocumentID,
                                        DocumentTypeID = GetDocumentTypeId("letter"),
                                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                                        CreateDate = DateTime.Now,
                                        UpdateDate = DateTime.Now
                                    };
                                    lstDocumentReceipts.Add(letterDocReceipts);
                                //}
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstDocumentReceipts;
        }

        public static List<DOCUMENT_RECEIPT> InvestigativeEvaluativeAndMcatDocumentReceiptsList(ExportApplicationsApplication applicantInfo)
        {
            // Add Letter information 
            var lstDocumentReceipts = new List<DOCUMENT_RECEIPT>();
            var context = new AMCASEntities();
            try
            {
                if (applicantInfo.Documents != null)
                {
                    // Evaluation
                    if (applicantInfo.Documents.EvaluationID != null)
                    {
                        foreach (var evaluationId in applicantInfo.Documents.EvaluationID)
                        {
                            //var recordExists = context.DOCUMENT_RECEIPT.SingleOrDefault(a => a.DocumentReceiptID == evaluationId &&
                            //                          a.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                            //                          a.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);

                            //if (recordExists == null)
                            //{
                                var letterDocReceipts = new DOCUMENT_RECEIPT()
                                {
                                    DocumentReceiptID = (int)evaluationId,
                                    DocumentTypeID = GetDocumentTypeId("evaluation"),
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                                    CreateDate = DateTime.Now,
                                    UpdateDate = DateTime.Now
                                };
                                lstDocumentReceipts.Add(letterDocReceipts);
                            //}
                        }
                    }

                    // Investigation
                    if (applicantInfo.Documents.InvestigationID != null)
                    {
                        foreach (var investigationId in applicantInfo.Documents.InvestigationID)
                        {
                            //var recordExists = context.DOCUMENT_RECEIPT.SingleOrDefault(a => a.DocumentReceiptID == investigationId && 
                            //                          a.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                            //                          a.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);

                            //if (recordExists == null)
                            //{
                                var letterDocReceipts = new DOCUMENT_RECEIPT()
                                {
                                    DocumentReceiptID = (int)investigationId,
                                    DocumentTypeID = GetDocumentTypeId("investigation"),
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                                    CreateDate = DateTime.Now,
                                    UpdateDate = DateTime.Now
                                };
                                lstDocumentReceipts.Add(letterDocReceipts);
                            //}
                        }
                    }
                }

                // MCAT Image
                if (applicantInfo.AcademicInformation.MCATScores.MCATScore2015 != null &&
                    applicantInfo.AcademicInformation.MCATScores.MCATScore2015.Length > 0)
                {
                    foreach (var scores in applicantInfo.AcademicInformation.MCATScores.MCATScore2015)
                    {

                        //var recordExists = context.DOCUMENT_RECEIPT.SingleOrDefault(a => a.DocumentReceiptID == scores.MCATImageID &&
                        //                              a.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                        //                              a.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);

                        //if (recordExists == null)
                        //{
                            var mcatImageReceipts = new DOCUMENT_RECEIPT()
                            {
                                DocumentReceiptID = (int)scores.MCATImageID,
                                DocumentTypeID = GetDocumentTypeId("mcat"),
                                APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                                CreateDate = DateTime.Now,
                                UpdateDate = DateTime.Now
                            };
                            lstDocumentReceipts.Add(mcatImageReceipts);
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstDocumentReceipts;
        }

        private static int GetDocumentTypeId(string documentType)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    var refDocumentType = context.REF_DOCUMENT_TYPE.FirstOrDefault(a => a.DocumentType == documentType);
                    if (refDocumentType != null)
                        return refDocumentType.DocumentTypeID;
                }
            }
            catch (Exception)
            {
                //InsertErrorInfo(ex.Message);
            }
            return 0;
        }
    }
}
