﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class MiscTest
    {
        public static List<MISC_TEST> GetMiscTest(ExportApplicationsApplication applicantInfo)
        {
            // Add MISC_TEST information
            var lstMistTests = new List<MISC_TEST>();
            try
            {
                if (applicantInfo.AcademicInformation.OtherTests != null)
                {
                    foreach (var otherTest in applicantInfo.AcademicInformation.OtherTests)
                    {
                        var tblMistTest = new MISC_TEST()
                        {
                            MISC_TEST_ID = (int)otherTest.OtherTestID,
                            TEST_NAME = otherTest.TestName,
                            TEST_DATE = otherTest.TestDate,
                            TEST_SECTION = otherTest.TestSection,
                            TEST_SCORE = otherTest.TestScore,
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear
                        };
                        lstMistTests.Add(tblMistTest);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMistTests;
        }

    }
}
