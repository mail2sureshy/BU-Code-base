﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class PreviousApplicationInfo
    {
        public static List<PREVIOUS_APPLICATION_INFO> GetPreviousApplicationInfoList(ExportApplicationsApplication applicantInfo)
        {
            // Add PREVIOUS_APPLICATION_INFO information
            var lstPreviousApplicationInfo = new List<PREVIOUS_APPLICATION_INFO>();
            try
            {
                if (applicantInfo.MedicalSchoolDesignation != null)
                {
                    foreach (var medicalSchoolDesignation in applicantInfo.MedicalSchoolDesignation)
                    {
                        if (medicalSchoolDesignation.PreviousAppliedYear != null)
                        {
                            foreach (var previousYear in medicalSchoolDesignation.PreviousAppliedYear)
                            {
                                var tblPreviousApplicationInfo = new PREVIOUS_APPLICATION_INFO()
                                {
                                    MED_INST_ID = medicalSchoolDesignation.MedicalInstitutionID,
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    APPLIED_YEAR = previousYear,
                                    CREATED_BY = 1,
                                    APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                                    LAST_UPDATE = DateTime.Now,
                                    AAMC_ID = applicantInfo.IdentifyingInformation.ID.AAMCID
                                };
                                lstPreviousApplicationInfo.Add(tblPreviousApplicationInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstPreviousApplicationInfo;
        }
    }
}
