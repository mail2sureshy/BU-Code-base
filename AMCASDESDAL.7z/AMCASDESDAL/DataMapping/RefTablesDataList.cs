﻿using System;
using System.Collections.Generic;
using System.Data;

namespace AMCASDESDAL.DataMapping
{
    public static class RefTablesDataList
    {
        /// <summary>
        /// REF_SCHOOL_ADMISSION_ACTION table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_SCHOOL_ADMISSION_ACTION> GetRefSchoolAdmissionList(DataTable data)
        {
            var lstSchoolAdmActions = new List<REF_SCHOOL_ADMISSION_ACTION>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var refSchoolAdmActions = new REF_SCHOOL_ADMISSION_ACTION();

                    refSchoolAdmActions.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    refSchoolAdmActions.ADMISSION_ACTION_CD =
                        dataRow["ADMISSION_ACTION_CD"].ToString();
                    refSchoolAdmActions.SCHOOL_ADMISSION_ACTION_ID =
                        Convert.ToInt32(dataRow["SCHOOL_ADMISSION_ACTION_ID"]);
                    refSchoolAdmActions.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    refSchoolAdmActions.ADMISSION_ACTION_DESC =
                        dataRow["ADMISSION_ACTION_DESC"].ToString();
                    refSchoolAdmActions.FINAL_ACTION_IND =
                        Convert.ToInt32(dataRow["FINAL_ACTION_IND"]);
                    refSchoolAdmActions.OFFICIAL_AMCAS_ACTION_IND =
                        Convert.ToInt32(dataRow["OFFICIAL_AMCAS_ACTION_IND"]);
                    if (!string.IsNullOrEmpty(dataRow["ORDER_SEQ"].ToString()))
                    {
                        refSchoolAdmActions.ORDER_SEQ = Convert.ToInt32(dataRow["ORDER_SEQ"]);
                    }
                    //refSchoolAdmActions.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //refSchoolAdmActions.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    refSchoolAdmActions.IN_USE_IND = Convert.ToInt32(dataRow["IN_USE_IND"]);

                    lstSchoolAdmActions.Add(refSchoolAdmActions);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstSchoolAdmActions;
        }

        /// <summary>
        /// REF_COUNTRY table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_COUNTRY> GetRefCountrysList(DataTable data)
        {
            var lstCountrys = new List<REF_COUNTRY>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_COUNTRY();
                    reftable.COUNTRY_CD = dataRow["COUNTRY_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.COUNTRY_DESC_50 = dataRow["COUNTRY_DESC_50"].ToString();
                    reftable.COUNTRY_DESC_120 = dataRow["COUNTRY_DESC_120"].ToString();
                    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    if (!string.IsNullOrEmpty(dataRow["ISO_NUMERIC"].ToString()))
                    {
                        reftable.ISO_NUMERIC = Convert.ToInt32(dataRow["ISO_NUMERIC"]);
                    }

                    lstCountrys.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCountrys;
        }

        /// <summary>
        /// REF_STATE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_STATE> GetRefStatesList(DataTable data)
        {
            var lstStates = new List<REF_STATE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_STATE();
                    reftable.STATE_CD = dataRow["STATE_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.STATE_DESC = dataRow["STATE_DESC"].ToString();
                    reftable.DIVISION_CD = dataRow["DIVISION_CD"].ToString();
                    reftable.COUNTRY_CD = dataRow["COUNTRY_CD"].ToString();
                    reftable.ACTIVE_IND = 1;// Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstStates.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstStates;
        }

        /// <summary>
        /// REF_COUNTY table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_COUNTY> GetRefCountyList(DataTable data)
        {
            var lstCountys = new List<REF_COUNTY>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_COUNTY();

                    reftable.COUNTY_CD = dataRow["COUNTY_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.COUNTY_DESC_20 = dataRow["COUNTY_DESC_20"].ToString();
                    reftable.COUNTY_DESC_50 = dataRow["COUNTY_DESC_50"].ToString();
                    reftable.ACTIVE_IND = 1; //Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    reftable.RURAL_URBAN_IND = Convert.ToInt32(dataRow["RURAL_URBAN_IND"]);
                    reftable.STATE_CD = dataRow["STATE_CD"].ToString();
                    reftable.MED_UNDERSERVED_IND = Convert.ToInt32(dataRow["MED_UNDERSERVED_IND"]);
                    lstCountys.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCountys;
        }

        /// <summary>
        /// REF_SALUTATION table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_SALUTATION> GetRefSalutationList(DataTable data)
        {
            var lstSalutation = new List<REF_SALUTATION>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_SALUTATION();

                    reftable.SALUTATION_CD = dataRow["SALUTATION_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.SALUTATION_DESC = dataRow["SALUTATION_DESC"].ToString();
                    reftable.ACTIVE_IND = 1; //Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstSalutation.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstSalutation;
        }

        /// <summary>
        /// REF_SUFFIX table object from file  
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_SUFFIX> GetRefSuffixList(DataTable data)
        {
            var lstSuffix = new List<REF_SUFFIX>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_SUFFIX();

                    reftable.SUFFIX_CD = dataRow["SUFFIX_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.SUFFIX_DESC = dataRow["SUFFIX_DESC"].ToString();
                    reftable.DISPLAY_TXT = dataRow["DISPLAY_TXT"].ToString();
                    reftable.ACTIVE_IND = 1; Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstSuffix.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstSuffix;
        }

        /// <summary>
        /// REF_COLLEGE_INSTITUTION table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_COLLEGE_INSTITUTION> GetRefCollegeInisInstitutionsList(DataTable data)
        {
            var lstCollegeInisInstitutions = new List<REF_COLLEGE_INSTITUTION>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_COLLEGE_INSTITUTION();

                    reftable.COLLEGE_INST_ID = Convert.ToInt32(dataRow["COLLEGE_INST_ID"]);
                    if (!string.IsNullOrEmpty(dataRow["IPEDS_ID"].ToString()))
                    {
                        reftable.IPEDS_ID = Convert.ToInt32(dataRow["IPEDS_ID"]);
                    }
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.LONG_DESC = dataRow["LONG_DESC"].ToString();
                    reftable.SHORT_DESC = dataRow["SHORT_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["ENROLL_AMT"].ToString()))
                    {
                        reftable.ENROLL_AMT = Convert.ToDecimal(dataRow["ENROLL_AMT"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["CROSS_IND"].ToString()))
                    {
                        reftable.CROSS_IND = Convert.ToInt32(dataRow["CROSS_IND"]);
                    }

                    if (!string.IsNullOrEmpty(dataRow["ACCREDITED_IND"].ToString()))
                    {
                        reftable.ACCREDITED_IND = Convert.ToInt32(dataRow["ACCREDITED_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["COUNTY_CD"].ToString()))
                    {
                        reftable.COUNTY_CD = dataRow["COUNTY_CD"].ToString();
                    }
                    if (!string.IsNullOrEmpty(dataRow["COUNTRY_CD"].ToString()))
                    {
                        reftable.COUNTRY_CD = dataRow["COUNTRY_CD"].ToString();
                    }

                    reftable.CITY = dataRow["CITY"].ToString();
                    reftable.ADDRESS1 = dataRow["ADDRESS1"].ToString();
                    reftable.ADDRESS2 = dataRow["ADDRESS2"].ToString();
                    reftable.POSTAL_CD = dataRow["POSTAL_CD"].ToString();

                    if (!string.IsNullOrEmpty(dataRow["DEADLINE"].ToString()) && dataRow["DEADLINE"].ToString() != "1/1/0001 12:00:00 AM")
                    {
                        reftable.DEADLINE = Convert.ToDateTime(dataRow["DEADLINE"]);
                    }

                    if (!string.IsNullOrEmpty(dataRow["NARRATIVE_EVAL_IND"].ToString()))
                    {
                        reftable.NARRATIVE_EVAL_IND = Convert.ToInt32(dataRow["NARRATIVE_EVAL_IND"]);
                    }
                    reftable.ACTIVE_IND = 1; // Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);

                    if (!string.IsNullOrEmpty(dataRow["STATE_CD"].ToString()))
                    {
                        reftable.STATE_CD = dataRow["STATE_CD"].ToString();
                    }
                    if (!string.IsNullOrEmpty(dataRow["OPEN_DATE"].ToString()) && dataRow["OPEN_DATE"].ToString() != "1/1/0001 12:00:00 AM")
                    {
                        //reftable.OPEN_DATE = Convert.ToDateTime(dataRow["OPEN_DATE"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["CLOSE_DATE"].ToString()) && dataRow["CLOSE_DATE"].ToString() != "1/1/0001 12:00:00 AM")
                    {
                        reftable.CLOSE_DATE = Convert.ToDateTime(dataRow["CLOSE_DATE"]);
                    }
                    reftable.FICE_CD = dataRow["FICE_CD"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["CARN_ID"].ToString()))
                    {
                        reftable.CARN_ID = Convert.ToInt32(dataRow["CARN_ID"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["REG_LETTER_RESPONSE_IND"].ToString()))
                    {
                        reftable.REG_LETTER_RESPONSE_IND = Convert.ToInt32(dataRow["REG_LETTER_RESPONSE_IND"]);
                    }
                    lstCollegeInisInstitutions.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCollegeInisInstitutions;
        }

        /// <summary>
        /// REF_COLLEGE_INST_CONTACT table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_COLLEGE_INST_CONTACT> GetRefCollegeInisInstContactsList(DataTable data)
        {
            var lstCollegeInisInstitutions = new List<REF_COLLEGE_INST_CONTACT>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_COLLEGE_INST_CONTACT();

                    reftable.COLLEGE_INST_CONTACT_ID = Convert.ToInt32(dataRow["COLLEGE_INST_CONTACT_ID"]);
                    if (!string.IsNullOrEmpty(dataRow["SALUTATION_CD"].ToString()))
                    {
                        reftable.SALUTATION_CD = dataRow["SALUTATION_CD"].ToString();
                    }
                    reftable.FIRST_NAME = dataRow["FIRST_NAME"].ToString();
                    reftable.MIDDLE_NAME = dataRow["MIDDLE_NAME"].ToString();
                    reftable.LAST_NAME = dataRow["LAST_NAME"].ToString();
                    reftable.DIVISION = dataRow["DIVISION"].ToString();

                    if (!string.IsNullOrEmpty(dataRow["SUFFIX_CD"].ToString()))
                    {
                        reftable.SUFFIX_CD = dataRow["SUFFIX_CD"].ToString();
                    }
                    reftable.CONTACT_TITLE = dataRow["CONTACT_TITLE"].ToString();
                    reftable.ADDRESS1 = dataRow["ADDRESS1"].ToString();
                    reftable.ADDRESS2 = dataRow["ADDRESS2"].ToString();

                    if (!string.IsNullOrEmpty(dataRow["CONTACT_TYPE_ID"].ToString()))
                    {
                        reftable.CONTACT_TYPE_ID = Convert.ToInt32(dataRow["CONTACT_TYPE_ID"]);
                    }

                    reftable.FAX = dataRow["FAX"].ToString();
                    reftable.DAY_PHONE = dataRow["DAY_PHONE"].ToString();
                    reftable.DAY_PHONE_EXT = dataRow["DAY_PHONE_EXT"].ToString();
                    reftable.ALT_PHONE = dataRow["ALT_PHONE"].ToString();
                    reftable.ALT_PHONE_EXT = dataRow["ALT_PHONE_EXT"].ToString();
                    reftable.CELL_PHONE = dataRow["CELL_PHONE"].ToString();
                    reftable.EMAIL = dataRow["EMAIL"].ToString();
                    reftable.CITY = dataRow["CITY"].ToString();

                    if (!string.IsNullOrEmpty(dataRow["COUNTRY_CD"].ToString()))
                    {
                        reftable.COUNTRY_CD = dataRow["COUNTRY_CD"].ToString();
                    }

                    if (!string.IsNullOrEmpty(dataRow["POSTAL_CD"].ToString()))
                    {
                        reftable.POSTAL_CD = dataRow["POSTAL_CD"].ToString();
                    }

                    reftable.ALT_EMAIL = dataRow["ALT_EMAIL"].ToString();
                    reftable.NOTES = dataRow["NOTES"].ToString();
                    reftable.URL = dataRow["URL"].ToString();
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    reftable.ACTIVE_IND = 1;// Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    if (!string.IsNullOrEmpty(dataRow["COLLEGE_INST_ID"].ToString()))
                    {
                        reftable.COLLEGE_INST_ID = Convert.ToInt32(dataRow["COLLEGE_INST_ID"]);
                    }
                    //if (!string.IsNullOrEmpty(dataRow["CREATED_BY"].ToString()))
                    //{
                    //    reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //}
                    if (!string.IsNullOrEmpty(dataRow["APPL_YEAR"].ToString()))
                    {
                        reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["STATE_CD"].ToString()))
                    {
                        reftable.STATE_CD = dataRow["STATE_CD"].ToString();
                    }

                    //if (!string.IsNullOrEmpty(dataRow["LAST_UPDATE"].ToString()))
                    //{
                    //    reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    //}
                    lstCollegeInisInstitutions.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCollegeInisInstitutions;
        }

        /// <summary>
        /// REF_COURSE_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_COURSE_TYPE> GetRefCourseType(DataTable data)
        {
            var lstCourseTypes = new List<REF_COURSE_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_COURSE_TYPE
                    {
                        COURSE_TYPE_CD = dataRow["COURSE_TYPE_CD"].ToString(),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        COURSE_TYPE_DESC = dataRow["COURSE_TYPE_DESC"].ToString(),
                        ACTIVE_IND = 1,// Convert.ToInt32(dataRow["ACTIVE_IND"]),
                       // CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                       // LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstCourseTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCourseTypes;
        }

        /// <summary>
        /// REF_DEGREE_CAT table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_DEGREE_CAT> GetRefDegreeCatList(DataTable data)
        {
            var lstDegreeCat = new List<REF_DEGREE_CAT>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_DEGREE_CAT
                    {
                        REF_DEGREE_CAT_ID = Convert.ToInt32(dataRow["REF_DEGREE_CAT_ID"]),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        DEGREE_CAT_DESC = dataRow["DEGREE_CAT_DESC"].ToString(),
                        ACTIVE_IND =1,// Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstDegreeCat.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstDegreeCat;
        }

        /// <summary>
        /// REF_FIELD_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_FIELD_TYPE> GetRefFieldTypeList(DataTable data)
        {
            var lstFieldType = new List<REF_FIELD_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_FIELD_TYPE
                    {
                        FIELD_TYPE_ID = Convert.ToInt32(dataRow["FIELD_TYPE_ID"]),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        FIELD_TYPE_DESC = dataRow["FIELD_TYPE_DESC"].ToString(),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstFieldType.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstFieldType;
        }

        /// <summary>
        /// REF_MAJOR_CAT table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_MAJOR_CAT> GetMajorCatList(DataTable data)
        {
            var lstMajorCategory = new List<REF_MAJOR_CAT>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_MAJOR_CAT
                    {
                        MAJOR_CAT_CD = dataRow["MAJOR_CAT_CD"].ToString(),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        MAJOR_CAT_DESC = dataRow["MAJOR_CAT_DESC"].ToString(),
                        ACTIVE_IND =1,// Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstMajorCategory.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMajorCategory;
        }

        /// <summary>
        /// REF_MED_INST table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_MED_INST> GetMedInstList(DataTable data)
        {
            var lstMedicalInst = new List<REF_MED_INST>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_MED_INST();

                    reftable.MED_INST_ID = Convert.ToInt32(dataRow["MED_INST_ID"]);
                    if (!string.IsNullOrEmpty(dataRow["APPL_YEAR"].ToString()))
                    {
                        reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    }

                    if (!string.IsNullOrEmpty(dataRow["IPEDS_ID"].ToString()))
                    {
                        reftable.IPEDS_ID = Convert.ToInt32(dataRow["IPEDS_ID"]);
                    }

                    if (!string.IsNullOrEmpty(dataRow["AMCAS_IND"].ToString()))
                    {
                        reftable.AMCAS_IND = Convert.ToInt32(dataRow["AMCAS_IND"]);
                    }

                    reftable.LONG_DESC = dataRow["LONG_DESC"].ToString();
                    reftable.SHORT_DESC = dataRow["SHORT_DESC"].ToString();

                    if (!string.IsNullOrEmpty(dataRow["COUNTY_CD"].ToString()))
                    {
                        reftable.COUNTY_CD = dataRow["COUNTY_CD"].ToString();
                    }

                    if (!string.IsNullOrEmpty(dataRow["COUNTRY_CD"].ToString()))
                    {
                        reftable.COUNTRY_CD = dataRow["COUNTRY_CD"].ToString();
                    }

                    if (!string.IsNullOrEmpty(dataRow["POSTAL_CD"].ToString()))
                    {
                        reftable.POSTAL_CD = dataRow["POSTAL_CD"].ToString();
                    }

                    reftable.ACTIVE_IND = 1;// Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //if (!string.IsNullOrEmpty(dataRow["LAST_UPDATE"].ToString()))
                    //{
                    //    reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    //}

                    if (!string.IsNullOrEmpty(dataRow["STATE_CD"].ToString()))
                    {
                        reftable.STATE_CD = dataRow["STATE_CD"].ToString();
                    }

                    if (!string.IsNullOrEmpty(dataRow["DADF_IND"].ToString()))
                    {
                        reftable.DADF_IND = Convert.ToInt32(dataRow["DADF_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["TAMF_IND"].ToString()))
                    {
                        reftable.TAMF_IND = Convert.ToInt32(dataRow["TAMF_IND"]);
                    }
                    reftable.TAMF_RUN_DAYS = dataRow["TAMF_RUN_DAYS"].ToString();
                    reftable.DADF_RUN_DAYS = dataRow["DADF_RUN_DAYS"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["CBC_IND"].ToString()))
                    {
                        reftable.CBC_IND = Convert.ToInt32(dataRow["CBC_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["SSN_SIN_DISP_IND"].ToString()))
                    {
                        reftable.SSN_SIN_DISP_IND = Convert.ToInt32(dataRow["SSN_SIN_DISP_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["EVPA_IND"].ToString()))
                    {
                        reftable.EVPA_IND = Convert.ToInt32(dataRow["EVPA_IND"]);
                    }
                    lstMedicalInst.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMedicalInst;
        }

        /// <summary>
        /// REF_GRADUATE_PROGRAM table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_GRADUATE_PROGRAM> GetGraduateProgramList(DataTable data)
        {
            var lstGraduateProgram = new List<REF_GRADUATE_PROGRAM>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_GRADUATE_PROGRAM
                    {
                        GRAD_PROGRAM_ID = Convert.ToInt32(dataRow["GRAD_PROGRAM_ID"]),
                        PROGRAM_DESC = dataRow["PROGRAM_DESC"].ToString(),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        ACTIVE_IND =1,// Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        PHD_IND = Convert.ToInt32(dataRow["PHD_IND"])
                    };
                    lstGraduateProgram.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstGraduateProgram;
        }

        /// <summary>
        /// REF_MED_PROG_INFO table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_MED_PROG_INFO> GetMedicalProgInfoList(DataTable data)
        {
            var lstMedicalProgInfo = new List<REF_MED_PROG_INFO>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_MED_PROG_INFO();

                    reftable.MED_PROGRAM_INFO_ID = Convert.ToInt32(dataRow["MED_PROGRAM_INFO_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    if (!string.IsNullOrEmpty(dataRow["MED_INST_ID"].ToString()))
                    {
                        reftable.MED_INST_ID = Convert.ToInt32(dataRow["MED_INST_ID"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["APPL_DEADLINE"].ToString()))
                    {
                        reftable.APPL_DEADLINE = Convert.ToDateTime(dataRow["APPL_DEADLINE"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["TRNSCPT_DEADLINE"].ToString()))
                    {
                        reftable.TRNSCPT_DEADLINE = Convert.ToDateTime(dataRow["TRNSCPT_DEADLINE"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["INSTATE_ONLY_IND"].ToString()))
                    {
                        reftable.INSTATE_ONLY_IND = Convert.ToInt32(dataRow["INSTATE_ONLY_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["PROGRAM_ONLY_IND"].ToString()))
                    {
                        reftable.PROGRAM_ONLY_IND = Convert.ToInt32(dataRow["PROGRAM_ONLY_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["OTHER_IND"].ToString()))
                    {
                        reftable.OTHER_IND = Convert.ToInt32(dataRow["OTHER_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["RESTRICTION_IND"].ToString()))
                    {
                        reftable.RESTRICTION_IND = Convert.ToInt32(dataRow["RESTRICTION_IND"]);
                    }
                    reftable.NOTES = dataRow["RESTRICTION_IND"].ToString();
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    reftable.ACTIVE_IND = 1;// Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //if (!string.IsNullOrEmpty(dataRow["CREATED_BY"].ToString()))
                    //{
                    //    reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //}
                    //if (!string.IsNullOrEmpty(dataRow["LAST_UPDATE"].ToString()))
                    //{
                    //    reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    //}
                    lstMedicalProgInfo.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMedicalProgInfo;
        }

        /// <summary>
        /// REF_RACE_CATEGORY table object from file  
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_RACE_CATEGORY> GetRaceCategorysList(DataTable data)
        {
            var lstRaceCategorys = new List<REF_RACE_CATEGORY>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_RACE_CATEGORY
                    {
                        RACE_CAT_CD = dataRow["RACE_CAT_CD"].ToString(),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        RACE_CAT_DESC = dataRow["RACE_CAT_DESC"].ToString(),
                        ACTIVE_IND = 1, //Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstRaceCategorys.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstRaceCategorys;
        }

        /// <summary>
        /// REF_CALENDAR table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_CALENDAR> GetCalendarList(DataTable data)
        {
            var lstCalendars = new List<REF_CALENDAR>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_CALENDAR
                    {
                        CALENDAR_CD = dataRow["CALENDAR_CD"].ToString(),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        CALENDAR_DESC = dataRow["CALENDAR_DESC"].ToString(),
                        ACTIVE_IND =1, //Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstCalendars.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCalendars;
        }

        /// <summary>
        /// REF_ACA_STATUS table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_ACA_STATUS> GetAcaStatusList(DataTable data)
        {
            var lstAcaStatus = new List<REF_ACA_STATUS>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_ACA_STATUS
                    {
                        ACA_STATUS_CD = dataRow["ACA_STATUS_CD"].ToString(),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        ACA_STATUS_IND = Convert.ToInt32(dataRow["ACA_STATUS_IND"]),
                        DISPLAY_SEQ = Convert.ToInt32(dataRow["DISPLAY_SEQ"]),
                        ACA_STATUS_DESC = dataRow["ACA_STATUS_DESC"].ToString(),
                        ACTIVE_IND = 1, //Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstAcaStatus.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAcaStatus;
        }

        /// <summary>
        /// REF_ADDRESS_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_ADDRESS_TYPE> GetAddressTypesList(DataTable data)
        {
            var lstAddressTypes = new List<REF_ADDRESS_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_ADDRESS_TYPE
                    {
                        ADDR_TYPE_ID = Convert.ToInt32(dataRow["ADDR_TYPE_ID"]),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        ADDR_TYPE_DESC = dataRow["ADDR_TYPE_DESC"].ToString(),
                        ACTIVE_IND =1, //Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstAddressTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAddressTypes;
        }

        /// <summary>
        /// REF_ADI_STATUS table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_ADI_STATUS> GetAdiStatusList(DataTable data)
        {
            var lstAdiStatus = new List<REF_ADI_STATUS>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_ADI_STATUS
                    {
                        ADI_STATUS_CD = dataRow["ADI_STATUS_CD"].ToString(),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        ADI_STATUS_DESC = dataRow["ADI_STATUS_DESC"].ToString(),
                        ACTIVE_IND = 1,
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]),
                    };
                    lstAdiStatus.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAdiStatus;
        }

        // Unable to update the EntitySet 'REF_ADMISSION_ACTION_VALID' because it has a DefiningQuery and no 
        //<InsertFunction> element exists in the <ModificationFunctionMapping> element to support the current operation.
        // Note: Not required as per Marco.
        /// <summary>
        /// REF_ADMISSION_ACTION_VALID table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_ADMISSION_ACTION_VALID> GetRefAdmissionActionValidList(DataTable data)
        {
            var lstAdmissionActionValid = new List<REF_ADMISSION_ACTION_VALID>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_ADMISSION_ACTION_VALID();

                    reftable.NEXT_ADMISSION_ACTION_ID = Convert.ToInt32(dataRow["NEXT_ADMISSION_ACTION_ID"]);
                    reftable.ACTIVE_IND = 1;// Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    if (!string.IsNullOrEmpty(dataRow["SCHOOL_ADMISSION_ACTION_ID"].ToString()))
                    {
                        reftable.SCHOOL_ADMISSION_ACTION_ID = Convert.ToInt32(dataRow["SCHOOL_ADMISSION_ACTION_ID"]);
                    }
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);

                    lstAdmissionActionValid.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAdmissionActionValid;
        }

        /// <summary>
        /// REF_ALT_ID_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_ALT_ID_TYPE> GetAltIdTypeList(DataTable data)
        {
            var lstAltIdType = new List<REF_ALT_ID_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_ALT_ID_TYPE
                    {
                        REF_ALT_ID_TYPE_ID = Convert.ToInt32(dataRow["REF_ALT_ID_TYPE_ID"]),
                        APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]),
                        ALT_ID_TYPE_DESC = dataRow["ALT_ID_TYPE_DESC"].ToString(),
                        ACTIVE_IND =1, //Convert.ToInt32(dataRow["ACTIVE_IND"]),
                        //CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]),
                        //LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"])
                    };

                    lstAltIdType.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAltIdType;
        }

        /// <summary>
        /// REF_AMCAS_GRADE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_AMCAS_GRADE> GetAMCASGradesList(DataTable data)
        {
            var lstAMCASGrades = new List<REF_AMCAS_GRADE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_AMCAS_GRADE();

                    reftable.AMCAS_GRADE_CD = dataRow["AMCAS_GRADE_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    if (!string.IsNullOrEmpty(dataRow["AMCAS_WEIGHT"].ToString()))
                    {
                        reftable.AMCAS_WEIGHT = Convert.ToDecimal(dataRow["AMCAS_WEIGHT"]);
                    }
                    reftable.ACTIVE_IND = 1; //Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstAMCASGrades.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAMCASGrades;
        }

        /// <summary>
        /// REF_AP_SECTION_TAB table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_AP_SECTION_TAB> GetAPSectionTabsList(DataTable data)
        {
            var lstAPSectionTabs = new List<REF_AP_SECTION_TAB>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_AP_SECTION_TAB();

                    reftable.AP_SECTION_TAB_ID = Convert.ToInt32(dataRow["AP_SECTION_TAB_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.TAB_NAME = dataRow["TAB_NAME"].ToString();
                    reftable.ALT_TAB_NAME = dataRow["ALT_TAB_NAME"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["VISIBLE_IND"].ToString()))
                    {
                        reftable.VISIBLE_IND = Convert.ToInt32(dataRow["VISIBLE_IND"]);
                    }
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstAPSectionTabs.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstAPSectionTabs;
        }

        /// <summary>
        /// REF_APPLICATION_STATUS table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_APPLICATION_STATUS> GetApplicationStatusList(DataTable data)
        {
            var lstApplicationStatus = new List<REF_APPLICATION_STATUS>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_APPLICATION_STATUS();

                    reftable.APPL_STATUS_CD = dataRow["APPL_STATUS_CD"].ToString();
                    reftable.STATUS_DESC = dataRow["STATUS_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    
                    lstApplicationStatus.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstApplicationStatus;
        }

        /// <summary>
        /// REF_APPLICATION_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_APPLICATION_TYPE> GetApplicationTypesList(DataTable data)
        {
            var lstApplicationTypes = new List<REF_APPLICATION_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_APPLICATION_TYPE();

                    reftable.APPL_TYPE_ID = Convert.ToInt32(dataRow["APPL_TYPE_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.APPL_TYPE_DESC = dataRow["APPL_TYPE_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["CHARGEABLE_IND"].ToString()))
                    {
                        reftable.CHARGEABLE_IND = Convert.ToInt32(dataRow["CHARGEABLE_IND"]);
                    }
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstApplicationTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstApplicationTypes;
        }

        /// <summary>
        /// REF_CARNEGIE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_CARNEGIE> GetCarnegiesList(DataTable data)
        {
            var lstCarnegies = new List<REF_CARNEGIE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_CARNEGIE();

                    reftable.CARN_ID = Convert.ToInt32(dataRow["CARN_ID"]);
                    reftable.CARN_DESC = dataRow["CARN_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstCarnegies.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCarnegies;
        }

        /// <summary>
        /// REF_CLASS table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_CLASS> GetClass(DataTable data)
        {
            var lstClasses = new List<REF_CLASS>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_CLASS();

                    reftable.CLASS_CD = dataRow["CLASS_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.CLASS_DESC = dataRow["CLASS_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    if (!string.IsNullOrEmpty(dataRow["BCPM_IND"].ToString()))
                    {
                        reftable.BCPM_IND = Convert.ToInt32(dataRow["BCPM_IND"]);
                    }
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstClasses.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstClasses;
        }

        /// <summary>
        /// REF_COLLEGE_PROGRAM table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_COLLEGE_PROGRAM> GetCollegeProgram(DataTable data)
        {
            var lstCollegeProgram = new List<REF_COLLEGE_PROGRAM>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_COLLEGE_PROGRAM();

                    reftable.COLLEGE_PRGM_ID = Convert.ToInt32(dataRow["COLLEGE_PRGM_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    if (!string.IsNullOrEmpty(dataRow["COLLEGE_INST_ID"].ToString()))
                    {
                        reftable.COLLEGE_INST_ID = Convert.ToInt32(dataRow["COLLEGE_INST_ID"]);
                    }
                    reftable.PRGM_DESC = dataRow["PRGM_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}

                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstCollegeProgram.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstCollegeProgram;
        }

        /// <summary>
        /// REF_DEGREE table object from file  
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_DEGREE> GetDegrees(DataTable data)
        {
            var lstDegree = new List<REF_DEGREE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_DEGREE();

                    reftable.DEGREE_CD = dataRow["DEGREE_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.DEGREE_DESC = dataRow["DEGREE_DESC"].ToString();
                    reftable.DISPLAY_TXT = dataRow["DISPLAY_TXT"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["REF_DEGREE_CAT_ID"].ToString()))
                    {
                        reftable.REF_DEGREE_CAT_ID = Convert.ToInt32(dataRow["REF_DEGREE_CAT_ID"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["DISPLAY_SEQ"].ToString()))
                    {
                        reftable.DISPLAY_SEQ = Convert.ToInt32(dataRow["DISPLAY_SEQ"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["GRAD_IND"].ToString()))
                    {
                        reftable.GRAD_IND = dataRow["GRAD_IND"].ToString();
                    }
                    if (!string.IsNullOrEmpty(dataRow["MEDICINE_DEGREE_IND"].ToString()))
                    {
                        reftable.MEDICINE_DEGREE_IND = dataRow["MEDICINE_DEGREE_IND"].ToString();
                    }
                    if (!string.IsNullOrEmpty(dataRow["UNKNOWN_DEG_TYPE_IND"].ToString()))
                    {
                        reftable.UNKNOWN_DEG_TYPE_IND = dataRow["UNKNOWN_DEG_TYPE_IND"].ToString();
                    }
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstDegree.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstDegree;
        }

        /// <summary>
        /// REF_EDU_LEVEL table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_EDU_LEVEL> GetEduLevel(DataTable data)
        {
            var lstEduLevel = new List<REF_EDU_LEVEL>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_EDU_LEVEL();

                    reftable.EDU_LEVEL_ID = Convert.ToInt32(dataRow["EDU_LEVEL_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.EDU_LEVEL_DESC = dataRow["EDU_LEVEL_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstEduLevel.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstEduLevel;
        }

        /// <summary>
        /// REF_ESSAY_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_ESSAY_TYPE> GetEssayTypes(DataTable data)
        {
            var lstEssayTypes = new List<REF_ESSAY_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_ESSAY_TYPE();
                    if (!string.IsNullOrEmpty(dataRow["ESSAY_MAX_LENGTH"].ToString()))
                    {
                        reftable.ESSAY_MAX_LENGTH = Convert.ToInt32(dataRow["ESSAY_MAX_LENGTH"]);
                    }
                    reftable.REF_ESSAY_TYPE_ID = Convert.ToInt32(dataRow["REF_ESSAY_TYPE_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.ESSAY_TYPE_DESC = dataRow["ESSAY_TYPE_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstEssayTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstEssayTypes;
        }

        /// <summary>
        /// REF_ETHNICITY table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_ETHNICITY> GetEthnicitys(DataTable data)
        {
            var lstEthnicity = new List<REF_ETHNICITY>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_ETHNICITY();
                    
                    reftable.ETHNICITY_CD = dataRow["ETHNICITY_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.ETHNICITY_DESC = dataRow["ETHNICITY_DESC"].ToString();
                    reftable.USCENSUS_TXT = dataRow["USCENSUS_TXT"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    if (!string.IsNullOrEmpty(dataRow["DISPLAY_SEQ"].ToString()))
                    {
                        reftable.DISPLAY_SEQ = Convert.ToInt32(dataRow["DISPLAY_SEQ"]);
                    }
                    lstEthnicity.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstEthnicity;
        }

        /// <summary>
        /// REF_EXP_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_EXP_TYPE> GetExpTypes(DataTable data)
        {
            var lstExpTypes = new List<REF_EXP_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_EXP_TYPE();

                    reftable.REF_EXP_TYPE_ID = Convert.ToInt32(dataRow["REF_EXP_TYPE_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.EXP_TYPE_DESC = dataRow["EXP_TYPE_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstExpTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstExpTypes;
        }

        /// <summary>
        /// REF_FIELD table object from file  
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_FIELD> GetFields(DataTable data)
        {
            var lstFields = new List<REF_FIELD>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_FIELD();

                    reftable.FIELD_ID = Convert.ToInt32(dataRow["FIELD_ID"]);
                    reftable.FIELD_NAME = dataRow["FIELD_NAME"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.FORM_FIELD = dataRow["FORM_FIELD"].ToString();
                    
                    if (!string.IsNullOrEmpty(dataRow["AP_SECTION_TAB_ID"].ToString()))
                    {
                        reftable.AP_SECTION_TAB_ID = Convert.ToInt32(dataRow["AP_SECTION_TAB_ID"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["HIDE_IND"].ToString()))
                    {
                        reftable.HIDE_IND = Convert.ToInt32(dataRow["HIDE_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["FIELD_TYPE_ID"].ToString()))
                    {
                        reftable.FIELD_TYPE_ID = Convert.ToInt32(dataRow["FIELD_TYPE_ID"]);
                    }
                    reftable.REF_DATA_TABLE_NAME = dataRow["REF_DATA_TABLE_NAME"].ToString();
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    reftable.TABLE_NAME = dataRow["TABLE_NAME"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["FIELD_TYPE_ID"].ToString()))
                    {
                        reftable.VERIFIED_IND = Convert.ToInt32(dataRow["VERIFIED_IND"]);
                    }
                    lstFields.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstFields;
        }

        /// <summary>
        /// REF_GEO_CAT table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_GEO_CAT> GetGeoCat(DataTable data)
        {
            var lstGeoCats = new List<REF_GEO_CAT>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_GEO_CAT();

                    reftable.REF_GEO_CAT_ID = Convert.ToInt32(dataRow["REF_GEO_CAT_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.GEO_CAT_DESC = dataRow["GEO_CAT_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstGeoCats.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstGeoCats;
        }

        /// <summary>
        /// REF_HIDE_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_HIDE_TYPE> GetHideTypes(DataTable data)
        {
            var lstHideTypes = new List<REF_HIDE_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_HIDE_TYPE();

                    reftable.HIDE_TYPE_ID = Convert.ToInt32(dataRow["HIDE_TYPE_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.HIDE_TYPE_DESC = dataRow["HIDE_TYPE_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstHideTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstHideTypes;
        }

        /// <summary>
        /// REF_LANG table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_HIGH_SCHOOL_INSTITUTION> GetHighSchoolInistitutions(DataTable data)
        {
            var lstHighSchoolInistitutions = new List<REF_HIGH_SCHOOL_INSTITUTION>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_HIGH_SCHOOL_INSTITUTION();

                    reftable.HIGH_SCHOOL_INST_ID = Convert.ToInt32(dataRow["HIGH_SCHOOL_INST_ID"]);
                    reftable.LONG_DESC = dataRow["LONG_DESC"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.SHORT_DESC = dataRow["SHORT_DESC"].ToString();
                    reftable.CITY = dataRow["CITY"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["COUNTY_CD"].ToString()))
                    {
                        reftable.COUNTY_CD = dataRow["COUNTY_CD"].ToString();
                    }
                    if (!string.IsNullOrEmpty(dataRow["COUNTRY_CD"].ToString()))
                    {
                        reftable.COUNTRY_CD = dataRow["COUNTRY_CD"].ToString();
                    }
                    reftable.ADDRESS1 = dataRow["ADDRESS1"].ToString();
                    reftable.ADDRESS2 = dataRow["ADDRESS2"].ToString();
                    reftable.POSTAL_CD = dataRow["POSTAL_CD"].ToString();
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    reftable.ACTIVE_IND = 1;
                    if (!string.IsNullOrEmpty(dataRow["STATE_CD"].ToString()))
                    {
                        reftable.STATE_CD = dataRow["STATE_CD"].ToString();
                    }
                    lstHighSchoolInistitutions.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstHighSchoolInistitutions;
        }

        /// <summary>
        /// REF_INCOME table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_INCOME> GetIncomes(DataTable data)
        {
            var lstIncomes = new List<REF_INCOME>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_INCOME();

                    reftable.REF_INCOME_ID = Convert.ToInt32(dataRow["REF_INCOME_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.INCOME_DESC = dataRow["INCOME_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstIncomes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstIncomes;
        }

        /// <summary>
        /// REF_INVESTIGATION_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_INVESTIGATION_TYPE> GetInvestigationTypes(DataTable data)
        {
            var lstInvestigationTypes = new List<REF_INVESTIGATION_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_INVESTIGATION_TYPE();

                    reftable.INVESTIGATION_TYPE_ID = Convert.ToInt32(dataRow["INVESTIGATION_TYPE_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.INVESTIGATION_DESC = dataRow["INVESTIGATION_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstInvestigationTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstInvestigationTypes;
        }

        /// <summary>
        /// REF_LANG table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_LANG> GetLanges(DataTable data)
        {
            var lstLanges = new List<REF_LANG>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_LANG();

                    reftable.LANG_ID = Convert.ToInt32(dataRow["LANG_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.LANG_DESC = dataRow["LANG_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstLanges.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLanges;
        }

        /// <summary>
        /// REF_LANGUAGE_PROFICIENCY table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_LANGUAGE_PROFICIENCY> GetLanguageProficiency(DataTable data)
        {
            var lstLanguageProficiency = new List<REF_LANGUAGE_PROFICIENCY>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_LANGUAGE_PROFICIENCY();

                    reftable.LANGUAGE_PROFICIENCY_CD = dataRow["LANGUAGE_PROFICIENCY_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.SHORT_DESC = dataRow["SHORT_DESC"].ToString();
                    reftable.LONG_DESC = dataRow["LONG_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["SORT_SEQ_NBR"].ToString()))
                    {
                        reftable.SORT_SEQ_NBR = Convert.ToInt32(dataRow["SORT_SEQ_NBR"]);
                    }
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstLanguageProficiency.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLanguageProficiency;
        }

        /// <summary>
        /// REF_LANGUAGE_USAGE table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_LANGUAGE_USAGE> GetLanguageUsage(DataTable data)
        {
            var lstLanguageUsage = new List<REF_LANGUAGE_USAGE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_LANGUAGE_USAGE();

                    reftable.LANGUAGE_USAGE_CD = dataRow["LANGUAGE_USAGE_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.LANGUAGE_USAGE_DESC = dataRow["LANGUAGE_USAGE_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["SORT_SEQ_NBR"].ToString()))
                    {
                        reftable.SORT_SEQ_NBR = Convert.ToInt32(dataRow["SORT_SEQ_NBR"]);
                    }
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstLanguageUsage.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLanguageUsage;
        }

        /// <summary>
        /// REF_LETTER_SOURCE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_LETTER_SOURCE> GetLetterSource(DataTable data)
        {
            var lstLetterSource = new List<REF_LETTER_SOURCE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_LETTER_SOURCE();

                    reftable.LETTER_SOURCE_CD = dataRow["LETTER_SOURCE_CD"].ToString();
                    reftable.LETTER_SOURCE_DESC = dataRow["LETTER_SOURCE_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstLetterSource.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLetterSource;
        }

        /// <summary>
        /// REF_LETTER_TYPE table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_LETTER_TYPE> GetLetterType(DataTable data)
        {
            var lstLetterType = new List<REF_LETTER_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_LETTER_TYPE();

                    reftable.LETTER_TYPE_CD = Convert.ToInt32(dataRow["LETTER_TYPE_CD"]);
                    reftable.LETTER_TYPE_DESC = dataRow["LETTER_TYPE_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstLetterType.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLetterType;
        }

        /// <summary>
        /// REF_LOCAL_APPL_STATUS table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_LOCAL_APPL_STATUS> GetLocalApplStatus(DataTable data)
        {
            var lstLocalApplStatus = new List<REF_LOCAL_APPL_STATUS>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_LOCAL_APPL_STATUS();

                    reftable.LOCAL_APPL_STATUS_ID = Convert.ToInt32(dataRow["LOCAL_APPL_STATUS_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.LOCAL_APPL_STATUS_DESC = dataRow["LOCAL_APPL_STATUS_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["ORDER_SEQ"].ToString()))
                    {
                        reftable.ORDER_SEQ = Convert.ToInt32(dataRow["ORDER_SEQ"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["IN_USE_IND"].ToString()))
                    {
                        reftable.IN_USE_IND = Convert.ToInt32(dataRow["IN_USE_IND"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["AMCAS_DEFINED_IND"].ToString()))
                    {
                        reftable.AMCAS_DEFINED_IND = Convert.ToInt32(dataRow["AMCAS_DEFINED_IND"]);
                    }
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstLocalApplStatus.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLocalApplStatus;
        }

        /// <summary>
        /// REF_MAJOR table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_MAJOR> GetMajor(DataTable data)
        {
            var lstMajor = new List<REF_MAJOR>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_MAJOR();

                    reftable.MAJOR_CD = dataRow["MAJOR_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.SHORT_DESC = dataRow["SHORT_DESC"].ToString();
                    reftable.LONG_DESC = dataRow["LONG_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["MAJOR_CAT_CD"].ToString()))
                    {
                        reftable.MAJOR_CAT_CD = dataRow["MAJOR_CAT_CD"].ToString();
                    }
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstMajor.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMajor;
        }

        /// <summary>
        /// REF_MED_GRAD_PROG table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_MED_GRAD_PROG> GetMedGraduatePrograms(DataTable data)
        {
            var lstMedGraduatePrograms = new List<REF_MED_GRAD_PROG>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_MED_GRAD_PROG();

                    reftable.MED_GRAD_PROGRAM_ID = Convert.ToInt32(dataRow["MED_GRAD_PROGRAM_ID"]);
                    if (!string.IsNullOrEmpty(dataRow["MED_INST_ID"].ToString()))
                    {
                        reftable.MED_INST_ID = Convert.ToInt32(dataRow["MED_INST_ID"]);
                    }
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    if (!string.IsNullOrEmpty(dataRow["GRAD_PROGRAM_ID"].ToString()))
                    {
                        reftable.GRAD_PROGRAM_ID = Convert.ToInt32(dataRow["GRAD_PROGRAM_ID"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["MED_PROGRAM_INFO_ID"].ToString()))
                    {
                        reftable.MED_PROGRAM_INFO_ID = Convert.ToInt32(dataRow["MED_PROGRAM_INFO_ID"]);
                    }
                    lstMedGraduatePrograms.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMedGraduatePrograms;
        }

        /// <summary>
        /// REF_MED_INST_CAMPUS table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_MED_INST_CAMPUS> GetMedInstCampus(DataTable data)
        {
            var lstMedInstCampus = new List<REF_MED_INST_CAMPUS>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_MED_INST_CAMPUS();

                    reftable.MED_INST_CAMPUS_ID = Convert.ToInt32(dataRow["MED_INST_CAMPUS_ID"]);
                    reftable.SHORT_DESC = dataRow["SHORT_DESC"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.LONG_DESC = dataRow["LONG_DESC"].ToString();
                    reftable.CITY = dataRow["CITY"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["MED_INST_ID"].ToString()))
                    {
                        reftable.MED_INST_ID = Convert.ToInt32(dataRow["MED_INST_ID"]);
                    }
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    if (!string.IsNullOrEmpty(dataRow["CAMPUS_CD"].ToString()))
                    {
                        reftable.CAMPUS_CD = Convert.ToInt32(dataRow["CAMPUS_CD"]);
                    }
                    lstMedInstCampus.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMedInstCampus;
        }

        /// <summary>
        /// REF_MILITARY_STATUS table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_MILITARY_STATUS> GetMilitaryStatus(DataTable data)
        {
            var lstMilitaryStatus = new List<REF_MILITARY_STATUS>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_MILITARY_STATUS();
                    reftable.MILITARY_STATUS_ID = Convert.ToInt32(dataRow["MILITARY_STATUS_ID"]);
                    reftable.MILITARY_STATUS_CD = dataRow["MILITARY_STATUS_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.STATUS_DESC = dataRow["STATUS_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["SORT_SEQ_NBR"].ToString()))
                    {
                        reftable.SORT_SEQ_NBR = Convert.ToInt32(dataRow["SORT_SEQ_NBR"]);
                    }
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstMilitaryStatus.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMilitaryStatus;
        }

        /// <summary>
        /// REF_OCCUPATION table object from file 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_OCCUPATION> GetOccupations(DataTable data)
        {
            var lstMilitaryStatus = new List<REF_OCCUPATION>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_OCCUPATION();
                    reftable.OCCUPATION_ID = Convert.ToInt32(dataRow["OCCUPATION_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.OCCUPATION_DESC = dataRow["OCCUPATION_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstMilitaryStatus.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstMilitaryStatus;
        }

        /// <summary>
        /// REF_PROGRAM_TYPE table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_PROGRAM_TYPE> GetProgramTypes(DataTable data)
        {
            var lstProgramTypes = new List<REF_PROGRAM_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_PROGRAM_TYPE();
                    reftable.PRGM_TYPE_CD = dataRow["PRGM_TYPE_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.PRGM_TYPE_DESC = dataRow["PRGM_TYPE_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstProgramTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstProgramTypes;
        }

        /// <summary>
        /// REF_RACE table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_RACE> GetRaces(DataTable data)
        {
            var lstRaces = new List<REF_RACE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_RACE();
                    reftable.RACE_CD = dataRow["RACE_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.RACE_DESC = dataRow["RACE_DESC"].ToString();
                    reftable.USCENSUS_TXT = dataRow["USCENSUS_TXT"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["RACE_CAT_CD"].ToString()))
                    {
                        reftable.RACE_CAT_CD = dataRow["RACE_CAT_CD"].ToString();
                    }
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstRaces.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstRaces;
        }


        /// <summary>
        /// REF_SCORE_RANGE table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_SCORE_RANGE> GetScoreRanges(DataTable data)
        {
            var lstScoreRanges = new List<REF_SCORE_RANGE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_SCORE_RANGE();
                    reftable.SCORE_RANGE_CD = dataRow["SCORE_RANGE_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.RANGE_DESC = dataRow["RANGE_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstScoreRanges.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstScoreRanges;
        }

        /// <summary>
        /// REF_SUBJECT_TYPE table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_SUBJECT_TYPE> GetSubjectTypes(DataTable data)
        {
            var lstSubjectTypes = new List<REF_SUBJECT_TYPE>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_SUBJECT_TYPE();
                    reftable.REF_SUBJECT_TYPE_CD = dataRow["REF_SUBJECT_TYPE_CD"].ToString();
                    reftable.REF_SUBJECT_TYPE_DESC = dataRow["REF_SUBJECT_TYPE_DESC"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstSubjectTypes.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstSubjectTypes;
        }

        /// <summary>
        /// REF_TERM table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_TERM> GetTerms(DataTable data)
        {
            var lstTerms = new List<REF_TERM>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_TERM();

                    reftable.ACA_TERM_CD = dataRow["ACA_TERM_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.ACA_TERM_DESC = dataRow["ACA_TERM_DESC"].ToString();
                    if (!string.IsNullOrEmpty(dataRow["DISPLAY_SEQ"].ToString()))
                    {
                        reftable.DISPLAY_SEQ = Convert.ToInt32(dataRow["DISPLAY_SEQ"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["CAL_SEQ"].ToString()))
                    {
                        reftable.CAL_SEQ = Convert.ToInt32(dataRow["CAL_SEQ"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["CAL_CONVERT"].ToString()))
                    {
                        reftable.CAL_CONVERT = Convert.ToInt32(dataRow["CAL_CONVERT"]);
                    }
                    if (!string.IsNullOrEmpty(dataRow["CALENDAR_CD"].ToString()))
                    {
                        reftable.CALENDAR_CD = dataRow["CALENDAR_CD"].ToString();
                    }
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);

                    lstTerms.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstTerms;
        }

        /// <summary>
        /// REF_VERIFICATION_SYMBOL Symbols table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_VERIFICATION_SYMBOL> GetVerificationSymbols(DataTable data)
        {
            var lstVerificationSymbols = new List<REF_VERIFICATION_SYMBOL>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_VERIFICATION_SYMBOL();
                    reftable.VERIFICATION_SYMBOL_ID = Convert.ToInt32(dataRow["VERIFICATION_SYMBOL_ID"]);
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.VERIFICATION_SYMBOL = dataRow["VERIFICATION_SYMBOL"].ToString();
                    reftable.VERIFICATION_DESC = dataRow["VERIFICATION_DESC"].ToString();
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    reftable.ACTIVE_IND = 1;
                    lstVerificationSymbols.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstVerificationSymbols;
        }

        /// <summary>
        /// REF_VISA table object from file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static List<REF_VISA> GetVisa(DataTable data)
        {
            var lstVisas = new List<REF_VISA>();
            try
            {
                foreach (DataRow dataRow in data.Rows)
                {
                    var reftable = new REF_VISA();
                    reftable.VISA_CD = dataRow["VISA_CD"].ToString();
                    reftable.APPL_YEAR = Convert.ToInt32(dataRow["APPL_YEAR"]);
                    reftable.VISA_DESC = dataRow["VISA_DESC"].ToString();
                    reftable.ACTIVE_IND = 1;
                    //if (!string.IsNullOrEmpty(dataRow["ACTIVE_IND"].ToString()))
                    //{
                    //    reftable.ACTIVE_IND = Convert.ToInt32(dataRow["ACTIVE_IND"]);
                    //}
                    //reftable.CREATED_BY = Convert.ToInt32(dataRow["CREATED_BY"]);
                    //reftable.LAST_UPDATE = Convert.ToDateTime(dataRow["LAST_UPDATE"]);
                    lstVisas.Add(reftable);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstVisas;
        }

    }
}
