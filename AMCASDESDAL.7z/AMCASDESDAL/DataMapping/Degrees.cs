﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class Degrees
    {
        public static List<DEGREE> DegreesList(ExportApplicationsApplication applicantInfo)
        {
            // Add DEGREE information
            var lstDegrees = new List<DEGREE>();
            try
            {
                if (applicantInfo.AcademicInformation.SchoolsAttended != null)
                {
                    foreach (var schoolsAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        if (schoolsAttended.Degree != null)
                        {
                            foreach (var degree in schoolsAttended.Degree)
                            {
                                var tblDegree = new DEGREE()
                                {
                                    DEGREE_ID = degree.DegreeID,
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    DEGREE_NAME = degree.DegreeName.DegreeDescription,
                                    SCHOOL_ATTENDED_ID = schoolsAttended.SchoolAttendedID,
                                    DEGREE_CD = degree.DegreeName.DegreeCode.ToString(),
                                    CERT_IND = 1,
                                    CREATED_BY = 1,
                                    LAST_UPDATE = DateTime.Now,
                                    HIGHEST_DEGREE_IND = 0, //Need to verify
                                };
                                if (degree.DegreeDateSpecified)
                                {
                                    tblDegree.DEGREE_DT = degree.DegreeDate;
                                }

                                lstDegrees.Add(tblDegree);
                            }
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstDegrees;
        }
    }
}
