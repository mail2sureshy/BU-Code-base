﻿using System;
using System.Collections.Generic;
using System.Linq;
using AMCASDESModels;
using System.Data.Entity;

namespace AMCASDESDAL.DataMapping
{
    public static class ActiveServices
    {
        public static List<DESService> GetActions()
        {
            try
            {               
                var context = new AMCASEntities();
                var result =
                    (from a in context.DES_SERVICE.AsNoTracking()                    
                     select new DESService()
                     {
                         DES_SERVICE_ID = a.DES_SERVICE_ID,
                         Appl_Year = a.Appl_Year,
                         DES_SERVICE_NAME = a.DES_SERVICE_NAME,
                         DES_SERVICE_DESC = a.DES_SERVICE_DESC,
                         WebAPIUrl = a.WebAPIURL,
                         RoutingName = a.RoutingName,
                         Frequency = a.FrequencyInMinutes,
                         NextExecutionTime = a.NextExecutionTime,
                         StartTime = a.StartTime,
                         EndTime = a.EndTime,
                         CategoryId = a.CategoryId,
                         IsActive = a.IsActive,
                         SkipCount = a.SkipCount
                     }).Distinct().OrderByDescending(s => s.SkipCount).ToList();
                
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int MinimumFrequency()
        {
            try
            {              
                var context = new AMCASEntities();
                var result =
                    (from a in context.DES_SERVICE.AsNoTracking()
                     select new DESService()
                     {
                         DES_SERVICE_ID = a.DES_SERVICE_ID,
                         Appl_Year = a.Appl_Year,
                         DES_SERVICE_NAME = a.DES_SERVICE_NAME,
                         DES_SERVICE_DESC = a.DES_SERVICE_DESC,
                         WebAPIUrl = a.WebAPIURL,
                         RoutingName = a.RoutingName,
                         Frequency = a.FrequencyInMinutes,
                         NextExecutionTime = a.NextExecutionTime,
                         StartTime = a.StartTime,
                         EndTime = a.EndTime,
                         CategoryId = a.CategoryId,
                         IsActive = a.IsActive,
                         SkipCount = a.SkipCount
                     }).Distinct().OrderBy(s => s.Frequency).ToList();

                return result[0].Frequency;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public static List<DESService> GetServicesWithActiveSessions()
        {
            try
            {                
                var context = new AMCASEntities();
                var result =
                    (from a in context.DES_SERVICE
                     join b in context.DES_Session on a.RoutingName equals b.RoutingName
                     where a.IsActive == true && b.EndDate == null
                     select new DESService()
                     {
                         DES_SERVICE_ID = a.DES_SERVICE_ID,
                         Appl_Year = a.Appl_Year,
                         DES_SERVICE_NAME = a.DES_SERVICE_NAME,
                         DES_SERVICE_DESC = a.DES_SERVICE_DESC,
                         WebAPIUrl = a.WebAPIURL,
                         RoutingName = a.RoutingName,
                         Frequency = a.FrequencyInMinutes,
                         NextExecutionTime = a.NextExecutionTime,
                         StartTime = a.StartTime,
                         EndTime = a.EndTime,
                         CategoryId = a.CategoryId,
                         IsActive = a.IsActive,
                         SkipCount = a.SkipCount
                     }).Distinct();
                return result.ToList();               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }        
    }
}
