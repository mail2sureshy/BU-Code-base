﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMCASDESDAL.DataMapping
{
    public static class LetterReceipts
    {
        public static List<LETTER_RECEIPT> LetterReceiptsList(ExportApplicationsApplication applicantInfo)
        {
            // Add Letter information 
            var lstLetterReceipts = new List<LETTER_RECEIPT>();
            try
            {
                if (applicantInfo.LettersOfEvaluation?.Letter != null && applicantInfo.LettersOfEvaluation.Letter.Length > 0)
                {
                    foreach (var letter in applicantInfo.LettersOfEvaluation.Letter)
                    {
                        if (letter.Receipt != null && letter.Receipt.Length > 0)
                        {
                            foreach (var receipt in letter.Receipt)
                            {
                                var letterReceipts = new LETTER_RECEIPT()
                                {
                                    LETTER_RECEIPT_ID = receipt.ReceiptDocumentID,
                                    //ACTIVE_IND =//Need to verify
                                    CREATED_BY = 1,
                                    LAST_UPDATE = DateTime.Now,
                                    LETTER_ID = letter.LetterID,
                                    LETTER_SOURCE_CD = receipt.Distributor?.DistributorCode,
                                    //DOCUMENT_STATUS_CD =//Need to verify
                                    //MARK_DATE =//Need to verify
                                    //OIT_DOCUMENT_NAME =//Need to verify
                                    RECEIPT_DATE = receipt.ReceiptDate,
                                    //BARCODE_SEQ_NUMBER =//Need to verify
                                    LOAD_DATE = DateTime.Now,
                                    //SCAN_DATETIME =//Need to verify
                                    //SCANNER_AAMC_ID =//Need to verify
                                    //LETTER_BATCH_ID =//Need to verify
                                    //QAED_BY =//Need to verify
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    //AAMC_INDEXED_IND =//Need to verify
                                    //QA_DATE =//Need to verify
                                };
                                lstLetterReceipts.Add(letterReceipts);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLetterReceipts;
        }
    }
}
