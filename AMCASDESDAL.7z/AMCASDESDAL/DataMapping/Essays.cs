﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class Essays
    {
        public static List<ESSAY> EssaysList(ExportApplicationsApplication applicantInfo)
        {
            // Add SCHOOL_ATTENDED information
            var lstEssays = new List<ESSAY>();
            try
            {
                if (applicantInfo.Essays != null)
                {
                    // Personal Comments
                    if (applicantInfo.Essays.PersonalStatement != null)
                    {
                        var tblEssayPersonal = new ESSAY()
                        {
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            ESSAY1 = applicantInfo.Essays.PersonalStatement,
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            ESSAY_TYPE_ID = GetEssayTypeId("Personal Comments", applicantInfo.IdentifyingInformation.ID.ApplicationYear)
                        };
                        lstEssays.Add(tblEssayPersonal);
                    }

                    // Significant Research Experience
                    if (applicantInfo.Essays.MDPhdEssay != null)
                    {
                        var tblPhdEssay = new ESSAY()
                        {
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            ESSAY1 = applicantInfo.Essays.MDPhdEssay,
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            ESSAY_TYPE_ID = GetEssayTypeId("Significant Research Experience", applicantInfo.IdentifyingInformation.ID.ApplicationYear)
                        };
                        lstEssays.Add(tblPhdEssay);
                    }

                    // MD/PhD Motivation Experience
                    if (applicantInfo.Essays.MDPhDResearchExperience != null)
                    {
                        var tblPhdExp = new ESSAY()
                        {
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            ESSAY1 = applicantInfo.Essays.MDPhDResearchExperience,
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            ESSAY_TYPE_ID = GetEssayTypeId("MD/PhD Motivation", applicantInfo.IdentifyingInformation.ID.ApplicationYear)
                        };
                        lstEssays.Add(tblPhdExp);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstEssays;
        }

        /// <summary>
        /// returns Essay type ID.
        /// </summary>
        /// <param name="essayTypeDesc"></param>
        /// <param name="year"></param>
        /// <returns>int</returns>
        private static int GetEssayTypeId(string essayTypeDesc, int year)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    return (int)context.REF_ESSAY_TYPE.FirstOrDefault(a => a.ESSAY_TYPE_DESC == essayTypeDesc && a.APPL_YEAR == year).REF_ESSAY_TYPE_ID;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
