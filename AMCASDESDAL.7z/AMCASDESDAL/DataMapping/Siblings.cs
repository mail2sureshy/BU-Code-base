﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class Siblings
    {
        public static List<SIBLING> SiblingsDataList(ExportApplicationsApplication applicantInfo)
        {
            // Add Sibling information //SIBLING
            var lstSibling = new List<SIBLING>();
            try
            {
                if (applicantInfo.DemographicInformation.GeneralDemographics.Siblings == null) return lstSibling;
                foreach (var sibling in applicantInfo.DemographicInformation.GeneralDemographics.Siblings)
                {
                    var tblsibling = new SIBLING()
                    {
                        SIBLING_ID = sibling.SiblingID,
                        AGE = sibling.Age,
                        GENDER = sibling.Sex != null && sibling.Sex == "Male" ? "M" : "F",
                        CERT_IND = 1,
                        CREATED_BY = 1,
                        LAST_UPDATE = DateTime.Now,
                        APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                        APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID
                    };
                    lstSibling.Add(tblsibling);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstSibling;
        }
    }
}
