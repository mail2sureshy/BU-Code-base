﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class Languages
    {
        public static List<LANGUAGE> LanguagesList(ExportApplicationsApplication applicantInfo)
        {
            // Add Languages information 
            var lstLanguages = new List<LANGUAGE>();
            try
            {
                if (applicantInfo.DemographicInformation.Languages != null)
                {
                    foreach (var language in applicantInfo.DemographicInformation.Languages)
                    {
                        var tblLanguages = new LANGUAGE()
                        {
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            NATIVE_IND = 0,
                            LANG_ID = GetLanguageId(language.LanguageDescription, applicantInfo.IdentifyingInformation.ID.ApplicationYear),
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            LAST_UPDATE = DateTime.Now,
                            USAGE_CD = language.LanguageUseInChildhoodHome.UsageCode.ToString(),
                            PROFICIENCY_CD = language.LanguageProficiency.ProficiencyCode.ToString(),
                            OTHER_LANG_DESC = language.OtherLanguageDescription,
                        };
                        lstLanguages.Add(tblLanguages);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstLanguages;
        }

        /// <summary>
        /// Lookup for Langvage ID
        /// </summary>
        /// <param name="languageDesc"></param>
        /// <param name="year"></param>
        /// <returns>int</returns>
        private static int GetLanguageId(string languageDesc, int year)
        {
            try
            {
                using (var context = new AMCASEntities())
                {
                    return (int)context.REF_LANG.FirstOrDefault(a => a.LANG_DESC == languageDesc && a.APPL_YEAR == year).LANG_ID;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
