﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class Gpas
    {
        public static List<GPA> GetGpaList(ExportApplicationsApplication applicantInfo)
        {
            // Add GPA information
            var lstGpas = new List<GPA>();
            try
            {
                if (applicantInfo.AcademicInformation.GPAs != null && applicantInfo.AcademicInformation.GPAs.GPA != null)
                {
                    foreach (var gpa in applicantInfo.AcademicInformation.GPAs.GPA)
                    {
                        var tblGpa = new GPA()
                        {
                            APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                            APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                            BCPM_GPA = gpa.BCPMGPA.BCPMGPA,
                            BCPM_HOURS = gpa.BCPMGPA.BCPMHours,
                            AO_GPA = gpa.AOGPA.AOGPA,
                            AO_HOURS = gpa.AOGPA.AOHours,
                            TOTAL_GPA = gpa.TotalGPA.TotalGPA,
                            TOTAL_HOURS = gpa.TotalGPA.TotalHours,
                            SUPP_HOURS_FAILED = applicantInfo.AcademicInformation.GPAs.SupplementalHoursFailed,
                            SUPP_HOURS_PASSED = applicantInfo.AcademicInformation.GPAs.SupplementalHoursPassed,
                            SUPP_HOURS_AP = applicantInfo.AcademicInformation.GPAs.SupplementalHoursAdvancedPlacement,
                            SUPP_HOURS_CLEP = applicantInfo.AcademicInformation.GPAs.SupplementalHoursCLEP,
                            CERT_IND = 1,
                            CREATED_BY = 1,
                            VERIFIED_IND =1,
                            ACA_STATUS_CD =gpa.AcademicStatus.ToString(),
                            LAST_UPDATE = DateTime.Now,
                            SUPP_HOURS_OTHER = applicantInfo.AcademicInformation.GPAs.SupplementalHoursOther
                        };
                        lstGpas.Add(tblGpa);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstGpas;
        }

        public static List<GPA_ARCHIVE> GetGpasArchiveList(ExportApplicationsApplication applicantInfo, int sessonId)
        {
            // Add Gpas Archive information
            var lstGpasArc = new List<GPA_ARCHIVE>();
            try
            {// Archive GPA's data into GPA_ARCHIVE table
                if (applicantInfo.AcademicInformation.GPAs != null)
                {
                    AMCASEntities context = new AMCASEntities();
                    var gpas = context.GPAs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                                                                d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);
                    if (gpas.Any())
                    {

                        foreach (var gpa in gpas)
                        {
                            var tblGpaArc = new GPA_ARCHIVE()
                            {
                                DESSessionID = sessonId,
                                APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID,
                                APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                BCPM_GPA = gpa.BCPM_GPA,
                                BCPM_HOURS = gpa.BCPM_HOURS,
                                AO_GPA = gpa.AO_GPA,
                                AO_HOURS = gpa.AO_HOURS,
                                TOTAL_GPA = gpa.TOTAL_GPA,
                                TOTAL_HOURS = gpa.TOTAL_HOURS,
                                SUPP_HOURS_FAILED = gpa.SUPP_HOURS_FAILED,
                                SUPP_HOURS_PASSED = gpa.SUPP_HOURS_PASSED,
                                SUPP_HOURS_AP = gpa.SUPP_HOURS_AP,
                                SUPP_HOURS_CLEP = gpa.SUPP_HOURS_CLEP,
                                CERT_IND = 1,
                                CREATED_BY = 1,
                                VERIFIED_IND = 1,
                                ACA_STATUS_CD = gpa.ACA_STATUS_CD,
                                CREATE_DATE = DateTime.Now,
                                LAST_UPDATE = DateTime.Now,
                                SUPP_HOURS_OTHER = gpa.SUPP_HOURS_OTHER
                            };
                            lstGpasArc.Add(tblGpaArc);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstGpasArc;
        }
    }
}
