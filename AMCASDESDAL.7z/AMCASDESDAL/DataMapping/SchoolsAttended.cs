﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class SchoolsAttended
    {
        public static List<SCHOOL_ATTENDED> SchoolsAttendedList(ExportApplicationsApplication applicantInfo)
        {
            var lstSchoolsAttended = new List<SCHOOL_ATTENDED>();
            try
            {
                // Add SCHOOL_ATTENDED information
                if (applicantInfo.AcademicInformation.SchoolsAttended != null)
                {
                    foreach (var schoolAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        var lstSchoolAttended = new SCHOOL_ATTENDED();

                        lstSchoolAttended.CITY = schoolAttended.City;
                        lstSchoolAttended.TRANS_ID = null; // Need to verify
                        lstSchoolAttended.TRANS_NAME = null; // Need to verify
                        lstSchoolAttended.FINAL_OT_RECEIVED_IND = 0; // Need to verify
                        lstSchoolAttended.SCHOOL_ATTENDED_ID = schoolAttended.SchoolAttendedID;
                        lstSchoolAttended.APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID;
                        lstSchoolAttended.TRANS_CREDIT_SCHOOL_ATTENDED = 0; //Need to verify
                        if (!string.IsNullOrEmpty(schoolAttended.StartMonthAndYear))
                        {
                            lstSchoolAttended.ATTEND_START_DT = Convert.ToDateTime(schoolAttended.StartMonthAndYear);
                        }

                        if (!string.IsNullOrEmpty(schoolAttended.EndMonthAndYear))
                        {
                           lstSchoolAttended.ATTEND_FINISH_DT = Convert.ToDateTime(schoolAttended.EndMonthAndYear);
                        }
                        
                        lstSchoolAttended.SUMMER_SCHL_IND = 0; // Need to verify
                        lstSchoolAttended.STUDY_ABROAD_IND = 0; // Need to verify
                        lstSchoolAttended.TRANS_REQ_IND = 0; // Need to verify
                        lstSchoolAttended.COUNTRY_CD = schoolAttended.Country?.CountryCode.ToString();
                        lstSchoolAttended.EVAL_IND = 0; // Need to verify
                        lstSchoolAttended.MOD_SCHOOL_DESC =
                            applicantInfo.AcademicInformation.HighSchool.Name.ModifiedDescription;
                        //lstSchoolAttended.COLLEGE_GRAD_DATE = //Need to verify;
                        lstSchoolAttended.HIGH_SCHOOL_GRAD_YEAR = Convert.ToDecimal(applicantInfo.AcademicInformation.HighSchool.GraduationYear);
                        if (applicantInfo.AcademicInformation.HighSchool?.HighSchoolInstitutionID != 0)
                        {
                            lstSchoolAttended.HIGH_SCHOOL_INST_ID =
                                applicantInfo.AcademicInformation.HighSchool?.HighSchoolInstitutionID;
                        }
                        lstSchoolAttended.PRGM_TYPE_CD = schoolAttended.ProgramType.ProgramTypeCode.ToString();
                        lstSchoolAttended.CERT_IND = 1;
                        //lstSchoolAttended.EXCEPTION_STATUS = Need to verify
                        //lstSchoolAttended.ADVISOR_RELEASE_IND =Need to verify
                        lstSchoolAttended.CREATED_BY = 1;
                        lstSchoolAttended.LAST_UPDATE = DateTime.Now;
                        //lstSchoolAttended.TRNSCPT_TYPE_ID =
                        lstSchoolAttended.PRIMARY_UNDERGRAD_INST_IND =
                            schoolAttended.PrimaryUndergraduateInstitutionIndicator ? 1 : 0;
                        //lstSchoolAttended.COLLEGE_PRGM_ID = Need to verify
                        //lstSchoolAttended.GRADE_SYSTEM_TYPE_ID = Need to verify
                        lstSchoolAttended.APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear;
                        lstSchoolAttended.STATE_CD = schoolAttended.State?.StateCode.ToString();
                        lstSchoolAttended.COLLEGE_INST_ID = schoolAttended.CollegeInstitutionID;
                        lstSchoolAttended.COUNTY_CD = schoolAttended.County?.CountyCode;
                        //lstSchoolAttended.HIGHEST_DEGREE_INST_IND = Need to verify

                        lstSchoolsAttended.Add(lstSchoolAttended);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lstSchoolsAttended;
        }
    }
}
