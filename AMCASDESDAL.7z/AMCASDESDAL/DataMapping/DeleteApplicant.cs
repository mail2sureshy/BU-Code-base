﻿using System;
using System.Data.Entity.Validation;
using System.Linq;
using System.Threading.Tasks;

namespace AMCASDESDAL.DataMapping
{
    public static class DeleteApplicant
    {
        public static async Task<bool> DeleteExistingApplicant(AMCASEntities context, ExportApplicationsApplication applicantInfo)
        {
            try
            {
                context.Database.CommandTimeout = 180;
                // Delete Alternate Names.
                context.NAMEs.RemoveRange(context.NAMEs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete LANGUAGEs.
                context.LANGUAGEs.RemoveRange(context.LANGUAGEs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete EXPERIENCEs.
                context.EXPERIENCEs.RemoveRange(context.EXPERIENCEs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete ETHNICITies.
                context.ETHNICITies.RemoveRange(context.ETHNICITies.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete Races.
                context.RACEs.RemoveRange(context.RACEs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete ESSAYs.
                context.ESSAYs.RemoveRange(context.ESSAYs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete DEGREEs.
                if (applicantInfo.AcademicInformation.SchoolsAttended != null)
                {
                    foreach (var schoolAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        if (schoolAttended?.Degree != null && schoolAttended.Degree.Length > 0)
                        {
                            foreach (var degree in schoolAttended.Degree)
                            {
                                context.DEGREEs.RemoveRange(context.DEGREEs.Where(d => d.DEGREE_ID == degree.DegreeID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                                //await context.SaveChangesAsync();
                            }
                        }
                    }
                }
                
                // Delete SIBLINGs.
                context.SIBLINGs.RemoveRange(context.SIBLINGs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete Disadvantaged data.
                context.DISADVANTAGED_STATUS.RemoveRange(context.DISADVANTAGED_STATUS.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete ALTERNATE_ID.
                context.ALTERNATE_ID.RemoveRange(context.ALTERNATE_ID.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete ADDRESSes.
                context.ADDRESSes.RemoveRange(context.ADDRESSes.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete Parent Guardians
                context.PARENT_GUARDIAN.RemoveRange(context.PARENT_GUARDIAN.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete Letter Receipts
                if (applicantInfo.LettersOfEvaluation?.Letter != null && applicantInfo.LettersOfEvaluation.Letter.Length > 0)
                {
                    foreach (var letter in applicantInfo.LettersOfEvaluation.Letter)
                    {
                        context.LETTER_RECEIPT.RemoveRange(
                           context.LETTER_RECEIPT.Where(a => a.LETTER_ID == letter.LetterID));
                           //await context.SaveChangesAsync();
                    }
                }

                // Delete Document Receipts
                if (applicantInfo.LettersOfEvaluation?.Letter != null && applicantInfo.LettersOfEvaluation.Letter.Length > 0)
                {
                    foreach (var letter in applicantInfo.LettersOfEvaluation.Letter)
                    {
                        if (letter.Receipt!= null && letter.Receipt.Length > 0)
                        {
                            foreach (var receipt in letter.Receipt)
                            {
                                var docReceipts = context.DOCUMENT_RECEIPT.Where(
                                    b => b.DocumentReceiptID == receipt.ReceiptDocumentID && 
                                    b.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                                    b.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);

                                if (docReceipts.Count() > 0)
                                {
                                    foreach (var docs in docReceipts)
                                    {
                                        int? docReceiptId = docs.DocumentContentID;
                                        if (docReceiptId != null)
                                        {
                                            // Delete data from Document content table
                                            context.DOCUMENT_CONTENT.Remove(
                                                context.DOCUMENT_CONTENT.SingleOrDefault(
                                                    a => a.DocumentContentID == docReceiptId));
                                            //await context.SaveChangesAsync();
                                        }
                                    }
                                }                               
                            }
                        }
                    }
                    // Delete data from Document Receipt table if needed
                    context.DOCUMENT_RECEIPT.RemoveRange(
                                    context.DOCUMENT_RECEIPT.Where(
                                        d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                                        d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                    //await context.SaveChangesAsync();
                }
                
                // Delete Letters
                context.LETTERs.RemoveRange(context.LETTERs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete GPA's
                context.GPAs.RemoveRange(context.GPAs.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete MCAT data
                context.MCAT_SCORES.RemoveRange(context.MCAT_SCORES.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete MCAT2015 data
                context.MCAT_SCORE_2015.RemoveRange(context.MCAT_SCORE_2015.Where(d => d.appl_person_id == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.appl_year == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete Investigative And Evaluative Document Receipts.
                if (applicantInfo.Documents != null)
                {
                    // Delete Evaluative Document Receipts.
                    if (applicantInfo.Documents.EvaluationID != null)
                    {
                        foreach (var evaluationId in applicantInfo.Documents.EvaluationID)
                        {

                            var documentReceipt = context.DOCUMENT_RECEIPT.FirstOrDefault(b => b.DocumentReceiptID == evaluationId);

                            int? docReceiptId = documentReceipt?.DocumentContentID;

                            if (docReceiptId != null)
                            {
                                // Delete data from Document content table
                                context.DOCUMENT_CONTENT.Remove(
                                    context.DOCUMENT_CONTENT.SingleOrDefault(
                                        a => a.DocumentContentID == docReceiptId));
                                //await context.SaveChangesAsync();
                            }
                        }
                    }

                    // Delete Investigative Document Receipts.
                    if (applicantInfo.Documents.InvestigationID != null)
                    {
                        foreach (var investigationId in applicantInfo.Documents.InvestigationID)
                        {
                            var documentReceipt = context.DOCUMENT_RECEIPT.FirstOrDefault(b => b.DocumentReceiptID == investigationId);

                            int? docReceiptId = documentReceipt?.DocumentContentID;

                            if (docReceiptId != null)
                            {
                                // Delete data from Document content table
                                context.DOCUMENT_CONTENT.Remove(
                                    context.DOCUMENT_CONTENT.SingleOrDefault(
                                        a => a.DocumentContentID == docReceiptId));
                                //await context.SaveChangesAsync();
                            }
                        }
                    }
                }

                // Delete Major Minor data.
                if (applicantInfo.AcademicInformation.SchoolsAttended != null)
                {
                    foreach (var schoolAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        context.MAJOR_MINOR.RemoveRange(context.MAJOR_MINOR.Where(d => d.SCHOOL_ATTENDED_ID == schoolAttended.SchoolAttendedID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                        //await context.SaveChangesAsync();
                    }
                }

                // Delete Course Type data.
                if (applicantInfo.AcademicInformation.SchoolsAttended != null)
                {
                    foreach (var schoolAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        if (schoolAttended.Coursework != null && schoolAttended.Coursework.Length > 0)
                        {
                            foreach (var courseWork in schoolAttended.Coursework)
                            {
                                context.COURSE_TYPE.RemoveRange(context.COURSE_TYPE.Where(d => d.CRSE_WORK_ID == courseWork.CourseWorkID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                                //await context.SaveChangesAsync();
                            }
                        }
                    }
                }
                
                // Delete Course Work data.
                if (applicantInfo.AcademicInformation.SchoolsAttended != null)
                {
                    foreach (var schoolAttended in applicantInfo.AcademicInformation.SchoolsAttended)
                    {
                        context.COURSE_WORK.RemoveRange(context.COURSE_WORK.Where(d => d.SCHOOL_ATTENDED_ID == schoolAttended.SchoolAttendedID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                        //await context.SaveChangesAsync();
                    }
                }

                // Delete Misc Test data.
                context.MISC_TEST.RemoveRange(context.MISC_TEST.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                // Delete Previous Application Info
                context.PREVIOUS_APPLICATION_INFO.RemoveRange(context.PREVIOUS_APPLICATION_INFO.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                //// Delete Designated Grad Area
                //if (applicantInfo.MedicalSchoolDesignation != null)
                //{
                //    var designatedSchools = context.DESIGNATED_SCHOOL.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                //                                                        d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);
                //    if (designatedSchools != null && designatedSchools.Any())
                //    {
                //        foreach (var designatedSchool in designatedSchools)
                //        {
                //            var designatedProgramIds = context.DESIGNATED_PROGRAM.Where(d => d.DESIGNATED_SCHOOL_ID == designatedSchool.DESIGNATED_SCHOOL_ID && d.APPL_YEAR == designatedSchool.APPL_YEAR);

                //            if (designatedProgramIds != null && designatedProgramIds.Count() > 0)
                //            {
                //                foreach (var designatedProgramId in designatedProgramIds)
                //                {
                //                    context.DESIGNATED_GRAD_AREA.RemoveRange(context.DESIGNATED_GRAD_AREA.Where(d => d.DESIGNATED_PROGRAM_ID == designatedProgramId.DESIGNATED_PROGRAM_ID && d.APPL_YEAR == designatedProgramId.APPL_YEAR));
                //                    //await context.SaveChangesAsync();
                //                }
                //            }
                //        }
                //    }
                //}

                //// Delete Designated Program
                //if (applicantInfo.MedicalSchoolDesignation != null)
                //{
                //    var designatedSchools = context.DESIGNATED_SCHOOL.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID &&
                //                                                        d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear);
                //    if (designatedSchools != null && designatedSchools.Any())
                //    {
                //        foreach (var designatedSchool in designatedSchools)
                //        {
                //            context.DESIGNATED_PROGRAM.RemoveRange(context.DESIGNATED_PROGRAM.Where(d => d.DESIGNATED_SCHOOL_ID == designatedSchool.DESIGNATED_SCHOOL_ID && d.APPL_YEAR == designatedSchool.APPL_YEAR));
                //            //await context.SaveChangesAsync();
                //        }
                //    }
                //}

                // Delete SCHOOL_ATTENDED.
                context.SCHOOL_ATTENDED.RemoveRange(context.SCHOOL_ATTENDED.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                //await context.SaveChangesAsync();

                //// Delete Designated schools data.
                //context.DESIGNATED_SCHOOL.RemoveRange(context.DESIGNATED_SCHOOL.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));
                ////await context.SaveChangesAsync();

                // Delete APPLICANT_PERSON.
                context.APPLICANT_PERSON.RemoveRange(context.APPLICANT_PERSON.Where(d => d.APPL_PERSON_ID == applicantInfo.IdentifyingInformation.ID.ApplicantPersonID && d.APPL_YEAR == applicantInfo.IdentifyingInformation.ID.ApplicationYear));

                await context.SaveChangesAsync();
            }
            catch (DbEntityValidationException ex)
            {
                // Retrieve the error messages as a list of strings.
                var errorMessages = ex.EntityValidationErrors
                        .SelectMany(x => x.ValidationErrors)
                        .Select(x => x.ErrorMessage);

                // Join the list to a single string.
                var fullErrorMessage = string.Join("; ", errorMessages);

                // Combine the original exception message with the new one.
                var exceptionMessage = string.Concat(ex.Message, " The validation errors are: ", fullErrorMessage);

                // Throw a new DbEntityValidationException with the improved exception message.
                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
    }
}
