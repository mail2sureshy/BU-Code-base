﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AMCASDESDAL.DataMapping
{
    public static class ParentGuardian
    {
        public static List<PARENT_GUARDIAN> GetParentGuardianList(ExportApplicationsApplication applicantInfo)
        {
            // Add PARENT_GUARDIAN information
            var lstParentGuardian = new List<PARENT_GUARDIAN>();
            try
            {
                if (applicantInfo.DemographicInformation.ParentGuardian != null && applicantInfo.DemographicInformation.ParentGuardian.Length > 0)
                {
                    foreach (var parentGuardian in applicantInfo.DemographicInformation.ParentGuardian)
                    {
                        var tblParentGuardian = new PARENT_GUARDIAN();

                        tblParentGuardian.PARENT_GUARDIAN_ID = parentGuardian.ParentGuardianID;
                        tblParentGuardian.APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID;
                        tblParentGuardian.NAME = parentGuardian.Name;
                        tblParentGuardian.OCCUPATION_DESC = parentGuardian.Occupation.OccupationDescription;
                        tblParentGuardian.OCCUPATION_ID = parentGuardian.Occupation.OccupationID;
                        tblParentGuardian.LIVING_IND = parentGuardian.LivingIndicator == "Yes" ? 1 : 0;
                        tblParentGuardian.EDU_LEVEL_ID = Convert.ToInt32(parentGuardian.EducationLevel);
                        tblParentGuardian.GENDER = parentGuardian.Sex.ToUpper() == "MALE" ? "M" : "Y";
                        tblParentGuardian.RURAL_IND = 0;
                        tblParentGuardian.SCHOOL_CITY = parentGuardian.School.SchoolCity;
                        tblParentGuardian.SCHOOL_COUNTRY_CD = parentGuardian.School.SchoolCountry?.CountryCode.ToString();
                        if (parentGuardian.School.SchoolName?.LongDescription != null)
                        {
                            string schoolCountyCode = GetSchoolCoutyCode(parentGuardian.School.SchoolName.LongDescription, applicantInfo.IdentifyingInformation.ID.ApplicationYear, parentGuardian.School.SchoolCity);
                            if (!string.IsNullOrEmpty(schoolCountyCode))
                            {
                                tblParentGuardian.SCHOOL_COUNTY_CD = schoolCountyCode;
                            }

                            decimal? collegeInstId = GetCollegeInstId(parentGuardian.School.SchoolName.LongDescription, applicantInfo.IdentifyingInformation.ID.ApplicationYear, parentGuardian.School.SchoolCity);
                            if (collegeInstId != 0)
                            {
                                tblParentGuardian.COLLEGE_INST_ID = collegeInstId;
                            }
                        }
                        
                        tblParentGuardian.CERT_IND = 1;
                        tblParentGuardian.CREATED_BY = 1;
                        tblParentGuardian.LAST_UPDATE = DateTime.Now;
                        tblParentGuardian.LEGAL_COUNTRY_CD = parentGuardian.CountryOfResidence?.CountryCode.ToString();
                        tblParentGuardian.LEGAL_COUNTY_CD = parentGuardian.CountyOfResidence?.CountyCode;
                        tblParentGuardian.SCHOOL_STATE_CD = parentGuardian.School.SchoolState?.StateCode.ToString();
                        tblParentGuardian.LEGAL_STATE_CD = parentGuardian.StateOfResidence?.StateCode.ToString();
                        tblParentGuardian.MOD_SCHOOL_DESC = parentGuardian.School.SchoolName?.ModifiedDescription;
                        tblParentGuardian.APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear;
                        
                       
                        lstParentGuardian.Add(tblParentGuardian);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstParentGuardian;
        }

        private static string GetSchoolCoutyCode(string schoolLongDesc, int year, string city)
        {
            using (var context = new AMCASEntities())
            {
                var refCollegeInstitution = context.REF_COLLEGE_INSTITUTION.FirstOrDefault(a => a.LONG_DESC == schoolLongDesc && a.CITY == city && a.APPL_YEAR == year);
                return refCollegeInstitution?.COUNTY_CD;
            }
        }

        private static decimal? GetCollegeInstId(string schoolLongDesc, int year, string city)
        {
            using (var context = new AMCASEntities())
            {
                var refCollegeInstitution = context.REF_COLLEGE_INSTITUTION.FirstOrDefault(a => a.LONG_DESC == schoolLongDesc && a.CITY == city && a.APPL_YEAR == year);
                return refCollegeInstitution?.COLLEGE_INST_ID;
            }
        }

    }
}
