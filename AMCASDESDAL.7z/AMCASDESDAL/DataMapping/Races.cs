﻿using System;
using System.Collections.Generic;

namespace AMCASDESDAL.DataMapping
{
    public static class Races
    {
        public static List<RACE> GetRacesList(ExportApplicationsApplication applicantInfo)
        {
            // Add RACE information
            var lstRaces = new List<RACE>();
            try
            {
                if (applicantInfo.DemographicInformation.SelfIdentification.Races != null)
                {
                    foreach (var race in applicantInfo.DemographicInformation.SelfIdentification.Races)
                    {
                        // If Race Subcategory exist insert Subcategory else insert Race category.
                        if (race.RaceSubcategory != null)
                        {
                            foreach (var raceSubCat in race.RaceSubcategory) // Need to check what to insert.
                            {
                                var tblRace = new RACE()
                                {
                                    APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                    MOD_DESC = raceSubCat.RaceDescription,
                                    RACE_CD = raceSubCat.RaceCode.ToString(),
                                    CERT_IND = 1,
                                    CREATED_BY = 1,
                                    LAST_UPDATE = DateTime.Now,
                                    APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID
                                };
                                lstRaces.Add(tblRace);
                            }
                        }
                        else
                        {
                            var tblRace = new RACE()
                            {
                                APPL_YEAR = applicantInfo.IdentifyingInformation.ID.ApplicationYear,
                                MOD_DESC = race.RaceCategoryDescription, 
                                RACE_CD = race.RaceCategoryCode.ToString(),
                                CERT_IND = 1,
                                CREATED_BY = 1,
                                LAST_UPDATE = DateTime.Now,
                                APPL_PERSON_ID = applicantInfo.IdentifyingInformation.ID.ApplicantPersonID
                            };
                            lstRaces.Add(tblRace);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstRaces;
        }
    }
}
