﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AMCASDESModels
{
    public interface IAMCASRepository
    {
        #region DES Calls
        Task<bool> SaveDocumnetContents(DocumentContentData data);
        IEnumerable<DocumentContent> GetDocumnetContents(int appYear);

        Task<string> GetAmcasActions(int appYear, int medicalInstId);

        Task<bool> UpdateAmcasActionsResults(AdmissionActionsResponse response);

        Task<bool> InsertApplicantsData(Export data,int sesson,int batchId, int year);
        
        Task<bool> InsertEvenLogInformation(string message, string url = null, int sessionId = 0);

        Task<int> InsertSessionId(string methodCall, string clientIpAddress, string routingName);

        Task<bool> UpdateSessionId(int sessionId);

        Task<int> InsertBatchId(int seesionId, string xmlResponse);

        List<decimal> ApplicantExist(int applYear);

        #endregion

        #region REF Calls

        Task<string> InsertReferenceTablesData(string filePath,int applicationYear);

        #endregion

        #region ServiceRelated

        List<DESService> GetActions();

        List<DESService> GetServicesWithActiveSession();

        int GetMinimumFrequency();

        int DelayExecution(int desServiceId, DateTime nextExecutionTime, int skipCount);

        #endregion
    }
}
