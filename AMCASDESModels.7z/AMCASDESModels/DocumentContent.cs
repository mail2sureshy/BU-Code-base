﻿using System;

namespace AMCASDESModels
{
    public class DocumentContent
    {
        public int DocumentReceiptId { get; set; }

        public string DocumentType { get; set; }
        
        public decimal ApplicantPersonId { get; set; }
        
        public decimal ApplicantYear { get; set; }
        
        public int? DocumentContentId { get; set; }

        public string DocumentContentType { get; set; }
    }

    public class DocumentContentData
    {
        public int DocumentReceiptId { get; set; }

        public string DocumentType { get; set; }

        public decimal ApplicantPersonId { get; set; }

        public decimal ApplicantYear { get; set; }

        public int? DocumentSize { get; set; }

        public byte[] DocumentContent { get; set; }

        public string DocumentContentType { get; set; }

    }

    public class DESService
    {
        public int DES_SERVICE_ID { get; set; }
        public int Appl_Year { get; set; }
        public string DES_SERVICE_NAME { get; set; }
        public string DES_SERVICE_DESC { get; set; }
        public string WebAPIUrl { get; set; }                
        public string RoutingName { get; set; }
        public int Frequency { get; set; }
        public DateTime NextExecutionTime { get; set; }
        public int StartTime { get; set; }
        public int EndTime { get; set; }
        public bool IsActive { get; set; }
        public int CategoryId { get; set; }

        public int SkipCount { get; set; }
    }

}
